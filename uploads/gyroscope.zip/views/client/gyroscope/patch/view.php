<?php
$patchInfo = $this->all["patch"];
?>
<style>
    .main-text-bg{
        width: 95%;
        overflow: auto;
        padding: 20px;
    }
</style>
<aside id="right">
    <div id="content_ajax">
        <article class="page_article">
			<?php Cache::open($patchInfo->id."_patch");?>
			<?php if (Cache::check($patchInfo->id."_patch")):?>
            <h2 class="head"><?=$patchInfo->title?></h2>
            <div class="body">
                <div class="main-inner main-inner-news">
                    <div class="main-text-bg">
                        <div style="float: right;color: #A07332"><?=Functions::prettyDateTime1($patchInfo->tarih);?></div>
                        <br><br>
                        <div class="main-text">
							<?=$patchInfo->content?>
                        </div>
                    </div>
                </div>
            </div>
			<?php endif;?>
			<?php Cache::close($patchInfo->id."_patch");?>
        </article>
    </div>
</aside>