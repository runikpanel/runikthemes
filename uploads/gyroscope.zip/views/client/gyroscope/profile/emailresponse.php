<?php $status = $this->all['result']; ?>
<aside id="right">
    <div id="content_ajax">
        <article class="page_article">
            <h2 class="head"><?=$lng[122]?><a href="<?=URI::get_path('profile')?>" class="back-to-account" title="Geri"></a></h2>
            <div class="body">
                <div class="bg-light">
					<?php if(!$status): ?>
						<?= Client::alert('error',$lng[81]);?>
					<?php else:?>
						<?= Client::alert('info',$lng[135]);?>
                        <form id="emailChangeForm2" action="<?=URI::get_path('profile/emailchange3')?>" method="post" accept-charset="utf-8" class="page_form" autocomplete="off">
                            <table style="width:500px;">
                                <tr>
                                    <td><label for="password"><?=$lng[23]?> :</label></td>
                                    <td>
                                        <span class="warfg_input" style="">
                                            <input type="password" id="password" name="password" value="" placeholder="<?=$lng[23]?>">
                                        </span>
                                    </td>
                                </tr>
                                <tr>
                                    <td><label for="newMail"><?=$lng[133]?> :</label></td>
                                    <td>
                                        <span class="warfg_input" style="">
                                            <input type="email" id="newMail" name="new_mail" value="" placeholder="<?=$lng[133]?>">
                                        </span>
                                    </td>
                                </tr>
                                <tr>
                                    <td><label for="reMail"><?=$lng[134]?> :</label></td>
                                    <td>
                                        <span class="warfg_input" style="">
                                            <input type="email" id="reMail" name="re_mail" value="" placeholder="<?=$lng[134]?>">
                                        </span>
                                    </td>
                                </tr>
                                <tr>
                                    <td><label for="reCaptcha"><?=$lng[24]?> :</label></td>
                                    <td>
										<?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                                    </td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td>
                                        <span class="warfg_btn"><input type="submit" name="login_submit" value="<?=$lng[122]?>"></span>
                                    </td>
                                </tr>
                            </table>
                        </form>
					<?php endif;?>
                </div>
            </div>
        </article>
    </div>
</aside>
<script>
    $("#emailChangeForm2").on("submit", function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                grecaptcha.reset();
                if (response.result)
                    successNotify(response.message);
                else
                    errorNotify(response.message);
            }
        });
    });
</script>