<?php $isBanned = $this->all["is_banned"];?>
<aside id="right">
    <div id="content_ajax">
        <article class="page_article">
            <h2 class="head"><?=$lng[141]?><a href="<?=URI::get_path('profile')?>" class="back-to-account" title="Geri"></a></h2>
            <div class="body">
                <div class="error-holder">
                    <div class="container_3 red wide fading-notification" align="left">
						<?php if ($isBanned):?>
							<?= Client::alert('error', $lng[112]);?>
						<?php else:?>
                    </div>
                </div>
                <form id="passwordChangeForm" action="<?=URI::get_path('profile/passwordchange')?>" method="post" accept-charset="utf-8" class="page_form" autocomplete="off">
                    <table style="width:500px;">
                        <tr>
                            <td><label for="oldPassword"><?=$lng[165]?> :</label></td>
                            <td>
                                <span class="warfg_input" style="">
                                    <input type="password" id="oldPassword" name="old_password" placeholder="<?=$lng[165]?>">
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td><label for="newPassword"><?=$lng[166]?> :</label></td>
                            <td>
                                <span class="warfg_input" style="">
                                    <input type="password" id="newPassword" name="new_password" maxlength="16" placeholder="<?=$lng[166]?>">
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td><label for="rePassword"><?=$lng[167]?> :</label></td>
                            <td>
                                <span class="warfg_input" style="">
                                    <input type="password" id="rePassword" name="re_password" maxlength="16" placeholder="<?=$lng[167]?>">
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td><label for="reCaptcha"><?=$lng[24]?> :</label></td>
                            <td>
								<?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                            </td>
                        </tr>
                        <tr>
                            <td></td>
                            <td>
                                <span class="warfg_btn"><input type="submit" name="login_submit" value="<?=$lng[141]?>"></span>
                            </td>
                        </tr>
                    </table>
                </form>
				<?php endif;?>
            </div>
        </article>
    </div>
</aside>
<script>
    $("#passwordChangeForm").on("submit", function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                grecaptcha.reset();
                if (response.result)
                    successNotify(response.message);
                else
                    errorNotify(response.message);
            }
        });
    });
</script>