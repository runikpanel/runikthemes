<?php
$isBanned = $this->all["is_banned"];
$mailActive = $this->all["mail_active"];
?>
<aside id="right">
    <div id="content_ajax">
        <article class="page_article">
            <h2 class="head"><?=$lng[98]?><a href="<?=URI::get_path('profile')?>" class="back-to-account" title="Geri"></a></h2>
            <div class="body">
                <div class="error-holder">
                    <div class="container_3 red wide fading-notification" align="left">
						<?php if ($isBanned):?>
							<?= Client::alert('error',$lng[112]); ?>
						<?php elseif ($mailActive === "1"):?>
							<?= Client::alert('error',$lng[113])?>
                            <a href="<?=URI::get_path('profile/aktive')?>" ><button type="submit" class="center-block btn btn-grunge"><?=$lng[114]?></button></a>
						<?php else:?>
                    </div>
                </div>
                <form id="mailActivationForm" action="<?=URI::get_path('profile/aktivechange')?>" method="post" accept-charset="utf-8" class="page_form" autocomplete="off">
                    <table style="width:500px;">
                        <tr>
                            <td><label for="password"><?=$lng[23]?> :</label></td>
                            <td>
                                <span class="warfg_input" style="">
                                    <input type="password" id="password" name="password" value="" placeholder="<?=$lng[23]?>">
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td><label for="reCaptcha"><?=$lng[24]?> :</label></td>
                            <td>
								<?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                            </td>
                        </tr>
                        <tr>
                            <td></td>
                            <td>
                                <span class="warfg_btn"><input type="submit" name="login_submit" value="<?=$lng[104]?>"></span>
                            </td>
                        </tr>
                    </table>
                </form>
				<?php endif;?>
            </div>
        </article>
    </div>
</aside>
<script>
    $("#mailActivationForm").on("submit", function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                grecaptcha.reset();
                if (response.result)
                    successNotify(response.message);
                else
                    errorNotify(response.message);
            }
        });
    });
</script>