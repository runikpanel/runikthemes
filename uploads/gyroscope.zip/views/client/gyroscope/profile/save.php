<?php
$isBanned = $this->all["is_banned"];
$playerInfo = $this->all["player_info"];
$randomKey = Functions::generateRandomString(32);
Session::setHash(['bug_key'=>$randomKey]);
?>
<style>
    .g-recaptcha{
        -webkit-transform: scale(1);
        margin-top: 15px;
    }
</style>
<aside id="right">
    <div id="content_ajax">
        <article class="page_article">
            <h2 class="head"><?=$lng[106]?><a href="<?=URI::get_path('profile')?>" class="back-to-account" title="Geri"></a></h2>
            <div class="body">
				<?php if ($playerInfo->count <= 0):?>
					<?=Client::alert('warning',$lng[107]);?>
				<?php else:?>
					<?php foreach ($playerInfo->data as $player):?>
						<?php
						$bugHash = md5($player->name.$randomKey);
						?>
                        <a href="<?=URI::get_path('profile/saved/'.$player->id);?>">
                            <div id="profileBox" class="player-table">
                                <div class="player-row">
                                    <img src="<?=URL.'data/chrs/medium/'.$player->job.'.png'?>" alt="<?=Functions::jobName($player->job);?>" style="    display: block;margin-left: auto;margin-right: auto;">
                                    <center>
                                        <span style="font: normal 18px 'Palatino Linotype', 'Times', serif; text-transform: none;color: wheat"><?=$player->name?></span>
                                    </center>
                                    <br>
                                    <center>
                                        <span><?=$lng[109]?> : <?=Functions::map($player->map_index);?></span>
                                    </center>
                                    <br>
                                    <a href="<?=URI::get_path('profile/saved/'.$player->name.'/'.$bugHash);?>">
                                        <span style="margin-left: 40%;" class="warfg_btn"><input type="submit" name="login_submit" value="<?=$lng[110]?>"></span>
                                    </a>
                                </div>
                            </div>
                        </a>
					<?php endforeach;?>
				<?php endif;?>
            </div>
        </article>
    </div>
</aside>