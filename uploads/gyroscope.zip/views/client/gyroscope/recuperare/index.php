<aside id="right">
    <div id="content_ajax">
        <article class="page_article">
            <h2 class="head"><?=$lng[25]?></h2>
            <div class="body">
                <div class="error-holder">
                    <div class="container_3 red wide fading-notification" align="left">
						<?php if (isset($aid)):?>
							<?= Client::alert('error',$lng[74]);?>
						<?php else:?>
                    </div>
                </div>
                <form id="forgetPasswordForm" action="<?=URI::get_path('recuperare/control')?>" method="post" accept-charset="utf-8" class="page_form" autocomplete="off">
                    <table style="width:500px;">
                        <tr>
                            <td><label for="account_id"><?=$lng[22]?> :</label></td>
                            <td>
                                <span class="warfg_input" style=""><input type="text" name="login" value="" placeholder="<?=$lng[22]?>"></span>

                            </td>
                        </tr>
                        <tr>
                            <td><label for="account_password"><?=$lng[78]?> :</label></td>
                            <td>
                                <span class="warfg_input" style=""><input type="text" name="email" value="" placeholder="<?=$lng[78]?>"></span>
                            </td>
                        </tr>
                        <tr>
                            <td><label for="account_password"><?=$lng[24]?> :</label></td>
                            <td>
								<?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                            </td>
                        </tr>
                        <tr>
                            <td></td>
                            <td>
                                <span class="warfg_btn"><input type="submit" name="login_submit" value="<?=$lng[79]?>"></span>
                            </td>
                        </tr>
                    </table>
                </form>
				<?php endif;?>
            </div>
        </article>
    </div>
</aside>
<script>
    $("#forgetPasswordForm").on("submit", function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                grecaptcha.reset();
                if (response.result)
                    successNotify(response.message);
                else
                    errorNotify(response.message);
            }
        });
    });
</script>