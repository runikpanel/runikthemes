<aside id="right">
    <div id="content_ajax">
        <article class="page_article">
            <h2 class="head"><?=$lng[73]?></h2>
            <div class="body">
				<?php if (isset($aid)):?>
                    <div class="error-holder">
                        <div class="container_3 red wide fading-notification" align="left">
							<?= Client::alert('error',$lng[74]);?>
                        </div>
                    </div>
				<?php else:?>
                <form id="forgetAccountForm" action="<?=URI::get_path('recuperare/control2')?>" method="post" accept-charset="utf-8" class="page_form" autocomplete="off">
                    <table style="width:500px;">
                        <tr>
                            <td><label for="account_id"><?=$lng[78]?> :</label></td>
                            <td>
                                <span class="warfg_input" style=""><input type="text" name="email" value="" placeholder="<?=$lng[78]?>"></span>

                            </td>
                        </tr>
                        <tr>
                            <td><label for="account_password"><?=$lng[24]?> :</label></td>
                            <td>
								<?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                            </td>
                        </tr>
                        <tr>
                            <td></td>
                            <td>
                                <span class="warfg_btn"><input type="submit" name="login_submit" value="<?=$lng[79]?>"></span>
                            </td>
                        </tr>
                    </table>
                </form>
				<?php endif;?>
            </div>
        </article>
    </div>
</aside>
<script>
    $("#forgetAccountForm").on("submit", function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                grecaptcha.reset();
                if (response.result)
                    successNotify(response.message);
                else
                    errorNotify(response.message);
            }
        });
    });
</script>