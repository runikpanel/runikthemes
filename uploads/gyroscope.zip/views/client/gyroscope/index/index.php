<aside id="right">
    <div id="slider_bg">
        <div id="slider">
            <a href="#">
                <img src="<?=URI::public_path('asset/slider/1.jpg')?>" style="height: 266px; width: 100%;">
            </a>
            <a href="#">
                <img src="<?=URI::public_path('asset/slider/2.jpg')?>" style="height: 266px; width: 100%;">
            </a>
            <a href="#">
                <img src="<?=URI::public_path('asset/slider/3.jpg')?>" style="height: 266px; width: 100%;">
            </a>
        </div>
    </div>
    <div id="content_ajax">
        <!-- Latest News Header -->
        <div class="news_container">
            <div class="container_left">
				<?=$lng[62]?>
            </div>
            <!-- Latest News Header.End -->
        </div>
		<?php Cache::open('patch');?>
		<?php if (Cache::check('patch')):?>
            <?php $newsList = $this->all['patch']; ?>
			<?php foreach ($newsList->data as $news):?>
        <article class="news_article">
            <h2 class="news_head">
                <a href="<?=URI::get_path('patch/view/'.$news->id)?>"><?=$news->title;?></a>
                <span><a href="javascript:void(0)"><?=$lng[64]?> :</a> <?=Functions::prettyDateTime1($news->tarih)?> </span>
            </h2>
            <div class="news_body">
                <div class="news_content">
                    <p><span style="text-align: center;"><?=$news->content2;?></span><br></p>
                    <a class="readn_ln" href="<?=URI::get_path('patch/view/'.$news->id)?>"><?=$lng[63]?></a>
                </div>
                <div class="comments"></div>
            </div>
        </article>
			<?php endforeach; ?>
		<?php endif;?>
		<?php Cache::close('patch');?>
    </div>
</aside>
<?php if (\StaticDatabase\StaticDatabase::settings('facebook_like_status')):?>
    <div class="fbBoard fbBoard2" id="facebookLike">
        <center>

            <a href="<?=\StaticDatabase\StaticDatabase::settings('facebook')?>" target="_blank">
                <div class="facebook-like">
                    <img src="<?=URI::public_path('asset/images/like-background.png')?>" alt="">
                    <a href="javascript:void(0)" onclick="document.getElementById('facebookLike').style.display='none';" style="display:block;width:23px;height:23px;margin:0px;padding:0px;border:none;background-color:transparent;position:absolute;top:23px;right:70px;-webkit-border-radius: 12px;border-radius: 12px;"></a>

                    <iframe src="https://www.facebook.com/plugins/like.php?href=<?=\StaticDatabase\StaticDatabase::settings('facebook')?>&amp;send=false&amp;layout=button_count&amp;width=120&amp;show_faces=false&amp;action=like&amp;colorscheme=light&amp;font=segoe+ui&amp;height=30&amp;appId=515295435153698" scrolling="no" frameborder="0" style="position:absolute;bottom:82px;right:104px;border:none; overflow:hidden; width:98px; height:21px;" allowtransparency="true"></iframe>


                </div>
            </a>
        </center>
    </div>
    <script>
        var isMobile = {
            Android: function() {
                return navigator.userAgent.match(/Android/i);
            },
            BlackBerry: function() {
                return navigator.userAgent.match(/BlackBerry/i);
            },
            iOS: function() {
                return navigator.userAgent.match(/iPhone|iPad|iPod/i);
            },
            Opera: function() {
                return navigator.userAgent.match(/Opera Mini/i);
            },
            Windows: function() {
                return navigator.userAgent.match(/IEMobile/i);
            },
            any: function() {
                return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows());
            }
        };
        if(isMobile.any()) {
            //some code...
            document.getElementById('facebookLike').style.display = 'none';
        }
    </script>
<?php endif;?>
