<aside id="right">
    <div id="content_ajax">
        <article class="page_article">
            <h2 class="head">Kayıt Ol</h2>
            <div class="body">
                <div class="error-holder">
                    <div class="container_3 red wide fading-notification" align="left">
                    </div>
                </div>
				<?php if (\StaticDatabase\StaticDatabase::settings('register_status') == "0"):?>
					<?php echo Client::alert('error','Kayıtlarımız şuanda kapalıdır!');?>
				<?php else:?>
                    <form id="registerForm" action="<?=URI::get_path('register/control')?>" method="POST" class="page_form" autocomplete="off">
                        <div class="bg-light">
                            <table>
                                <tbody>
                                <tr>
                                    <td style="width: 150px;">
                                        <label class="register-input" for="login"><?=$lng[22]?>:</label>
                                    </td>
                                    <td>
                                        <input type="text" class="form-control grunge" name="login" id="login" required maxlength="16" onkeypress="return textonly(event,'#login')"/>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label class="register-input" for="password"><?=$lng[23]?>:</label>
                                    </td>
                                    <td>
                                        <input type="password" class="form-control grunge" name="password" id="password" required maxlength="30"/>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label class="register-input" for="password2"><?=$lng[94]?>:</label>
                                    </td>
                                    <td>
                                        <input type="password" class="form-control grunge" name="password2" id="password2" required maxlength="30"/>
                                    </td>
                                </tr>
								<?php if (\StaticDatabase\StaticDatabase::settings('pin_status') === "1"): ?>
                                    <tr>
                                        <td>
                                            <label class="register-input" for="pin">PIN:</label>
                                        </td>
                                        <td>
                                            <input type="password" class="form-control grunge" name="pin" id="pin" onkeypress="return numberonly(event,this)" required maxlength="<?=\StaticDatabase\StaticDatabase::settings('pin_count')?>"/>
                                        </td>
                                    </tr>
								<?php endif;?>
                                <tr>
                                    <td>
                                        <label class="register-input" for="email"><?=$lng[78]?>:</label>
                                    </td>
                                    <td>
                                        <input type="email" class="form-control grunge" name="email" id="email" required/>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label class="register-input" for="name"><?=$lng[95]?>:</label>
                                    </td>
                                    <td>
                                        <input id="name" type="text" name="name" class="form-control grunge" onkeypress="return textonly2(event,'#name')" maxlength="30" required />
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label class="register-input" for="ksk"><?=$lng[96]?>:</label>
                                    </td>
                                    <td>
                                        <input id="ksk" type="text" name="ksk" class="form-control grunge" onkeypress="return numberonly(event,'#ksk')" maxlength="7" required />
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label class="register-input" for="phone"><?=$lng[97]?>:</label>
                                    </td>
                                    <td>
                                        <input type="text" id="phone" name="phone" class="form-control grunge" onkeypress="return numberonly(event,'#phone')" maxlength="10" required placeholder="555-555-55-55"/>
                                    </td>
                                </tr>
								<?php if (\StaticDatabase\StaticDatabase::settings('findme_status') === "1"): ?>
                                <tr>
									<?php
									$findMeList = \StaticDatabase\StaticDatabase::init()->prepare("SELECT * FROM findme_list");
									$findMeList->execute();
									?>
                                    <td>
                                        <label class="register-input" for="findme">Bizi nerden buldunuz?:</label>
                                    </td>
                                    <td>
                                        <select name="findme">
                                            <option value="0" selected>Lütfen seçiniz...</option>
											<?php foreach ($findMeList->fetchAll(PDO::FETCH_ASSOC) as $row):?>
                                                <option value="<?=$row["id"]?>"><?=$row["name"]?></option>
											<?php endforeach;?>
                                        </select>
                                    </td>
                                </tr>
								<?php endif;?>
                                <tr>
                                    <td>
                                        <label class="register-input" for="recaptcha"><?=$lng[24]?>:</label>
                                    </td>
                                    <td>
										<?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                    </td>
                                    <td>
                                        <div style="margin-bottom: 20px;">
                                            <span>Kayıt olarak <a href="<?=URI::get_path('privacy/index')?>" target="_blank" style="color: wheat;">üyelik sözleşmesini</a> kabul ederim.</span>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td>
                                        <span class="warfg_btn">
                                            <input type="submit" name="register" value="<?=$lng[10]?>">
                                        </span>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </form>
                <?php endif;?>
            </div>
        </article>
    </div>
</aside>
<script>
    $('#pass2').change(function () {
        var pass = $('#pass').val();
        var pass2 = $(this).val();
        if(pass != pass2){
            document.getElementById('passOk').style.display = "none";
            document.getElementById('passNo').style.display = "";
            $('#pass2').notify(
                "Şifreler uyuşmuyor !",
                { position:"right" }
            );
        }else{
            document.getElementById('passNo').style.display = "none";
            document.getElementById('passOk').style.display = "";
        }
    });

    $("#registerForm").on("submit", function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                if (response.result)
                {
                    successNotify(response.message);
                    setTimeout(function () {
                        window.location.href = response.redirect;
                    },2000)
                }
                else
                {
                    errorNotify(response.message);
                    grecaptcha.reset();
                }
            }
        });
    });
</script>