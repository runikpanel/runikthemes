<!DOCTYPE html>
<html>
<head>

    <!-- Meta start -->
    <meta charset="UTF-8">
    <meta name="robots" content="follow, index"/>
    <meta http-equiv="Content-Language" content="pl"/>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <base href="<?=URL?>">
    <title><?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> - <?=\StaticDatabase\StaticDatabase::settings('slogan')?></title>
    <!-- /meta start -->

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="<?=URL?>favicon.ico" sizes="16x16" />
    <!-- /favicon -->

    <!-- Meta -->
    <meta name="keywords" content="metin2, <?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?>, emek, medium, metin, pvp server metin2"/>
    <meta name="description" content="<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> pvp server Metin2 emek/zor."/>
    <!-- /meta -->

    <!-- OpenGraph tags (espec. Facebook) -->
    <meta property="og:type" content="article"/>
    <meta property="og:url" content="<?=URL?>"/>
    <meta property="og:title" content="<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> - Metin2 PVP Server"/>
    <meta property="og:description" content="<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?>-<?=\StaticDatabase\StaticDatabase::settings('slogan')?>. Uzun süre boyunca, hoş dengeli ve ilginç oyun sunuyoruz!"/>
    <meta property="og:image" content="<?=\StaticDatabase\StaticDatabase::settings('logo')?>"/>
    <!-- /openGraph tags -->


    <link rel="stylesheet" href="<?=URI::public_path()?>asset/css/default.css" type="text/css"/>
    <link rel="stylesheet" href="<?=URI::public_path()?>asset/css/cms.css" type="text/css"/>
    <link rel="stylesheet" href="<?=URI::public_path()?>asset/css/main.css" type="text/css"/>
    <link rel="stylesheet" type="text/css" href="<?=URI::public_path()?>asset/css/selectbox.css"/>
    <link rel="stylesheet" type="text/css" href="<?=URI::public_path()?>asset/css/radiocheck.css"/>
    <link rel="stylesheet" type="text/css" href="<?=URI::public_path()?>asset/css/shadowbox.css"/>
    <link rel="stylesheet" type="text/css" href="<?=URI::public_path()?>asset/css/loginbox.css"/>
    <link rel="stylesheet" href="<?=URI::public_path()?>asset/css/rankings.css"/>
    <link rel="stylesheet" href="<?=URI::public_path()?>asset/css/popup.css"/>
    <link rel="stylesheet" href="<?=URI::public_path()?>asset/css/jquery.modal.css"/>
    <link rel="stylesheet" href="<?=URI::public_path()?>asset/css/basscss.min.css"/>
    <link href="<?=URI::public_path('')?>asset/css/fancybox.css" rel="stylesheet" type="text/css" media="screen"/>
    <link rel="stylesheet" type="text/css" href="<?=URI::public_path('notify/css/notify.css')?>">
    <link rel="stylesheet" type="text/css" href="<?=URI::public_path('notify/css/prettify.css')?>">


    <!-- Needed Footer JS -->

    <script type="text/javascript" src="<?=URI::public_path()?>asset/js/jquery.min.js"></script>
    <script type="text/javascript" src="<?=URI::public_path()?>asset/js/jquery.modal.min.js"></script>

    <script type="text/javascript" src="<?=URI::public_path('asset/js/selectbox.min.js')?>"></script>
    <script type="text/javascript" src="<?=URI::public_path()?>asset/js/footer_include.js"></script>
    <script type="text/javascript" src="<?=URI::public_path()?>asset/js/ui.js"></script>
    <script type="text/javascript" src="<?=URI::public_path()?>asset/js/flux.min.js"></script>
    <script type="text/javascript" src="<?=URI::public_path()?>asset/js/popup.js"></script>
    <script type="text/javascript" src="<?=URI::public_path('')?>asset/js/fancybox.js"></script>
    <script type="text/javascript" src="<?=URI::public_path()?>asset/js/notify.js"></script>
    <script type="text/javascript" src="<?=URI::public_path('notify/js/notify.js')?>"></script>
    <script type="text/javascript" src="<?=URI::public_path('notify/js/prettify.js')?>"></script>
    <script type="text/javascript" src="<?=URI::public_path('notify/js/notify-function.js')?>"></script>

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries --><!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <script type="text/javascript">
        $(document).ready(function () {
            var screenSize = $(window).height();
            var compareW = 767;
            if (screenSize > 0 && screenSize < compareW) {
                var fancy_a = 740;
                var fancy_b = 550;
                var fancy_c = "ishopbg-small";
                var fancy_d = "13px";
                var fancy_e = "3px";
                var fancy_f = "13px";
                var fancy_g = 754;
                var fancy_h = 574;
                var fancy_i = 6;
                var fancy_j = 20;
            }
            else
            {
                var fancy_a = 1016;
                var fancy_b = 655;
                var fancy_c = "ishopbg";
                var fancy_d = "16px";
                var fancy_e = "7px";
                var fancy_f = "16px";
                var fancy_g = 1032;
                var fancy_h = 690;
                var fancy_i = 8;
                var fancy_j = 28;
            }
            var fancybox_css = {
                'outer': {'background': null},
                'close': {'background_image': null, 'height': null, 'right': null, 'top': null, 'width': null}
            };
            $('a.itemshop').fancybox({
                'autoDimensions': false,
                'width': fancy_a,
                'height': fancy_b,
                'padding': 0,
                'scrolling': 'yes',
                'overlayColor': '#000',
                'overlayOpacity': 0.8,
                'onStart': function () {
                    fancybox_css.outer.background = $('#fancybox-outer').css('background');
                    fancybox_css.close.background_image = $('#fancybox-close').css('background-image');
                    fancybox_css.close.height = $('#fancybox-close').css('height');
                    fancybox_css.close.right = $('#fancybox-close').css('right');
                    fancybox_css.close.top = $('#fancybox-close').css('top');
                    fancybox_css.close.width = $('#fancybox-close').css('width');
                    $('#fancybox-outer').css({'background': 'transparent url("<?=URI::public_path('')?>static/images/'+fancy_c+'.png") center center no-repeat'});
                    $('#fancybox-close').css({
                        'background-image': 'none',
                        'cursor': 'pointer',
                        'height': fancy_d,
                        'right': '3px',
                        'top': fancy_e,
                        'width': fancy_f
                    });
                },
                'onComplete': function () {
                    $('#fancybox-inner').css({'top': fancy_j, 'left': fancy_i});
                    $('#fancybox-wrap').css({'width': fancy_g, 'height': fancy_h});
                },
                'onClosed': function () {
                    if (null != fancybox_css.outer.background) {
                        $('#fancybox-outer').css('background', fancybox_css.outer.background);
                    }
                    if (null != fancybox_css.close.background_image) {
                        $('#fancybox-close').css('background-image', fancybox_css.close.background_image);
                    }
                    if (null != fancybox_css.close.height) {
                        $('#fancybox-close').css('height', fancybox_css.close.height);
                    }
                    if (null != fancybox_css.close.right) {
                        $('#fancybox-close').css('right', fancybox_css.close.right);
                    }
                    if (null != fancybox_css.close.top) {
                        $('#fancybox-close').css('top', fancybox_css.close.top);
                    }
                    if (null != fancybox_css.close.width) {
                        $('#fancybox-close').css('width', fancybox_css.close.width);
                    }
                }
            });
        });
    </script>
    <script type="text/javascript">
        var Config = {
            URL: "",
            URL2: "",
            IconURL: "",
            FileURL: "<?=URI::public_path()?>asset/",
            AjaxURL: "",

            Slider: {
                interval: 8000,
                effect: "blinds3d",
                id: "slider_bg"
            },

            Theme: {
                next: "",
                previous: ""
            }
        };

        function search() {
            var keyword = $("input[name=keyword]").val();
            if (keyword.length < 4) {
                UI.alert("Arama yaparken en az 4 karakter girmelisiniz.");
            } else if (keyword.length > 20) {
                UI.alert("Arama yaparken en fazla 20 karakter girmelisiniz.");
            } else {
                $("#search").submit();
            }
        }
        function serverstatus() {
            $.post("ajaxeed9.html?action=serverstatus", function (data) {
                if (data == "1") {
                    $(".rs_online").html('<font color="green">ONLINE</font>');
                } else {
                    $(".rs_online").html('<font color="red">OFFLINE</font>');
                }
            });
        }
    </script>
    <script>
        $(document).ready(function () {
            UI.initialize();
        });
    </script>
</head>