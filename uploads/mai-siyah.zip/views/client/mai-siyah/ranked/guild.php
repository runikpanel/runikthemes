<div class="row">
    <div class="col-md-9 normal-content">
        <div class="row">
            <div class="col-md-3">
                <ul id="ranking-menu" class="rankings-nav" style="margin-top: 10px">
                    <li>
                        <a href="<?=URI::get_path('ranked/player')?>" data-type="playerrank">
                            <span class="img char">p</span>
                            <span>Oyuncu Sıralaması</span>
                        </a>
                    </li>
                    <li class="active">
                        <a href="<?=URI::get_path('ranked/guild')?>" data-type="guildrank">
                            <span class="img guild">g</span>
                            <span>Lonca Sıralaması</span>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="col-md-9">
                <div class="rank-img rank-img-chars">
                    <h3 id="ranking-title">Lonca Sıralaması</h3>
                </div>
                <div id="ajaxLoader">
                    <div id="ranking-result" style="margin-top: 18px;"><div class="container-tab rankings-cont">
						<?php if (\StaticDatabase\StaticDatabase::settings('guild_rank_status') == "0"):?>
                            <?php  echo Client::alert('error',"Lonca sıralaması şuanda kapalı!");?>
                        <?php else:?>
                            <table class="table table-rankings">
                                    <thead>
                                    <tr>
                                        <td>#</td>
                                        <td><?=$lng[46]?></td>
                                        <td><?=$lng[47]?></td>
                                        <td><?=$lng[48]?></td>
                                        <td><?=$lng[44]?></td>
                                        <td><?=$lng[49]?></td>
                                        <td><?=$lng[50]?></td>
                                        <td><?=$lng[51]?></td>
                                    </tr>
                                    </thead>
                                    <tbody>
									<?php Cache::open('guilds');?>
									<?php if (Cache::check('guilds')):?>
										<?php foreach ($this->all->data as $key => $guild):?>
                                            <tr>
                                                <td><span class="badge-rank rank-<?=($key+1)?>"><?=($key+1)?></span></td>
                                                <td>
                                                    <a href="<?=URI::get_path('detail/guild/'.$guild->lonca)?>" title="<?=$guild->lonca?>" rel="np" class="icon-profile link-first">
                                                        <center><span><?=$guild->lonca?></span></center>
                                                    </a>
                                                </td>
                                                <td><?=$guild->ladder_point?></td>
                                                <td><img class="class-portrait" src="<?=URL.'data/flags/'.$guild->bayrak.'.jpg'?>"/></td>
                                                <td><a href="<?=URI::get_path('detail/player/'.$guild->baskan)?>" rel="np" class="icon-profile link-first">
                                                        <center><span><?=$guild->baskan;?></span></center>
                                                    </a></td>
                                                <td><center style="color: green"><?=$guild->win?></center></td>
                                                <td>
                                                    <center><?=$guild->draw?></center>
                                                </td>
                                                <td class="cell-CompletedTime">
                                                    <center style="color: red"><?=$guild->loss?></center>
                                                </td>
                                            </tr>
										<?php endforeach;?>
									<?php endif;?>
									<?php Cache::close('guilds');?>
                                    </tbody>
                                </table>
                        <?php endif;?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
