<!DOCTYPE html>
<html>
<head>
    <!-- Meta start -->
    <meta charset="UTF-8">
    <meta name="robots" content="follow, index"/>
    <meta http-equiv="Content-Language" content="pl"/>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <base href="<?=URL?>">
    <title><?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> - <?= \StaticDatabase\StaticDatabase::settings('slogan')?></title>
    <!-- /meta start -->

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="<?=URL.'favicon.ico'?>" sizes="16x16" />
    <!-- /favicon -->

    <!-- Meta -->
    <meta name="keywords" content="metin2, <?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?>, emek, medium, metin, pvp server metin2"/>
    <meta name="description" content="<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> pvp server Metin2 emek/zor."/>
    <!-- /meta -->

    <!-- OpenGraph tags (espec. Facebook) -->
    <meta property="og:type" content="article"/>
    <meta property="og:url" content="<?=URL?>"/>
    <meta property="og:title" content="<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> - Metin2 PVP Server"/>
    <meta property="og:description" content="<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?>-Metin2 PVP Server. Uzun süre boyunca, hoş dengeli ve ilginç oyun sunuyoruz!"/>
    <meta property="og:image" content="<?=URL.\StaticDatabase\StaticDatabase::settings('logo')?>"/>
    <!-- /openGraph tags -->

    <link rel="stylesheet" href="<?=URI::public_path()?>media/css/styles.css">
    <link rel="stylesheet" href="<?=URI::public_path()?>media/css/alertify.css">
    <link rel="stylesheet" href="<?=URI::public_path()?>media/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?=URI::public_path()?>media/css/bootstrap-social.css">
    <link rel="stylesheet" href="<?=URI::public_path()?>media/css/jquery.bxslider.min.css">
    <link rel="stylesheet" href="<?=URI::public_path()?>media/css/flag-icon.min.css">
    <link rel="stylesheet" href="<?=URI::public_path()?>media/css/fancybox.css"/>
    <link rel="stylesheet" href="<?=URI::public_path()?>media/css/jquery.fancybox.min.css"/>
    <link rel="stylesheet" type="text/css" href="<?=URI::public_path()?>notify/css/notify.css">
    <link rel="stylesheet" type="text/css" href="<?=URI::public_path()?>notify/css/prettify.css">

    <script type="text/javascript" src="<?=URI::public_path()?>media/javascripts/jquery-2.1.4.min.js"></script>
    <script type="text/javascript" src="<?=URI::public_path()?>media/javascripts/bootstrap.min.js"></script>
    <script type="text/javascript" src="<?=URI::public_path()?>media/javascripts/alertify.js"></script>
    <script type="text/javascript" src="<?=URI::public_path()?>media/javascripts/jquery-ui.js"></script>
    <script type="text/javascript" src="<?=URI::public_path()?>media/javascripts/jquery.bxslider.min.js"></script>
    <script type="text/javascript" src="<?=URI::public_path()?>media/javascripts/jquery.blockUI.js"></script>
    <script type="text/javascript" src="<?=URI::public_path()?>media/javascripts/script.js"></script>
    <script type="text/javascript" src="<?=URI::public_path()?>media/javascripts/fancybox.js"></script>
    <script type="text/javascript" src="<?=URI::public_path()?>media/javascripts/jquery.fancybox.min.js"></script>
    <script type="text/javascript" src="<?=URI::public_path()?>media/javascripts/notify.js"></script>
    <script type="text/javascript" src="<?=URI::public_path()?>notify/js/notify.js"></script>
    <script type="text/javascript" src="<?=URI::public_path()?>notify/js/prettify.js"></script>
    <script type="text/javascript" src="<?=URI::public_path()?>notify/js/notify-function.js"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            var screenSize = $(window).height();
            var compareW = 767;
            if (screenSize > 0 && screenSize < compareW) {
                var fancy_a = 740;
                var fancy_b = 550;
                var fancy_c = "ishopbg-small";
                var fancy_d = "13px";
                var fancy_e = "3px";
                var fancy_f = "13px";
                var fancy_g = 754;
                var fancy_h = 574;
                var fancy_i = 6;
                var fancy_j = 20;
            }
            else
            {
                var fancy_a = 1016;
                var fancy_b = 655;
                var fancy_c = "ishopbg";
                var fancy_d = "16px";
                var fancy_e = "7px";
                var fancy_f = "16px";
                var fancy_g = 1032;
                var fancy_h = 690;
                var fancy_i = 8;
                var fancy_j = 28;
            }
            var fancybox_css = {
                'outer': {'background': null},
                'close': {'background_image': null, 'height': null, 'right': null, 'top': null, 'width': null}
            };
            $('a.itemshop').fancybox({
                'autoDimensions': false,
                'width': fancy_a,
                'height': fancy_b,
                'padding': 0,
                'scrolling': 'yes',
                'overlayColor': '#000',
                'overlayOpacity': 0.8,
                'onStart': function () {
                    fancybox_css.outer.background = $('#fancybox-outer').css('background');
                    fancybox_css.close.background_image = $('#fancybox-close').css('background-image');
                    fancybox_css.close.height = $('#fancybox-close').css('height');
                    fancybox_css.close.right = $('#fancybox-close').css('right');
                    fancybox_css.close.top = $('#fancybox-close').css('top');
                    fancybox_css.close.width = $('#fancybox-close').css('width');
                    $('#fancybox-outer').css({'background': 'transparent url("<?=URI::public_path('')?>static/images/'+fancy_c+'.png") center center no-repeat'});
                    $('#fancybox-close').css({
                        'background-image': 'none',
                        'cursor': 'pointer',
                        'height': fancy_d,
                        'right': '3px',
                        'top': fancy_e,
                        'width': fancy_f
                    });
                },
                'onComplete': function () {
                    $('#fancybox-inner').css({'top': fancy_j, 'left': fancy_i});
                    $('#fancybox-wrap').css({'width': fancy_g, 'height': fancy_h});
                },
                'onClosed': function () {
                    if (null != fancybox_css.outer.background) {
                        $('#fancybox-outer').css('background', fancybox_css.outer.background);
                    }
                    if (null != fancybox_css.close.background_image) {
                        $('#fancybox-close').css('background-image', fancybox_css.close.background_image);
                    }
                    if (null != fancybox_css.close.height) {
                        $('#fancybox-close').css('height', fancybox_css.close.height);
                    }
                    if (null != fancybox_css.close.right) {
                        $('#fancybox-close').css('right', fancybox_css.close.right);
                    }
                    if (null != fancybox_css.close.top) {
                        $('#fancybox-close').css('top', fancybox_css.close.top);
                    }
                    if (null != fancybox_css.close.width) {
                        $('#fancybox-close').css('width', fancybox_css.close.width);
                    }
                }
            });
        });
    </script>
</head>


