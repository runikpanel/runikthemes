<div class="page-header">
    <h2 class="page-title">404 Not Found</h2>
</div>
<div class="col-md-9 normal-content">
    <div class="row">
        <ol class="breadcrumb grunge">
            <li><a href="<?=URI::get_path('index');?>">Anasayfa</a></li>
            <li class="active">404 Not Found</li>
        </ol>
    </div>
    <div class="col-sm-12 panel panel-grunge download-box">
        <div class="panel-body">
            <i class="fa fa-warning"></i>
            <h4><?=$lng[60]?> </h4>
        </div>
    </div>
</div>