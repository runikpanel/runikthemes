<div class="row">
    <div class="col-md-9 normal-content">
        <div class="col-md-12 no-padding-all">
            <center><h3><?=$lng[10];?></h3></center>
            <h2 class="brackets"></h2>
        </div>
    <div class="col-md-12">
		<?php if (\StaticDatabase\StaticDatabase::settings('register_status') == "0"):?>
			<?php echo Client::alert('error','Kayıtlarımız şuanda kapalıdır!');?>
		<?php else:?>
            <form id="registerForm" action="<?=URI::get_path('register/control')?>" method="post" class="form-horizontal" autocomplete="off">
                <div class="form-group has-feedback">
                    <label for="login" class="col-sm-4 control-label"><?=$lng[22]?> <span
                                class="text-danger">*</span></label>

                    <div class="col-sm-6">
                        <input type="text" class="form-control grunge" name="login" id="login" required maxlength="16" onkeypress="return textonly(event,'#login')"/>
                        <i class="fa fa-user form-control-feedback"></i>
                    </div>
                </div>
                <div class="form-group has-feedback">
                    <label for="password" class="col-sm-4 control-label"><?=$lng[23]?> <span
                                class="text-danger">*</span></label>

                    <div class="col-sm-6">
                        <input type="password" class="form-control grunge" name="password" id="password" required maxlength="30"/>
                        <i class="fa fa-lock form-control-feedback"></i>
                    </div>
                </div>
                <div class="form-group has-feedback">
                    <label for="password2" class="col-sm-4 control-label"><?=$lng[94]?> <span
                                class="text-danger">*</span></label>

                    <div class="col-sm-6">
                        <input type="password" class="form-control grunge" name="password2" id="password2" required maxlength="30"/>
                        <i class="fa fa-lock form-control-feedback"></i>
                    </div>
                </div>
				<?php if (\StaticDatabase\StaticDatabase::settings('pin_status') === "1"): ?>
                    <div class="form-group has-feedback">
                        <label for="pin" class="col-sm-4 control-label">PIN <span
                                    class="text-danger">*</span></label>

                        <div class="col-sm-6">
                            <input type="password" class="form-control grunge" name="pin" id="pin" maxlength="<?=\StaticDatabase\StaticDatabase::settings('pin_count')?>" onkeypress="return numberonly(event,this)" required/>
                            <i class="fa fa-lock form-control-feedback"></i>
                        </div>
                    </div>
				<?php endif;?>
                <div class="form-group has-feedback">
                    <label for="email" class="col-sm-4 control-label"><?=$lng[78]?> <span
                                class="text-danger">*</span></label>

                    <div class="col-sm-6">
                        <input type="email" class="form-control grunge" name="email" id="email" required />
                        <i class="fa fa-envelope form-control-feedback"></i>
                    </div>
                </div>
                <div class="form-group has-feedback">
                    <label for="name" class="col-sm-4 control-label"><?=$lng[95]?> <span
                                class="text-danger">*</span></label>

                    <div class="col-sm-6">
                        <input id="name" type="text" name="name" class="form-control grunge" onkeypress="return textonly2(event,'#name')" maxlength="30" required />
                        <i class="fa fa-edit form-control-feedback"></i>
                    </div>
                </div>
                <div class="form-group has-feedback">
                    <label for="ksk" class="col-sm-4 control-label"><?=$lng[96]?> <span
                                class="text-danger">*</span></label>

                    <div class="col-sm-6">
                        <input id="ksk" type="text" name="ksk" class="form-control grunge" onkeypress="return numberonly(event,'#ksk')" maxlength="7" required />
                        <i class="fa fa-lock form-control-feedback"></i>
                    </div>
                </div>
                <div class="form-group has-feedback">
                    <label for="regpassword" class="col-sm-4 control-label"><?=$lng[97]?> <span
                                class="text-danger"></span></label>

                    <div class="col-sm-6">
                        <input type="text" id="phone" name="phone" class="form-control grunge" onkeypress="return numberonly(event,'#phone')" maxlength="10" required placeholder="555-555-55-55"/>
                        <i class="fa fa-phone form-control-feedback"></i>
                    </div>
                </div>
				<?php if (\StaticDatabase\StaticDatabase::settings('findme_status') === "1"): ?>
                <div class="form-group has-feedback">
					<?php
					$findMeList = \StaticDatabase\StaticDatabase::init()->prepare("SELECT * FROM findme_list");
					$findMeList->execute();
					?>
                    <label for="findme" class="col-sm-4 control-label">Bizi nerden buldunuz? <span
                                class="text-danger"></span></label>

                    <div class="col-sm-6">
                        <select name="findme" class="form-control grunge">
                            <option value="0" selected>Lütfen seçiniz...</option>
							<?php foreach ($findMeList->fetchAll(PDO::FETCH_ASSOC) as $row):?>
                                <option value="<?=$row["id"]?>"><?=$row["name"]?></option>
							<?php endforeach;?>
                        </select>
                    </div>
                </div>
				<?php endif;?>
                <div class="form-group has-feedback">
                    <label for="recaptcha" class="col-sm-4 control-label"><?=$lng[24]?> <span
                                class="text-danger">*</span></label>

                    <div class="col-sm-6">
						<?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6 col-sm-offset-4">
                        <div style="    margin-top: -20px;
    margin-bottom: 20px;"><span>Kayıt olarak <a href="<?=URI::get_path('privacy/index')?>" target="_blank" style="color: wheat;">üyelik sözleşmesini</a> kabul ederim.</span></div>
                    </div>
                </div>
                <div class="row">
                    <div class="form-inline col-sm-offset-4 col-sm-8">
                        <button type="submit" class="btn btn-grunge"><?=$lng[10]?></button>
                    </div>
                </div>
            </form>
        <?php endif;?>
    </div>
</div>
<script>
    $('#pass2').change(function ()
    {
        var pass = $('#pass').val();
        var pass2 = $(this).val();

        if(pass !== pass2)
        {
            document.getElementById('passOk').style.display = "none";
            document.getElementById('passNo').style.display = "";
            $('#pass2').notify(
                "Şifreler uyuşmuyor !",
                { position:"right" }
            );
        }
        else
        {
            document.getElementById('passNo').style.display = "none";
            document.getElementById('passOk').style.display = "";
        }
    });

    $("#registerForm").on("submit", function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                if (response.result)
                {
                    successNotify(response.message);
                    setTimeout(function () {
                        window.location.href = response.redirect;
                    },2000)
                }
                else
                {
                    errorNotify(response.message);
                    grecaptcha.reset();
                }
            }
        });
    });
</script>