<?php $status = $this->all['result']; ?>
<div class="col-md-9 normal-content">
    <div class="row">
        <ol class="breadcrumb grunge">
            <li><a href="<?=URI::get_path('index')?>"><?=$lng[8]?></a></li>
            <li class="active"><?=$lng[122]?></li>
        </ol>
    </div>
    <div class="col-md-12">
		<?php if(!$status): ?>
			<?= Client::alert('error',$lng[81]);?>
		<?php else:?>
			<?= Client::alert('info',$lng[135]);?>
            <form id="emailChangeForm2" action="<?=URI::get_path('profile/emailchange3')?>" method="post" class="form-horizontal" autocomplete="off">
                <div class="form-group has-feedback">
                    <label for="regpassword" class="col-sm-4 control-label"><?=$lng[23]?> <span
                            class="text-danger">*</span></label>

                    <div class="col-sm-5">
                        <input type="password" class="form-control grunge" name="password" id="password" required/>
                        <i class="fa fa-lock form-control-feedback"></i>
                    </div>
                </div>
                <div class="form-group has-feedback">
                    <label for="newMail" class="col-sm-4 control-label"><?=$lng[133]?> <span
                            class="text-danger">*</span></label>

                    <div class="col-sm-5">
                        <input type="email" class="form-control grunge" name="new_mail" id="newMail" required/>
                        <i class="fa fa-lock form-control-feedback"></i>
                    </div>
                </div>
                <div class="form-group has-feedback">
                    <label for="reMail" class="col-sm-4 control-label"><?=$lng[134]?> <span
                            class="text-danger">*</span></label>

                    <div class="col-sm-5">
                        <input type="email" class="form-control grunge" name="re_mail" id="reMail" required/>
                        <i class="fa fa-lock form-control-feedback"></i>
                    </div>
                </div>
                <div class="form-group has-feedback">
                    <label for="reCaptcha" class="col-sm-4 control-label"><?=$lng[24]?> <span
                            class="text-danger">*</span></label>

                    <div class="col-sm-5">
                        <?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                    </div>
                </div>
                <div class="row">
                    <div class="form-inline col-sm-offset-4 col-sm-8">
                        <button type="submit" class="btn btn-grunge"><?=$lng[122]?></button>
                    </div>
                </div>
            </form>
        <?php endif;?>
    </div>
</div>
<script>
    $("#emailChangeForm2").on("submit", function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                grecaptcha.reset();
                if (response.result)
                    successNotify(response.message);
                else
                    errorNotify(response.message);
            }
        });
    });
</script>