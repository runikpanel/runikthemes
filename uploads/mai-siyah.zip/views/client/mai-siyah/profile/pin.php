<?php
$isBanned = $this->all["is_banned"];
$mailActive = $this->all["mail_active"];
?>
<div class="col-md-9 normal-content">
    <div class="row">
        <ol class="breadcrumb grunge">
            <li><a href="<?=URI::get_path('index')?>"> <?=$lng[8]?></a></li>
            <li class="active"> PIN Değiştir</li>
        </ol>
    </div>
    <div class="col-md-12">
		<?php if ($isBanned):?>
			<?= Client::alert('error',$lng[112]); ?>
		<?php elseif ($mailActive === "0"):?>
			<?= Client::alert('error',$lng[113])?>
            <a href="<?=URI::get_path('profile/aktive')?>" ><button type="submit" class="center-block btn btn-grunge"><?=$lng[114]?></button></a>
		<?php else:?>
            <form id="pinChangeForm" class="form-horizontal" action="<?=URI::get_path('profile/pinchange')?>" method="post" autocomplete="off">
                <div class="form-group has-feedback">
                    <label for="password" class="col-sm-4 control-label"><?=$lng[23]?> <span
                                class="text-danger">*</span></label>

                    <div class="col-sm-5">
                        <input type="password" class="form-control grunge" name="password" id="password"/>
                        <i class="fa fa-lock form-control-feedback"></i>
                    </div>
                </div>
                <div class="form-group has-feedback">
                    <label for="reCaptcha" class="col-sm-4 control-label"><?=$lng[24]?> <span
                                class="text-danger">*</span></label>

                    <div class="col-sm-5">
						<?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                    </div>
                </div>
                <div class="row">
                    <div class="form-inline col-sm-offset-4 col-sm-8">
                        <button type="submit" class="btn btn-grunge">Mail Gönder</button>
                    </div>
                </div>
            </form>
		<?php endif;?>
    </div>
</div>
<script>
    $("#pinChangeForm").on("submit", function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                grecaptcha.reset();
                if (response.result)
                    successNotify(response.message);
                else
                    errorNotify(response.message);
            }
        });
    });
</script>