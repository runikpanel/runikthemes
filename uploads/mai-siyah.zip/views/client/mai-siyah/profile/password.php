<?php $isBanned = $this->all["is_banned"];?>
<div class="col-md-9 normal-content">
    <div class="row">
        <ol class="breadcrumb grunge">
            <li><a href="<?=URI::get_path('index')?>">Anasayfa</a></li>
            <li class="active">Sifre Degistir</li>
        </ol>
    </div>
    <div class="col-md-12">
		<?php if ($isBanned):?>
			<?= Client::alert('error', $lng[112]);?>
		<?php else:?>
        <form id="passwordChangeForm" class="form-horizontal" action="<?=URI::get_path('profile/passwordchange')?>" method="POST"  autocomplete="off">
            <div class="form-group has-feedback">
                <label for="oldPassword" class="col-sm-4 control-label"><?=$lng[165]?> <span
                        class="text-danger">*</span></label>

                <div class="col-sm-5">
                    <input type="password" class="form-control grunge" name="old_password" maxlength="16" required>
                    <i class="fa fa-lock form-control-feedback"></i>
                </div>
            </div>
            <div class="form-group has-feedback">
                <label for="newPassword" class="col-sm-4 control-label"><?=$lng[166]?> <span
                        class="text-danger">*</span></label>

                <div class="col-sm-5">
                    <input type="password" class="form-control grunge" name="new_password" maxlength="16" required>
                    <i class="fa fa-lock form-control-feedback"></i>
                </div>
            </div>
            <div class="form-group has-feedback">
                <label for="rePassword" class="col-sm-4 control-label"><?=$lng[167]?> <span
                        class="text-danger">*</span></label>

                <div class="col-sm-5">
                    <input type="password" class="form-control grunge" name="re_password" maxlength="16" required>
                    <i class="fa fa-lock form-control-feedback"></i>
                </div>
            </div>
            <div class="form-group has-feedback">
                <label for="reCaptcha" class="col-sm-4 control-label"><?=$lng[24]?> <span
                        class="text-danger">*</span></label>

                <div class="col-sm-5">
                    <?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                </div>
            </div>
            <div class="row">
                <div class="form-inline col-sm-offset-4 col-sm-8">
                    <button type="submit" class="btn btn-grunge"><?=$lng[141]?></button>
                </div>
            </div>
        </form>
		<?php endif;?>
    </div>
</div>
<script>
    $("#passwordChangeForm").on("submit", function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                grecaptcha.reset();
                if (response.result)
                    successNotify(response.message);
                else
                    errorNotify(response.message);
            }
        });
    });
</script>