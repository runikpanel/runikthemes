<div class="row">
    <div class="col-md-9 normal-content">
        <div class="col-md-12 no-padding-all">
            <center><h3><?=$lng[73]?></h3></center>
            <h2 class="brackets"></h2>
        </div>
    <div class="col-md-12">
		<?php if (isset($aid)):?>
			<?= Client::alert('error',$lng[74]);?>
		<?php else:?>
            <form id="forgetAccountForm" class="form-horizontal" action="<?=URI::get_path('recuperare/control2')?>" method="post" autocomplete="off">
                <div class="form-group has-feedback">
                    <label for="regpassword" class="col-sm-4 control-label"><?=$lng[78]?> <span
                            class="text-danger">*</span></label>

                    <div class="col-sm-5">
                        <input type="text" class="form-control grunge" name="email" id="email" required/>
                        <i class="fa fa-envelope form-control-feedback"></i>
                    </div>
                </div>
                <div class="form-group has-feedback">
                    <label for="regpassword" class="col-sm-4 control-label"><?=$lng[24]?> <span
                            class="text-danger">*</span></label>

                    <div class="col-sm-5">
                        <?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                    </div>
                </div>
                <div class="row">
                    <div class="form-inline col-sm-offset-4 col-sm-8">
                        <button type="submit" class="btn btn-grunge"><?=$lng[79]?></button>
                    </div>
                </div>
            </form>
        <?php endif;?>
    </div>
</div>
    <script>
        $("#forgetAccountForm").on("submit", function (event) {
            event.preventDefault();

            var url = $(this).attr("action");
            var data = $(this).serialize();

            $.ajax({
                url : url,
                type : 'POST',
                data : data,
                dataType : 'json',
                success : function (response) {
                    grecaptcha.reset();
                    if (response.result)
                        successNotify(response.message);
                    else
                        errorNotify(response.message);
                }
            });
        });
    </script>