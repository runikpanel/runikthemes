<?php
$guildInfo = $this->all["info"];
$name = $this->all["name"];
$guildMembers = $this->all["members"];
?>
<div class="row">
    <div class="col-md-9 normal-content">
        <div class="col-md-12 no-padding-all">
            <center><h3><?=$lng[43]?></h3></center>
            <h2 class="brackets"></h2>
        </div>
	<?php Cache::open($name."_guild");?>
	<?php if (Cache::check($name."_guild")):?>
    <div class="col-md-8">
        <div class="equipment-icons" style="float: none;">
            <center><strong><?=$lng[46]?> : <?=$guildInfo->name?></strong></center>
            <?=Functions::bracket()?>
            <center><strong><?=$lng[68]?> : <?=$guildInfo->level?></strong></center>
            <?=Functions::bracket()?>
            <center><strong><?=$lng[47]?> : <?=$guildInfo->ladder_point?></strong></center>
            <?=Functions::bracket()?>
            <center><strong>EXP : <?=$guildInfo->exp?></strong></center>
            <?=Functions::bracket()?>
            <center><strong><img src="<?=URL.'data/flags/'.$guildInfo->empire.'.jpg';?>" alt="<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?>"></strong></center>
            <?=Functions::bracket()?>
            <center><strong><?=$lng[176]?> : <span style="color: #00a8c6"><?=$guildMembers->count;?></span></strong></center>
            <?=Functions::bracket()?>
            <center><strong><?=$lng[49]?> : <span style="color: green"><?=$guildInfo->win?></span></strong></center>
            <?=Functions::bracket()?>
            <center><strong><?=$lng[50]?> : <span style="color: grey"><?=$guildInfo->draw?></span></strong></center>
            <?=Functions::bracket()?>
            <center><strong><?=$lng[51]?> : <span style="color: darkred"><?=$guildInfo->loss?></span></strong></center>
        </div>
    </div>
    <div class="col-md-4">
        <div class="login-cont frame">
            <div class="frame-inner">
                <a href="<?=URI::get_path('detail/player/'.$guildInfo->baskan)?>"><h2 class="char-title ch text-center"><?=$lng[44]?>: <?=$guildInfo->baskan?></h2></a>
                <div class="char-img">
                    <a href="<?=URI::get_path('detail/player/'.$guildInfo->baskan)?>"><img src="<?=URL.'data/chrs/big/'.$guildInfo->job.'/'.Functions::playerPortrait($guildInfo->seviye).'.png'?>" alt="<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?>" style="width:210px"></a>
                    <div class="shadow"></div>
                </div>

            </div>
        </div>
    </div>
	<?php endif;?>
	<?php Cache::close($name."_guild");?>
</div>
