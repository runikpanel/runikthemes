<?php
$name = $this->all["name"];
?>
<div class="row">
    <div class="col-md-9 normal-content">
        <div class="col-md-12 no-padding-all">
            <center><h3><?=$lng[32]?></h3></center>
            <h2 class="brackets"></h2>
        </div>
		<?php Cache::open($name."_player");?>
		<?php if (Cache::check($name."_player")):?>
			<?php
			$info = $this->all["info"];
			$playerInfo = $info->data[0];
			?>
            <div class="col-md-8">
                <div class="equipment-icons" style="float: none;">
                    <center><strong><?=$lng[35]?> : <?=$playerInfo->name?></strong></center>
					<?=Functions::bracket()?>
                    <center><strong><?=$lng[68]?> : <?=$playerInfo->level?></strong></center>
					<?=Functions::bracket()?>
                    <center><strong>EXP : <?=$playerInfo->exp?></strong></center>
					<?=Functions::bracket()?>
                    <center><strong><?=$lng[40]?> : <?=$playerInfo->playtime?> <?=$lng[42]?></strong></center>
					<?=Functions::bracket()?>
                    <center><strong><img src="<?=URL.'data/flags/'.$playerInfo->empire.'.jpg';?>" alt=""></strong></center>
					<?=Functions::bracket()?>
                    <center><strong><?=$lng[38]?> : <?= ($playerInfo->lonca == null) ? 'Yok' : $playerInfo->lonca?></strong></center>
					<?=Functions::bracket()?>
                    <center><strong><?=$lng[39]?> : <?=Functions::prettyDateTime1($playerInfo->last_play)?></strong></center>
					<?=Functions::bracket()?>
                    <center><strong><?=$lng[109]?> : <?=Functions::map($playerInfo->map_index)?></strong></center>
					<?=Functions::bracket()?>
                    <center><strong></strong> <div><img src="<?=URL.'data/chrs/small/'.Functions::playerOnlineStatus($playerInfo->last_play).'.png'?>" alt=""></div></center>
                </div>
            </div>
            <div class="col-md-4">
                <div class="login-cont frame">
                    <div class="frame-inner">
                        <div class="char-img">
                            <img style="width:210px" src="<?=URL.'data/chrs/big/'.$playerInfo->job.'/'.Functions::playerPortrait($playerInfo->level).'.png'?>" alt="" >
                            <div class="shadow"></div>
                        </div>

                    </div>
                </div>
            </div>
		<?php endif;?>
		<?php Cache::close($name."_player");?>
    </div>