<aside id="right">
    <div id="content_ajax">
        <article class="page_article">
			<div class="panel-heading"><h2 class="head"><?=$lng[177]?></h2></div>
            <div class="body">
                <div  style="margin-left:10px;margin-bottom:20px;text-align: center;">
					<a href="<?=URI::get_path('ranked/player')?>"><button class="btn btn-giris"><?=$lng[176]?></button></a>
					<a href="javascript:void(0);"><button class="btn btn-giris"><?=$lng[177]?></button></a>
                    <div class="ucp_divider"></div>
                </div>
				<?php if (\StaticDatabase\StaticDatabase::settings('guild_rank_status') == "0"):?>
					<?php  echo Client::alert('error',"Lonca sıralaması şuanda kapalı!");?>
				<?php else:?>
                    <table id="large" cellspacing="0" class="tablesorter">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th><?=$lng[67]?></th>
                            <th><?=$lng[71]?></th>
                            <th><?=$lng[37]?></th>
                            <th><?=$lng[44]?></th>
                            <th><?=$lng[72]?></th>
                        </tr>
                        </thead>
                        <tbody>
						<?php Cache::open('guilds');?>
						<?php if (Cache::check('guilds')):?>
							<?php foreach ($this->all->data as $key => $guild):?>
                                <tr>
                                    <td><?=($key+1)?></td>
                                    <td><a href="<?=URI::get_path('detail/guild/'.$guild->lonca)?>" title="<?=$guild->lonca?>"><?=$guild->lonca?></a></td>
                                    <td><?=$guild->ladder_point?></td>
                                    <td><img src="<?=URL.'data/flags/'.$guild->bayrak.'.png'?>" alt=""></td>
                                    <td><a rel="nofollow" href="<?=URI::get_path('detail/player/'.$guild->baskan)?>"><?=$guild->baskan;?></a></td>
                                    <td>
                                        <span class="label label-green"><?=$guild->win?></span> |
                                        <span class="label label-draw"><?=$guild->draw?></span> |
                                        <span class="label label-red"><?=$guild->loss?></span>
                                    </td>
                                </tr>
							<?php endforeach;?>
						<?php endif;?>
						<?php Cache::close('guilds');?>
                        </tbody>
                    </table>
                <?php endif;?>
            </div>
        </article>
    </div>
</aside>
