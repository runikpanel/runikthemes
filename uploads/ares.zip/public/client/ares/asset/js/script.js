// JavaScript Document
$(document).ready(function () {
	  // range slider start
    //   $('input[type="range"]').rangeslider({
	// 	polyfill: false
	//   });
	  
	//   $('#alpha-range-slider').on('change input', function() {
	// 	$('#alpha-range-output').text($(this).val());
	//   });
	var valueBubble = '<output class="rangeslider__value-bubble" />';

		var unit = $('input[type="range"]').attr('unit');

		function updateValueBubble(pos, value, context) {
		pos = pos || context.position;
		value = value || context.value;
		var $valueBubble = $('.rangeslider__value-bubble', context.$range);
		var tempPosition = pos + context.grabPos;
		var position = (tempPosition <= context.handleDimension) ? context.handleDimension : (tempPosition >= context.maxHandlePos) ? context.maxHandlePos : tempPosition;

		if ($valueBubble.length) {
			$valueBubble[0].style.left = Math.ceil(position) + 'px';
			$valueBubble[0].innerHTML = value + " ";
		}
		}

		$('input[type="range"]').rangeslider({
		polyfill: false,
		onInit: function() {
			this.$range.append($(valueBubble));
			updateValueBubble(null, null, this);
		},
		onSlide: function(pos, value) {
			updateValueBubble(pos, value, this);
		}
		});
	  // range slider end


	  // custom js start
	  $(".open-detail-link").click(function (e) {
		$(".content-main .left-sidebar").addClass('edit-sidebar');
		$(".inner-illustartion-block").addClass('hidden');
		$(".content-main .right-content").addClass('img-full-right');	
		$(".right-content .first-block-main .first-block-inner .top-content-main").addClass('hidden');
		$(".right-content .first-block-main .first-block-inner .last-text").addClass('hidden');
		$(".right-content .first-block-main .first-block-inner").addClass('full-width-block');
		// $(".right-content .first-block-main").addClass('hidden');
		$(".content-main .right-content .back-arrow").removeClass('hidden');
		$(".left-sidebar .illustartion-edit-block").removeClass('hidden');
		$(".left-sidebar .illustartion-edit-inner").removeClass('hidden');
		// $(".right-content .right-block-open").removeClass('hidden');
		$(".right-content .second-block-main").toggleClass('right-side-hidden');
		$(".right-content .first-block-inner .full-banner").addClass('full-width-banner');

		// $(".right-content .first-block-main").addClass('hidden');
		// $(".right-content .right-block-open .banner-full-img").addClass('img-transform');
	  });
	
	  $(".right-content .back-arrow a").click(function (e) {
		$(".content-main .left-sidebar").removeClass('edit-sidebar');
		$(".inner-illustartion-block").removeClass('hidden');
		$(".content-main .right-content").removeClass('img-full-right');	
		$(".right-content .first-block-main .first-block-inner .top-content-main").removeClass('hidden');
		$(".right-content .first-block-main .first-block-inner .last-text").removeClass('hidden');
		$(".right-content .first-block-main .first-block-inner").removeClass('full-width-block');
		// $(".right-content .first-block-main").addClass('hidden');
		$(".content-main .right-content .back-arrow").addClass('hidden');
		$(".left-sidebar .illustartion-edit-block ").addClass('hidden');
		// $(".right-content .right-block-open").removeClass('hidden');
		$(".right-content .second-block-main").toggleClass('right-side-hidden');
		$(".right-content .first-block-inner .full-banner").removeClass('full-width-banner');
	  });
	  // custom js end
	  $(".inner-illustartion-block, .menu-slide-open-mobile").mCustomScrollbar({
		axis: "y",
		autoHideScrollbar: false,
		mouseWheelPixels: 70,
		scrollInertia: 50,
		setLeft: -100,
		scrollButtons:{
			enable:true
		  }
	  });

	  $(".illustartion-edit-block").mCustomScrollbar({
		axis: "y",
		autoHideScrollbar: false,
		mouseWheelPixels: 70,
		scrollInertia: 50,
		setLeft: -100,
		scrollButtons:{
			enable:true
		  }
	  });
	  // mobile js start
	  $(".mobile-toggle-main a").click(function (e) {
		$(".menu-slide-open-mobile").toggleClass('open');
		// $(".max-width-header").toggleClass('max-width');
		$("body").toggleClass('overflow-body');
		$(this).toggleClass('active');
	  });
	  // mobile js end

	  // slick slider js start
      $('.inner-illustartion-slider').slick({
		dots: false,
        infinite: true,
        centerMode: true,
        slidesToShow: 1,
        item: 1,
        slidesToScroll: 1,
        arrows: false,
        autoplay: true,
        autoplaySpeed: 500000,
		variableWidth: true,
    });
	  // slick slider js end

	  // option js mobile start
	  $(".option-block-main a.open-edit-color").click(function (e) { 
		$(".menu-slide-open-mobile").removeClass('open');
		$(".inner-illustartion-mobile").addClass('hidden');
		$(".content-main .right-content .first-block-inner .vid-btn-group").addClass('hidden');	
		$(".first-block-inner .last-text").addClass('hidden');	
		$(".first-block-inner .text-mobile-date").addClass('hidden');	
		$(".illustartion-edit-inner").removeClass('hidden');	
		$(".illustartion-edit-inner").removeClass('open');	
		$(".illustartion-edit-block .verticle-toggle-bar").addClass('active');	
		$(".illustartion-edit-block .lanscape-toggle-bar").addClass('active');	
		$("body").addClass('height-full-body');	
		$(".content-main .left-sidebar").addClass('height-none');
		$(".first-block-inner .full-banner").toggleClass("height-resize");	
		$(".mobile-toggle-main a").removeClass("active");	
		// $("body").addClass('hidden');	
	  });
	  $(".verticle-toggle-bar a").click(function (e) { 
		// $(".illustartion-edit-block").toggle("open");
		$(".illustartion-edit-block").toggleClass("open");
		$(".first-block-inner .full-banner").toggleClass("height-resize");
		$(".first-block-inner .full-banner").toggleClass("height-resize-small");
		$(this).toggleClass('active');
		// 
	  });

	  // landscape view js start

	  $(".lanscape-toggle-bar a").click(function (e) { 
		$(".illustartion-edit-block").toggleClass("landscape-open");
		$(this).toggleClass('active');
		// 
	  });
	  // landscape view js end
	  

	  $('body').click(function () {
		$(".illustartion-edit-block").removeClass('open');
		$(".illustartion-edit-block").removeClass('landscape-open');
		$(".first-block-inner .full-banner").addClass("height-resize");
		$(".first-block-inner .full-banner").removeClass('height-resize-small');
	  });
	  $('.illustartion-edit-block').click(function (e) {
		e.stopPropagation(); 
	  });
	  // option js mobile end

	  $('.modal-submit').click(function(){
		$('#submit-modal').modal({
		}); 
	  });
	  $('select').selectric({
		// disableOnMobile: false
	});
	

	// OFI Browser
	objectFitImages();
});