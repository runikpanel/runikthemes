const getUserInfo = () => {
    fetch('/getuserinfo.php', {
        method: 'GET',
        credentials: 'same-origin'
    })
        .then(res => res.json())
        .then(data => {
            $('#user_name').html(data.username)
            $('#amount_dm').html(data.coins)

            $('#amount_dz').html(data.coins2)
        })
        .catch(err => {
            console.log(err);
        })
}

$(() => {

    $('#section-6').hide();

    function showSuccesModal() {
        console.log('CAW');
        $.toast({
            text: "Předmět byl úspěšně zakoupen", // Text that is to be shown in the toast
            heading: 'ÚSPĚCH', // Optional heading to be shown on the toast
            icon: 'success', // Type of toast icon
            showHideTransition: 'fade', // fade, slide or plain
            allowToastClose: true, // Boolean value true or false
            hideAfter: 3000, // false to make it sticky or number representing the miliseconds as time after which toast needs to be hidden
            stack: 5, // false if there should be only one toast at a time or a number representing the maximum number of toasts to be shown at a time
            position: 'top-center', // bottom-left or bottom-right or bottom-center or top-left or top-right or top-center or mid-center or an object representing the left, right, top, bottom values



            textAlign: 'left', // Text alignment i.e. left, right or center
            loader: false, // Whether to show loader or not. True by default
            loaderBg: '#9EC600', // Background color of the toast loader
            beforeShow: function () { }, // will be triggered before the toast is shown
            afterShown: function () { }, // will be triggered after the toat has been shown
            beforeHide: function () { }, // will be triggered before the toast gets hidden
            afterHidden: function () { } // will be triggered after the toast has been hidden
        });
    }


    function showErrorModal() {
        console.log('CAW');
        $.toast({
            text:  "Nastala chyba při koupit itemu!", // Text that is to be shown in the toast
            heading: 'CHYBA', // Optional heading to be shown on the toast
            icon: 'error', // Type of toast icon
            showHideTransition: 'fade', // fade, slide or plain
            allowToastClose: true, // Boolean value true or false
            hideAfter: 3000, // false to make it sticky or number representing the miliseconds as time after which toast needs to be hidden
            stack: 5, // false if there should be only one toast at a time or a number representing the maximum number of toasts to be shown at a time
            position: 'top-center', // bottom-left or bottom-right or bottom-center or top-left or top-right or top-center or mid-center or an object representing the left, right, top, bottom values



            textAlign: 'left', // Text alignment i.e. left, right or center
            loader: false, // Whether to show loader or not. True by default
            loaderBg: '#9EC600', // Background color of the toast loader
            beforeShow: function () { }, // will be triggered before the toast is shown
            afterShown: function () { }, // will be triggered after the toat has been shown
            beforeHide: function () { }, // will be triggered before the toast gets hidden
            afterHidden: function () { } // will be triggered after the toast has been hidden
        });
    }



    $("*").dblclick(function (e) {
        e.preventDefault();
    })

    let inItem = false;
    let modalNameOpen = undefined;



    $('#mainModal').on('hidden.bs.modal', function () {

        $('.happy-wheel-wrapper').hide();
        console.log(modalNameOpen);
        if(!isItemModal){
            $('html').css('overflow', 'auto auto')
            isItemModal = false;
        }
        if (modalNameOpen && $(`${modalNameOpen}`).css('display') === 'block') {
            $(`${modalNameOpen}`).css('display', 'none');
            $('#pozadiPres2').css('display', 'none');
            $('html').css('overflow', 'auto auto')
            modalNameOpen = '';
            $('.bp-arrow').css('display', 'none');
            clearInterval(interval)
        }
        $('#pozadiPres').hide()
        if (inItem !== true) {
            $('#pozadiPres2').css('display', 'none')
            $('.bp-arrow').css('display', 'none');
            clearInterval(interval)
            inItem = false;
            $('html').css('overflow', 'auto auto')
        }
        inItem = false;
    })

    /*let interval;
    const moveArrow = () => {
        let positionLeft = 325;
        interval = setInterval(() => {
            $('.bp-arrow').css('left', `${positionLeft}px`)
            if (positionLeft <= 340) {
                positionLeft++;
            }
            else {
                positionLeft = 325;
            }
        }, 50);
    }*/
    let interval;
    let t = false;
    const changeOpacityInTime = () => {
        // let opacity = 1;
        // interval = setInterval(() => {
        //     $('#kolo-stesti-enter').css('opacity', opacity)
        //     if (opacity > 0.5 && t === false) {
        //         t = false;
        //         opacity -= 0.03;
        //     }
        //     else {
        //         t = true;
        //         opacity += 0.03;
        //         if (opacity > 0.99) {
        //             t = false;
        //         }
        //     }

        // }, 80);
    }
    let isItemModal = false;
    $('#pozadiPres').on('click', function () {
        $('.happy-wheel-wrapper').hide();
        console.log('CAWW');
        if (this.style.display === 'inline') {
            $('.innerItemModal:visible').modal('hide')
        }
    })

    $('#buy_coins_button').on('click', function (e) {
        $('.happy-wheel-wrapper').hide();
        e.preventDefault();
        $('.happy-wheel-wrapper').hide();
        $("#mainModal").modal({ show: true, hide: 'drop' });
        getUserInfo();
        $('#btn-home').click();
        $('#pozadiPres2').css('display', 'block')

        $('html').css('overflow-x', 'hidden')
        $('html').css('overflow-y', 'hidden');
        setTimeout(() => {
            $(window).scrollTop(256);
        }, 20);
        setTimeout(() => {
            $('#purchase-btn').click();
        }, 100);
    })



    $('#buy_coins_button2').on('click', function (e) {
        $('.happy-wheel-wrapper').hide();
        e.preventDefault();
        $('.happy-wheel-wrapper').hide();
        $("#mainModal").modal({ show: true, hide: 'drop' });
        getUserInfo();
        $('#btn-home').click();
        $('#pozadiPres2').css('display', 'block')

        $('html').css('overflow-x', 'hidden')
        $('html').css('overflow-y', 'hidden');
        setTimeout(() => {
            $(window).scrollTop(256);
        }, 20);
        setTimeout(() => {
            $('#purchase-btn').click();
        }, 100);
    })

    $('#item_shop_button').on('click', function (e) {
        e.preventDefault();
        $('.happy-wheel-wrapper').hide();
        $("#mainModal").modal({ show: true, hide: 'drop' });
        getUserInfo();
        $('#btn-home').click();
        $('#pozadiPres2').css('display', 'block')

        $('html').css('overflow-y', 'hidden');
        $('html').css('overflow-x', 'hidden')
        setTimeout(() => {
            $(window).scrollTop(256);
        }, 20);

        //changeOpacityInTime();
        /*setTimeout(() => {
            $('.bp-arrow').css('display', 'block');
            moveArrow()
        }, 1000);*/
    })

    $('.btn-shop').on('click', function (e) {
        if (!$(e.target).hasClass('disable-btn')) {
            e.preventDefault();
            $('.happy-wheel-wrapper').hide();
            $("#mainModal").modal({ show: true, hide: 'drop' });
            getUserInfo();
            $('#btn-home').click();
            $('#pozadiPres2').css('display', 'block')

            $('html').css('overflow-y', 'hidden');
            $('html').css('overflow-x', 'hidden');
            setTimeout(() => {
                $(window).scrollTop(256);
            }, 20);
        } else {
        }
    })


    // if (Cookies.get('lang') === 'cz') {
    $('#user_world').html('Nitem Gold')
    $('#dm').html('mincí')
    $('#dz').html('známek')
    $('#purchase-btn').html('<div class="ikonkadm"></div><div style="margin-top:-18px; margin-left: 15px;">KOUPIT MINCE</div>')
    $('#kolo-stesti-enter').html('Kolo štěstí')

    //sekce 1

    $('#section-1').html('Herní účet')
    $('#section-1_1, #section-1_1a').html('Zisk zkušeností')
    $('#section-1_2, #section-1_2a').html('Zisk předmětů')
    $('#section-1_3, #section-1_3a').html('Sklad')
    $('#section-1_4, #section-1_4a').html('Sbírání yangů')
    $('#section-1_5, #section-1_5a').html('Rybaření')
    $('#section-1_6, #section-1_6a').html('Pěstování')
    $('#section-1_7, #section-1_7a').html('Obchodník premium')

    //sekce 2

    $('#section-2').html('Vývoj')
    $('#section-2_1, #section-2_1a').html('Herní postava')
    $('#section-2_2, #section-2_2a').html('Manželství')
    $('#section-2_4, #section-2_4a').html('Balíčky')



    //sekce 3

    $('#section-3').html('Styl')
    $('#section-3_1, #section-3_1a').html('Účesy')
    $('#section-3_1_1, #section-3_1_1a').html('Válečník')
    $('#section-3_1_2, #section-3_1_2a').html('Ninja')
    $('#section-3_1_3, #section-3_1_3a').html('Šaman')
    $('#section-3_1_4, #section-3_1_4a').html('Sura')
    $('#section-3_3, #section-3_3a').html('Mazlíčci')
    $('#section-3_4, #section-3_4a').html('Jezdecká zvířata')


    //sekce 5

    $('#section-5').html('Obchod za DZ')


    //sekce 6
    $('#section-7').html('Kolo štěstí')

    //sekce další
    $('#section-8').html('Vánoce')
    $('#section-9').html('Silvestr')
    $('#section-10').html('Velikonoce')
    $('#section-11').html('Velikonoce')


    // //ruleta

    // $('#roll-now').html('TOČIT')

    // //battle-pass

    // $('#battle-pass-certificate-label').html('Battle Pass Certifikát')
    // $('#battle-pass-price').html('299 mincí')
    // $('#battle-pass-buy').html('KOUPIT')
    // $('#battle-pass-quests-label').html('Úkoly')



    // } else {
    //     $('.dropdown-content-bigger').addClass('dropdown-content-bigger2');

    //     $('#user_name').html('player name')
    //     $('#user_world').html('Nitem3')
    //     $('#amount_dm').html('0')
    //     $('#dm').html('coins')
    //     $('#amount_dz').html('0')
    //     $('#dz').html('marks')
    //     $('#purchase-btn').html('BUY COINS')
    //     $('#kolo-stesti-enter').html('HAPPY WHEEL')

    //     //sekce 1

    //     $('#section-1').html('Account')
    //     $('#section-1_1, #section-1_1a').html('Experience gain')
    //     $('#section-1_2, #section-1_2a').html('Item gain')
    //     $('#section-1_3, #section-1_3a').html('Storage')
    //     $('#section-1_4, #section-1_4a').html('Yang collecting')
    //     $('#section-1_5, #section-1_5a').html('Fishing')
    //     $('#section-1_6, #section-1_6a').html('Herbalism')
    //     $('#section-1_7, #section-1_7a').html('Trader Premium')

    //     //sekce 2

    //     $('#section-2').html('Progress')
    //     $('#section-2_1, #section-2_1a').html('Player character')
    //     $('#section-2_2, #section-2_2a').html('Marriage')
    //     $('#section-2_4, #section-2_4a').html('Packs')



    //     //sekce 3

    //     $('#section-3').html('Style')
    //     $('#section-3_1, #section-3_1a').html('Hairstyles')
    //     $('#section-3_1_1, #section-3_1_1a').html('Warrior')
    //     $('#section-3_1_2, #section-3_1_2a').html('Ninja')
    //     $('#section-3_1_3, #section-3_1_3a').html('Shaman')
    //     $('#section-3_1_4, #section-3_1_4a').html('Sura')
    //     $('#section-3_2, #section-3_2a').html('Glows')
    //     $('#section-3_2_1, #section-3_2_1a').html('Legendary')
    //     $('#section-3_2_2, #section-3_2_2a').html('Standard')
    //     $('#section-3_3, #section-3_3a').html('Pets')
    //     $('#section-3_3_1, #section-3_3_1a').html('PvP')
    //     $('#section-3_3_2, #section-3_3_2a').html('PvM')
    //     $('#section-3_4, #section-3_4a').html('Mounts')

    //     //sekce 4

    //     $('#section-4').html('Costumes')
    //     $('#section-4_1, #section-4_1a').html('Costumes (PvP)')
    //     $('#section-4_1_1, #section-4_1_1a').html('Male')
    //     $('#section-4_1_2, #section-4_1_2a').html('Female')
    //     $('#section-4_2, #section-4_2a').html('Costumes (PvM)')
    //     $('#section-4_2_1, #section-4_2_1a').html('Male')
    //     $('#section-4_2_2, #section-4_2_2a').html('Female')
    //     $('#section-4_3, #section-4_3a').html('Weapon skins (PvP)')
    //     $('#section-4_3_1, #section-4_3_1a').html('One-handed swords')
    //     $('#section-4_3_2, #section-4_3_2a').html('Two-handed swords')
    //     $('#section-4_3_3, #section-4_3_3a').html('Daggers')
    //     $('#section-4_3_4, #section-4_3_4a').html('Fans')
    //     $('#section-4_3_5, #section-4_3_5a').html('Bells')
    //     $('#section-4_3_6, #section-4_3_6a').html('Bows')
    //     $('#section-4_4, #section-4_4a').html('Weapon skins (PvM)')
    //     $('#section-4_4_1, #section-4_4_1a').html('One-handed swords')
    //     $('#section-4_4_2, #section-4_4_2a').html('Two-handed swords')
    //     $('#section-4_4_3, #section-4_4_3a').html('Daggers')
    //     $('#section-4_4_4, #section-4_4_4a').html('Fans')
    //     $('#section-4_4_5, #section-4_4_5a').html('Bells')
    //     $('#section-4_4_6, #section-4_4_6a').html('Bows')

    //     //sekce 5

    //     $('#section-5').html('DZ shop')

    //     //sekce 6

    //     $('#section-7').html('Happy Wheel')
    //     //sekce 8
    //     $('#section-8').html('Christmas')
    //     $('#section-9').html('New Year\'s Eve')
    //     $('#section-10').html('Velikonoce')

    //     //roulette

    //     $('#roll-now').html('ROLL')

    //     //battle-pass

    //     $('#battle-pass-certificate-label').html('Battle Pass Certificate')
    //     $('#battle-pass-price').html('299 coins')
    //     $('#battle-pass-buy').html('BUY')
    //     $('#battle-pass-quests-label').html('Quests')

    // }

    $('#ruleta').hide();
    $('#category-name').hide();
    $('#section-content').hide();
    $('.buy-coins').hide();
    $('#battle-pass').hide();
    $('#sidebar-content_11,#sidebar-content_10,#sidebar-content_9,#sidebar-content_8,#sidebar-content_6,#sidebar-content_5,#sidebar-content_4,#sidebar-content_3,#sidebar-content_2,#sidebar-content_1').hide()
    $('.happy-wheel-wrapper').hide();
    //$('#cont-images').hide(); //out
    //$('#index-footer').hide(); // out
    $('.btn-nav-akce,.btn-nav, .btn-nav-christmas, .btn-nav-silvestr, .btn-nav-limited, .sidebar-btn, .dropdown-item-text2').on('click', function () {
        $('#cont-images').hide();
        $('#index-footer').hide();
        $('#section-content').show();
        $('#category-name').show();
        $('#ruleta').hide();
        $('#battle-pass').hide();
        $('.happy-wheel-wrapper').hide();

    })



    let position = 0;
    $('#btn-home, .logo-itemshop').on('click', () => {
        $('#cont-images').show();
        $('#battle-pass').hide();
        $('#index-footer').show();
        $('#section-content').hide();
        $('#category-name').hide();
        $('#ruleta').hide();
        $('#items-shown').html('');
        $('.happy-wheel-wrapper').hide();


        fetch('/getisitems.php', {
            method: 'GET',
            credentials: 'same-origin'
        })
            .then(res => res.json())
            .then(items => {
                const featuredItems = items.filter(item => {
                    //console.log(item);
                    return item.featured == 1
                })

                    .map(item => {
                        return {
                            id: item.id,
                            currency: item.currency,
                            price: item.price,
                            itemname_cz: item.itemname_cz,
                            itemname_en: item.itemname_en,
                            description2_cz: item.description2_cz,
                            description2_en: item.description2_en,
                            itemdesc_cz: item.itemdesc_cz,
                            itemdesc_en: item.itemdesc_en,
                            itemcount: item.itemcount,
                            description1_cz: item.description1_cz,
                            description1_en: item.description1_en,
                            currentPhoto: 0,
                            images: item.images.map(item => '/assets/images/itemshop/items/' + item)
                        }
                    })

                let width = (featuredItems.length * 258) + 'px';

                $('#items-shown').css({
                    'opacity': 1,
                    'width': width,
                    'position': 'relative',
                    'left': '0px',
                    'transition': '0.5s'
                })

                createItems(featuredItems, '#items-shown')

            })
            .catch(err => {
                throw err;
            })



        $('.next-item').on('click', function () {
            let newWidth = $('#items-shown').css('width').replace('px', '');
            let newLeft = $('#items-shown').css('left').replace('px', '') - 243;
            //console.log(newWidth, newLeft)
            if (-(newLeft - 172) <= newWidth - (952.91 - 15))
                $('#items-shown').css('left', newLeft + 'px');
            else {
                newLeft = -(newWidth - (952.91 - 25))
                $('#items-shown').css('left', newLeft + 'px');
            }
        })

        $('.previous-item').on('click', function () {
            let newWidth = $('#items-shown').css('width').replace('px', '');
            let newLeft = Number($('#items-shown').css('left').replace('px', '')) + 243;
            if (-(newLeft + 172) >= 0)
                $('#items-shown').css('left', newLeft + 'px');
            else {
                newLeft = 0
                $('#items-shown').css('left', newLeft + 'px');
            }
        })

    })



    /*$('.actual-item').on('click', function () {
        $('.main-container').css('opacity', 0.3)
    })*/



    $('span,button,a').on('click', function () {
        if (!$(this).hasClass('battle-pass-certificate-label') && !$(this).hasClass('battle-pass-price') && !$(this).hasClass('bp123') && !$(this).hasClass('battle-pass-price') && !$(this).hasClass('category-name-text') && !$(this).hasClass('world') && !$(this).hasClass('account') && !$(this).hasClass('curr') && !$(this).hasClass('buy-btn') && !$(this).hasClass('betonek') && !$(this).hasClass('buy-btn-2') && !$(this).hasClass('paypalme') && !$(this).hasClass('paypalmea') && !$(this).hasClass('wheel-roll-btn')) {
            $('.section-content-items-main').html('');
            $('#battle-pass').hide();
            $('.buy-coins').hide();
            $('.btn-nav').css('text-transform', 'lower-case')
            $('.happy-wheel-wrapper').hide();

        }
    })



    const payButtons = [
        '<div class="czk-btn"> </div>',
        '<div class="eur-btn"> </div>'
    ];

    const payButtonContainer = `<div style="margin-right:43px; display:flex;" class="pay-btn-container">${payButtons.join('')}</div>`;

    let isAppended = false;
    $('#purchase-btn').on('click', () => {
        $('.pay-btn-container').show();
        if (!isAppended) {
            $('#category-name').append(payButtonContainer);
            $('.czk-btn').addClass('currency-btn-active');
            $('.eur-btn').removeClass('currency-btn-active')
            isAppended = true;
            $('.coins-czk').show();
            $('.coins-eur').hide();
        }
        $('#items-section-nav').hide();
        $('.section-content-items-main').html('');
        $('.buy-coins').show();
        $('#index-footer').hide();
        $('#cont-images').hide();
        $('#category-name').show();
        $('#sidebar-content_9,#sidebar-content_8,#sidebar-content_6,#sidebar-content_5,#sidebar-content_4,#sidebar-content_3,#sidebar-content_2,#sidebar-content_1, #sidebar-content_10,#sidebar-content_11').hide()
        $('.happy-wheel-wrapper').hide();
        $('#category-name-text').text(`${'Koupit mince'}`)


        $('.czk-btn, .eur-btn').on('click', e => {
            if ($(e.target).hasClass('czk-btn')) {
                $('.czk-btn').addClass('currency-btn-active');
                $('.eur-btn').removeClass('currency-btn-active')
                $('.coins-czk').show();
                $('.coins-eur').hide();
            } else {
                $('.eur-btn').addClass('currency-btn-active');
                $('.czk-btn').removeClass('currency-btn-active')
                $('.coins-czk').hide();
                $('.coins-eur').show();

            }
        });

    })

    const getCookie = () => {
        const cookie = document.cookie;
        const cookieArray = cookie.split(';');

        const cookieObj = {};
        cookieArray.forEach(c => {
            const trimmed = c.trim();
            const key = trimmed.split('=')[0];
            const value = trimmed.split('=')[1];
            cookieObj[key] = value;
        });

        return cookieObj;
    }


    $('.section-1').on('click', () => {
        $('.happy-wheel-wrapper').hide();
        $('.section-content-items-main').html('');
        $('#sidebar-content_9,#sidebar-content_8,#sidebar-content_5,#sidebar-content_4,#sidebar-content_3,#sidebar-content_2,#sidebar-content_6, #sidebar-content_10,#sidebar-content_11').hide()
        $('.section-content-items-main').css('max-height', '472px')
        $('#sidebar-content_1').show();
        $('.pay-btn-container').hide();

    })
    $('.section-2').on('click', () => {
        $('.happy-wheel-wrapper').hide();

        $('.section-content-items-main').html('');
        $('#sidebar-content_9,#sidebar-content_8,#sidebar-content_5,#sidebar-content_4,#sidebar-content_3,#sidebar-content_1,#sidebar-content_6, #sidebar-content_10,#sidebar-content_11').hide()
        $('.section-content-items-main').css('max-height', '472px')
        $('#sidebar-content_2').show();
        $('.pay-btn-container').hide();

    })
    $('.section-3').on('click', () => {
        $('.happy-wheel-wrapper').hide();

        $('.section-content-items-main').html('');
        $('#sidebar-content_9,#sidebar-content_8,#sidebar-content_5,#sidebar-content_4,#sidebar-content_1,#sidebar-content_2,#sidebar-content_6, #sidebar-content_10,#sidebar-content_11').hide()
        $('.section-content-items-main').css('max-height', '472px')
        $('#sidebar-content_3').show();
        $('.pay-btn-container').hide();
    })
    $('.section-4').on('click', () => {
        $('.happy-wheel-wrapper').hide();

        $('.section-content-items-main').html('');
        $('#sidebar-content_9,#sidebar-content_8,#sidebar-content_5,#sidebar-content_1,#sidebar-content_3,#sidebar-content_2,#sidebar-content_6, #sidebar-content_10,#sidebar-content_11').hide()
        $('.section-content-items-main').css('max-height', '472px')
        $('#sidebar-content_4').show();
        $('.pay-btn-container').hide();

    })
    $('.section-5').on('click', () => {
        $('.happy-wheel-wrapper').hide();

        $('.section-content-items-main').html('');
        $('#sidebar-content_9,#sidebar-content_8,#sidebar-content_1,#sidebar-content_4,#sidebar-content_3,#sidebar-content_2,#sidebar-content_6, #sidebar-content_10,#sidebar-content_11').hide()
        $('.section-content-items-main').css('max-height', '472px')
        $('#sidebar-content_5').show();
        $('.pay-btn-container').hide();


    })
    $('.section-8').on('click', () => {
        $('.happy-wheel-wrapper').hide();
        console.log('CO')
        $('.section-content-items-main').html('');
        $('#sidebar-content_9,#sidebar-content_1,#sidebar-content_4,#sidebar-content_3,#sidebar-content_2,#sidebar-content_6,#sidebar-content_5, #sidebar-content_10,#sidebar-content_11').hide()
        $('.section-content-items-main').css('max-height', '472px')
        $('#sidebar-content_8').show();
        $('.pay-btn-container').hide();


    })
    $('.section-9').on('click', () => {
        $('.happy-wheel-wrapper').hide();
        $('.section-content-items-main').html('');
        $('#sidebar-content_8,#sidebar-content_1,#sidebar-content_4,#sidebar-content_3,#sidebar-content_2,#sidebar-content_6,#sidebar-content_5, #sidebar-content_10,#sidebar-content_11').hide()
        $('.section-content-items-main').css('max-height', '472px')
        $('#sidebar-content_9').show();
        $('.pay-btn-container').hide();

    })

    $('.section-10').on('click', () => {
        $('.happy-wheel-wrapper').hide();
        $('.section-content-items-main').html('');
        $('#sidebar-content_8,#sidebar-content_1,#sidebar-content_4,#sidebar-content_3,#sidebar-content_2,#sidebar-content_6,#sidebar-content_5, #sidebar-content_9,#sidebar-content_11').hide()
        $('.section-content-items-main').css('max-height', '472px')
        $('#sidebar-content_10').show();
        $('.pay-btn-container').hide();

    })

    $('.section-11').on('click', () => {
        $('.happy-wheel-wrapper').hide();
        $('.section-content-items-main').html('');
        $('#sidebar-content_8,#sidebar-content_1,#sidebar-content_4,#sidebar-content_3,#sidebar-content_2,#sidebar-content_6,#sidebar-content_5, #sidebar-content_9').hide()
        $('.section-content-items-main').css('max-height', '472px')
        $('#sidebar-content_11').show();
        $('.pay-btn-container').hide();

    })

    $('.section-6').on('click', () => {
        $('.happy-wheel-wrapper').hide();

        $('.section-content-items-main').html('');
        $('#sidebar-content_1,#sidebar-content_4,#sidebar-content_3,#sidebar-content_2,#sidebar-content_5').hide()
        $('.section-content-items-main').css('max-height', '472px')
        $('#sidebar-content_6').show();
        $('.pay-btn-container').hide();

    })
    $('.section-7').on('click', () => {
        setTimeout(() => {
            console.log('CAW');
            initAnimation();
        }, 1000);
        $('.section-content-items-main').html('');
        $('#sidebar-content_1,#sidebar-content_4,#sidebar-content_3,#sidebar-content_2,#sidebar-content_6,#sidebar-content_5').hide()
        $('.section-content-items-main').css('max-height', '472px')
        $('.happy-wheel-wrapper').show();
        $('.pay-btn-container').hide();


    })

    //clears all stuff when clicked anything



    //modal2

    //všechny kliky na menu
    $('#section-11').on('click', () => {
        $('#items-section-nav').hide();
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#category-name-text').text($('#section-11').text())
    })

    $('#section-10').on('click', () => {
        $('#items-section-nav').hide();
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#category-name-text').text($('#section-10').text())
    })

    $('#section-9').on('click', () => {
        $('#items-section-nav').hide();
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#category-name-text').text($('#section-9').text())
    })

    $('#section-8').on('click', () => {
        $('#items-section-nav').hide();
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#category-name-text').text($('#section-8').text())
    })
    $('#section-7').on('click', () => {
        $('#items-section-nav').hide();
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#category-name-text').text('Kolo štěstí')
    })
    $('#section-6').on('click', () => {
        $('#items-section-nav').hide();
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#category-name-text').text('V této sekci se nachází limitované předměty. Exkluzivní předměty budou z této sekce odstraněny 1.11.2019 ve 23:59. ')
    })

    $('#section-5').on('click', () => {
        $('#items-section-nav').hide();
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#category-name-text').text($('#section-5').text())
    })

    // 4
    $('#section-4').on('click', () => {
        $('#items-section-nav').hide();
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#category-name-text').text($('#section-4').text())
    })
    $('#section-4_1, #section-4_1a').on('click', () => {
        $('.section-content-items-menu').html('');
        $('#category-name-text').text(`${$('#section-4').text()} - ${$('#section-4_1').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#items-section-nav').show();
        $('#items-section-nav').html(`
        <button class="item-section-nav" id="section-4_1_3b" onclick="$('#section-4_1').click()">Vše</button>
        <button class="item-section-nav" id="section-4_1_1b" onclick="$('#section-4_1_1').click()">${$('#section-4_1_1').text()}</button>
        <button class="item-section-nav" id="section-4_1_2b" onclick="$('#section-4_1_2').click()">${$('#section-4_1_2').text()}</button>
       
        `)

        $('#section-4_1a').addClass('sidebar-btn-clicked')
        $('#section-4_1_3b').addClass('sidebar-btn-clicked')
    })
    $('#section-4_1_1, #section-4_1_1a').on('click', () => {
        $('#category-name-text').text(`${$('#section-4').text()} - ${$('#section-4_1').text()} - ${$('#section-4_1_1').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#items-section-nav').show();
        $('#items-section-nav').html(`
        <button class="item-section-nav" id="section-4_1_3b" onclick="$('#section-4_1').click()">Vše</button>
        <button class="item-section-nav" id="section-4_1_1b">${$('#section-4_1_1').text()}</button>
         <button class="item-section-nav" id="section-4_1_2b" onclick="$('#section-4_1_2').click()">${$('#section-4_1_2').text()}</button>

        `)
        $('#section-4_1_1b').addClass('sidebar-btn-clicked')
        $('#section-4_1a').addClass('sidebar-btn-clicked')
    })
    $('#section-4_1_2, #section-4_1_2a').on('click', () => {
        $('#category-name-text').text(`${$('#section-4').text()} - ${$('#section-4_1').text()} - ${$('#section-4_1_2').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#items-section-nav').show();
        $('#items-section-nav').html(`
        <button class="item-section-nav" id="section-4_1_3b" onclick="$('#section-4_1').click()">Vše</button>
        <button class="item-section-nav" id="section-4_1_1b" onclick="$('#section-4_1_1').click()">${$('#section-4_1_1').text()}</button>
         <button class="item-section-nav" id="section-4_1_2b" >${$('#section-4_1_2').text()}</button>
         
        `)
        $('#section-4_1_2b').addClass('sidebar-btn-clicked')
        $('#section-4_1a').addClass('sidebar-btn-clicked')
    })

    $('#section-4_2, #section-4_2a').on('click', () => {
        $('.section-content-items-menu').html('');
        $('#category-name-text').text(`${$('#section-4').text()} - ${$('#section-4_2').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#items-section-nav').show();
        $('#items-section-nav').html(`
        <button class="item-section-nav" id="section-4_2_3b" onclick="$('#section-4_2').click()">Vše</button>
        <button class="item-section-nav" id="section-4_2_1b" onclick="$('#section-4_2_1').click()">${$('#section-4_2_1').text()}</button>
        <button class="item-section-nav" id="section-4_2_2b" onclick="$('#section-4_2_2').click()">${$('#section-4_2_2').text()}</button>
        `)
        $('#section-4_2_3b').addClass('sidebar-btn-clicked')
        $('#section-4_2a').addClass('sidebar-btn-clicked')
    })
    $('#section-4_2_1, #section-4_2_1a').on('click', () => {
        $('#category-name-text').text(`${$('#section-4').text()} - ${$('#section-4_2').text()} - ${$('#section-4_2_1').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#items-section-nav').show();
        $('#items-section-nav').html(`
        <button class="item-section-nav" id="section-4_2_3b" onclick="$('#section-4_2').click()">Vše</button>
        <button class="item-section-nav" id="section-4_2_1b">${$('#section-4_2_1').text()}</button>
         <button class="item-section-nav" id="section-4_2_2b" onclick="$('#section-4_2_2').click()">${$('#section-4_2_2').text()}</button>
        `)
        $('#section-4_2_1b').addClass('sidebar-btn-clicked')
        $('#section-4_2a').addClass('sidebar-btn-clicked')
    })
    $('#section-4_2_2, #section-4_2_2a').on('click', () => {
        $('#category-name-text').text(`${$('#section-4').text()} - ${$('#section-4_2').text()} - ${$('#section-4_2_1').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#items-section-nav').show();
        $('#items-section-nav').html(`
        <button class="item-section-nav" id="section-4_2_3b" onclick="$('#section-4_2').click()">Vše</button>
        <button class="item-section-nav" id="section-4_2_1b" onclick="$('#section-4_2_1').click()">${$('#section-4_2_1').text()}</button>
         <button class="item-section-nav" id="section-4_2_2b" >${$('#section-4_2_2').text()}</button>
        `)
        $('#section-4_2_2b').addClass('sidebar-btn-clicked')
        $('#section-4_2a').addClass('sidebar-btn-clicked')
    })
    $('#section-4_3, #section-4_3a').on('click', () => {
        $('#category-name-text').text(`${$('#section-4').text()} - ${$('#section-4_3').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('.section-content-items-menu').html('');
        $('#items-section-nav').show();
        $('#items-section-nav').html(`
        <button class="item-section-nav" id="section-4_3_7b" onclick="$('#section-4_3').click()">Vše</button>
        <button class="item-section-nav" id="section-4_3_1b" onclick="$('#section-4_3_1').click()">${$('#section-4_3_1').text()}</button>
        <button class="item-section-nav" id="section-4_3_2b" onclick="$('#section-4_3_2').click()">${$('#section-4_3_2').text()}</button>
        <button class="item-section-nav" id="section-4_3_3b" onclick="$('#section-4_3_3').click()">${$('#section-4_3_3').text()}</button>
        <button class="item-section-nav" id="section-4_3_4b" onclick="$('#section-4_3_4').click()">${$('#section-4_3_4').text()}</button>
        <button class="item-section-nav" id="section-4_3_5b" onclick="$('#section-4_3_5').click()">${$('#section-4_3_5').text()}</button>
        <button class="item-section-nav" id="section-4_3_6b" onclick="$('#section-4_3_6').click()">${$('#section-4_3_6').text()}</button>
        `)
        $('#section-4_3_7b').addClass('sidebar-btn-clicked')
        $('#section-4_3a').addClass('sidebar-btn-clicked')
    })
    $('#section-4_3_1, #section-4_3_1a').on('click', () => {
        $('#category-name-text').text(`${$('#section-4').text()} - ${$('#section-4_3').text()} - ${$('#section-4_3_1').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#items-section-nav').show();
        $('#items-section-nav').html(`
        <button class="item-section-nav" id="section-4_3_7b" onclick="$('#section-4_3').click()">Vše</button>
        <button class="item-section-nav" id="section-4_3_1b">${$('#section-4_3_1').text()}</button>
        <button class="item-section-nav" id="section-4_3_2b" onclick="$('#section-4_3_2').click()">${$('#section-4_3_2').text()}</button>
        <button class="item-section-nav" id="section-4_3_3b" onclick="$('#section-4_3_3').click()">${$('#section-4_3_3').text()}</button>
        <button class="item-section-nav" id="section-4_3_4b" onclick="$('#section-4_3_4').click()">${$('#section-4_3_4').text()}</button>
        <button class="item-section-nav" id="section-4_3_5b" onclick="$('#section-4_3_5').click()">${$('#section-4_3_5').text()}</button>
        <button class="item-section-nav" id="section-4_3_6b" onclick="$('#section-4_3_6').click()">${$('#section-4_3_6').text()}</button>
        `)
        $('#section-4_3_1b').addClass('sidebar-btn-clicked')
        $('#section-4_3a').addClass('sidebar-btn-clicked')
    })
    $('#section-4_3_2, #section-4_3_2a').on('click', () => {
        $('#category-name-text').text(`${$('#section-4').text()} - ${$('#section-4_3').text()} - ${$('#section-4_3_2').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#items-section-nav').show();
        $('#items-section-nav').html(`
        <button class="item-section-nav" id="section-4_3_7b" onclick="$('#section-4_3').click()">Vše</button>
        <button class="item-section-nav" id="section-4_3_1b"  onclick="$('#section-4_3_1').click()">${$('#section-4_3_1').text()}</button>
        <button class="item-section-nav" id="section-4_3_2b">${$('#section-4_3_2').text()}</button>
        <button class="item-section-nav" id="section-4_3_3b" onclick="$('#section-4_3_3').click()">${$('#section-4_3_3').text()}</button>
        <button class="item-section-nav" id="section-4_3_4b" onclick="$('#section-4_3_4').click()">${$('#section-4_3_4').text()}</button>
        <button class="item-section-nav" id="section-4_3_5b" onclick="$('#section-4_3_5').click()">${$('#section-4_3_5').text()}</button>
        <button class="item-section-nav" id="section-4_3_6b" onclick="$('#section-4_3_6').click()">${$('#section-4_3_6').text()}</button>
        `)
        $('#section-4_3_2b').addClass('sidebar-btn-clicked')
        $('#section-4_3a').addClass('sidebar-btn-clicked')
    })
    $('#section-4_3_3, #section-4_3_3a').on('click', () => {
        $('#category-name-text').text(`${$('#section-4').text()} - ${$('#section-4_3').text()} - ${$('#section-4_3_3').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#items-section-nav').show();
        $('#items-section-nav').html(`
        <button class="item-section-nav" id="section-4_3_7b" onclick="$('#section-4_3').click()">Vše</button>
        <button class="item-section-nav" id="section-4_3_1b"  onclick="$('#section-4_3_1').click()">${$('#section-4_3_1').text()}</button>
        <button class="item-section-nav" id="section-4_3_2b" onclick="$('#section-4_3_2').click()">${$('#section-4_3_2').text()}</button>
        <button class="item-section-nav" id="section-4_3_3b" >${$('#section-4_3_3').text()}</button>
        <button class="item-section-nav" id="section-4_3_4b" onclick="$('#section-4_3_4').click()">${$('#section-4_3_4').text()}</button>
        <button class="item-section-nav" id="section-4_3_5b" onclick="$('#section-4_3_5').click()">${$('#section-4_3_5').text()}</button>
        <button class="item-section-nav" id="section-4_3_6b" onclick="$('#section-4_3_6').click()">${$('#section-4_3_6').text()}</button>
        `)
        $('#section-4_3_3b').addClass('sidebar-btn-clicked')
        $('#section-4_3a').addClass('sidebar-btn-clicked')
    })
    $('#section-4_3_4, #section-4_3_4a').on('click', () => {
        $('#category-name-text').text(`${$('#section-4').text()} - ${$('#section-4_4').text()} - ${$('#section-4_3_4').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#items-section-nav').show();
        $('#items-section-nav').html(`
        <button class="item-section-nav" id="section-4_3_7b" onclick="$('#section-4_3').click()">Vše</button>
        <button class="item-section-nav" id="section-4_3_1b"  onclick="$('#section-4_3_1').click()">${$('#section-4_3_1').text()}</button>
        <button class="item-section-nav" id="section-4_3_2b" onclick="$('#section-4_3_2').click()">${$('#section-4_3_2').text()}</button>
        <button class="item-section-nav" id="section-4_3_3b" onclick="$('#section-4_3_3').click()">${$('#section-4_3_3').text()}</button>
        <button class="item-section-nav" id="section-4_3_4b" >${$('#section-4_3_4').text()}</button>
        <button class="item-section-nav" id="section-4_3_5b" onclick="$('#section-4_3_5').click()">${$('#section-4_3_5').text()}</button>
        <button class="item-section-nav" id="section-4_3_6b" onclick="$('#section-4_3_6').click()">${$('#section-4_3_6').text()}</button>
        `)
        $('#section-4_3_4b').addClass('sidebar-btn-clicked')
        $('#section-4_3a').addClass('sidebar-btn-clicked')
    })
    $('#section-4_3_5, #section-4_3_5a').on('click', () => {
        $('#category-name-text').text(`${$('#section-4').text()} - ${$('#section-4_3').text()} - ${$('#section-4_3_5').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#items-section-nav').show();
        $('#items-section-nav').html(`
        <button class="item-section-nav" id="section-4_3_7b" onclick="$('#section-4_3').click()">Vše</button>
        <button class="item-section-nav" id="section-4_3_1b"  onclick="$('#section-4_3_1').click()">${$('#section-4_3_1').text()}</button>
        <button class="item-section-nav" id="section-4_3_2b" onclick="$('#section-4_3_2').click()">${$('#section-4_3_2').text()}</button>
        <button class="item-section-nav" id="section-4_3_3b" onclick="$('#section-4_3_3').click()">${$('#section-4_3_3').text()}</button>
        <button class="item-section-nav" id="section-4_3_4b" onclick="$('#section-4_3_4').click()">${$('#section-4_3_4').text()}</button>
        <button class="item-section-nav" id="section-4_3_5b" >${$('#section-4_3_5').text()}</button>
        <button class="item-section-nav" id="section-4_3_6b" onclick="$('#section-4_3_6').click()">${$('#section-4_3_6').text()}</button>
        `)
        $('#section-4_3_5b').addClass('sidebar-btn-clicked')
        $('#section-4_3a').addClass('sidebar-btn-clicked')
    })
    $('#section-4_3_6, #section-4_3_6a').on('click', () => {
        $('#category-name-text').text(`${$('#section-4').text()} - ${$('#section-4_3').text()} - ${$('#section-4_3_6').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#items-section-nav').show();
        $('#items-section-nav').html(`
        <button class="item-section-nav" id="section-4_3_7b" onclick="$('#section-4_3').click()">Vše</button>
        <button class="item-section-nav" id="section-4_3_1b"  onclick="$('#section-4_3_1').click()">${$('#section-4_3_1').text()}</button>
        <button class="item-section-nav" id="section-4_3_2b" onclick="$('#section-4_3_2').click()">${$('#section-4_3_2').text()}</button>
        <button class="item-section-nav" id="section-4_3_3b" onclick="$('#section-4_3_3').click()">${$('#section-4_3_3').text()}</button>
        <button class="item-section-nav" id="section-4_3_4b" onclick="$('#section-4_3_4').click()">${$('#section-4_3_4').text()}</button>
        <button class="item-section-nav" id="section-4_3_5b" onclick="$('#section-4_3_5').click()">${$('#section-4_3_5').text()}</button>
        <button class="item-section-nav" id="section-4_3_6b" >${$('#section-4_3_6').text()}</button>
        `)
        $('#section-4_3_6b').addClass('sidebar-btn-clicked')
        $('#section-4_3a').addClass('sidebar-btn-clicked')
    })
    $('.section-content-items-main').html('');
    $('#section-4_4, #section-4_4a').on('click', () => {
        $('#category-name-text').text(`${$('#section-4').text()} - ${$('#section-4_4').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')

        $('#items-section-nav').show();
        $('#items-section-nav').html(`
        <button class="item-section-nav" id="section-4_4_7b" onclick="$('#section-4_4').click()">Vše</button>
        <button class="item-section-nav" id="section-4_4_1b" onclick="$('#section-4_4_1').click()">${$('#section-4_4_1').text()}</button>
        <button class="item-section-nav" id="section-4_4_2b" onclick="$('#section-4_4_2').click()">${$('#section-4_4_2').text()}</button>
        <button class="item-section-nav" id="section-4_4_3b" onclick="$('#section-4_4_3').click()">${$('#section-4_4_3').text()}</button>
        <button class="item-section-nav" id="section-4_4_4b" onclick="$('#section-4_4_4').click()">${$('#section-4_4_4').text()}</button>
        <button class="item-section-nav" id="section-4_4_5b" onclick="$('#section-4_4_5').click()">${$('#section-4_4_5').text()}</button>
        <button class="item-section-nav" id="section-4_4_6b" onclick="$('#section-4_4_6').click()">${$('#section-4_4_6').text()}</button>
        `)
        $('#section-4_4_7b').addClass('sidebar-btn-clicked')
        $('#section-4_4a').addClass('sidebar-btn-clicked')
    })
    $('#section-4_4_1, #section-4_4_1a').on('click', () => {
        $('#category-name-text').text(`${$('#section-4').text()} - ${$('#section-4_4').text()} - ${$('#section-4_4_1').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#items-section-nav').show();
        $('#items-section-nav').html(`
        <button class="item-section-nav" id="section-4_4_7b" onclick="$('#section-4_4').click()">Vše</button>
        <button class="item-section-nav" id="section-4_4_1b">${$('#section-4_4_1').text()}</button>
        <button class="item-section-nav" id="section-4_4_2b" onclick="$('#section-4_4_2').click()">${$('#section-4_4_2').text()}</button>
        <button class="item-section-nav" id="section-4_4_3b" onclick="$('#section-4_4_3').click()">${$('#section-4_4_3').text()}</button>
        <button class="item-section-nav" id="section-4_4_4b" onclick="$('#section-4_4_4').click()">${$('#section-4_4_4').text()}</button>
        <button class="item-section-nav" id="section-4_4_5b" onclick="$('#section-4_4_5').click()">${$('#section-4_4_5').text()}</button>
        <button class="item-section-nav" id="section-4_4_6b" onclick="$('#section-4_4_6').click()">${$('#section-4_4_6').text()}</button>
        `)
        $('#section-4_4_1b').addClass('sidebar-btn-clicked')
        $('#section-4_4a').addClass('sidebar-btn-clicked')
    })
    $('#section-4_4_2, #section-4_4_2a').on('click', () => {
        $('#category-name-text').text(`${$('#section-4').text()} - ${$('#section-4_4').text()} - ${$('#section-4_4_2').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#items-section-nav').show();
        $('#items-section-nav').html(`
        <button class="item-section-nav" id="section-4_4_7b" onclick="$('#section-4_4').click()">Vše</button>
        <button class="item-section-nav" id="section-4_4_1b"  onclick="$('#section-4_4_1').click()">${$('#section-4_4_1').text()}</button>
        <button class="item-section-nav" id="section-4_4_2b">${$('#section-4_4_2').text()}</button>
        <button class="item-section-nav" id="section-4_4_3b" onclick="$('#section-4_4_3').click()">${$('#section-4_4_3').text()}</button>
        <button class="item-section-nav" id="section-4_4_4b" onclick="$('#section-4_4_4').click()">${$('#section-4_4_4').text()}</button>
        <button class="item-section-nav" id="section-4_4_5b" onclick="$('#section-4_4_5').click()">${$('#section-4_4_5').text()}</button>
        <button class="item-section-nav" id="section-4_4_6b" onclick="$('#section-4_4_6').click()">${$('#section-4_4_6').text()}</button>
        `)
        $('#section-4_4_2b').addClass('sidebar-btn-clicked')
        $('#section-4_4a').addClass('sidebar-btn-clicked')
    })
    $('#section-4_4_3, #section-4_4_3a').on('click', () => {
        $('#category-name-text').text(`${$('#section-4').text()} - ${$('#section-4_4').text()} - ${$('#section-4_4_3').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#items-section-nav').show();
        $('#items-section-nav').html(`
        <button class="item-section-nav" id="section-4_4_7b" onclick="$('#section-4_4').click()">Vše</button>
        <button class="item-section-nav" id="section-4_4_1b"  onclick="$('#section-4_4_1').click()">${$('#section-4_4_1').text()}</button>
        <button class="item-section-nav" id="section-4_4_2b" onclick="$('#section-4_4_2').click()">${$('#section-4_4_2').text()}</button>
        <button class="item-section-nav" id="section-4_4_3b" >${$('#section-4_4_3').text()}</button>
        <button class="item-section-nav" id="section-4_4_4b" onclick="$('#section-4_4_4').click()">${$('#section-4_4_4').text()}</button>
        <button class="item-section-nav" id="section-4_4_5b" onclick="$('#section-4_4_5').click()">${$('#section-4_4_5').text()}</button>
        <button class="item-section-nav" id="section-4_4_6b" onclick="$('#section-4_4_6').click()">${$('#section-4_4_6').text()}</button>
        `)
        $('#section-4_4_3b').addClass('sidebar-btn-clicked')
        $('#section-4_4a').addClass('sidebar-btn-clicked')
    })
    $('#section-4_4_4, #section-4_4_4a').on('click', () => {
        $('#category-name-text').text(`${$('#section-4').text()} - ${$('#section-4_4').text()} - ${$('#section-4_4_4').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#items-section-nav').show();
        $('#items-section-nav').html(`
        <button class="item-section-nav" id="section-4_4_7b" onclick="$('#section-4_4').click()">Vše</button>
        <button class="item-section-nav" id="section-4_4_1b"  onclick="$('#section-4_4_1').click()">${$('#section-4_4_1').text()}</button>
        <button class="item-section-nav" id="section-4_4_2b" onclick="$('#section-4_4_2').click()">${$('#section-4_4_2').text()}</button>
        <button class="item-section-nav" id="section-4_4_3b" onclick="$('#section-4_4_3').click()">${$('#section-4_4_3').text()}</button>
        <button class="item-section-nav" id="section-4_4_4b" >${$('#section-4_4_4').text()}</button>
        <button class="item-section-nav" id="section-4_4_5b" onclick="$('#section-4_4_5').click()">${$('#section-4_4_5').text()}</button>
        <button class="item-section-nav" id="section-4_4_6b" onclick="$('#section-4_4_6').click()">${$('#section-4_4_6').text()}</button>
        `)
        $('#section-4_4_4b').addClass('sidebar-btn-clicked')
        $('#section-4_4a').addClass('sidebar-btn-clicked')
    })
    $('#section-4_4_5, #section-4_4_5a').on('click', () => {
        $('#category-name-text').text(`${$('#section-4').text()} - ${$('#section-4_4').text()} - ${$('#section-4_4_5').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#items-section-nav').show();
        $('#items-section-nav').html(`
        <button class="item-section-nav" id="section-4_4_7b" onclick="$('#section-4_4').click()">Vše</button>
        <button class="item-section-nav" id="section-4_4_1b"  onclick="$('#section-4_4_1').click()">${$('#section-4_4_1').text()}</button>
        <button class="item-section-nav" id="section-4_4_2b" onclick="$('#section-4_4_2').click()">${$('#section-4_4_2').text()}</button>
        <button class="item-section-nav" id="section-4_4_3b" onclick="$('#section-4_4_3').click()">${$('#section-4_4_3').text()}</button>
        <button class="item-section-nav" id="section-4_4_4b" onclick="$('#section-4_4_4').click()">${$('#section-4_4_4').text()}</button>
        <button class="item-section-nav" id="section-4_4_5b" >${$('#section-4_4_5').text()}</button>
        <button class="item-section-nav" id="section-4_4_6b" onclick="$('#section-4_4_6').click()">${$('#section-4_4_6').text()}</button>
        `)
        $('#section-4_4_5b').addClass('sidebar-btn-clicked')
        $('#section-4_4a').addClass('sidebar-btn-clicked')
    })
    $('#section-4_4_6, #section-4_4_6a').on('click', () => {
        $('#category-name-text').text(`${$('#section-4').text()} - ${$('#section-4_4').text()} - ${$('#section-4_4_6').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#items-section-nav').show();
        $('#items-section-nav').html(`
        <button class="item-section-nav" id="section-4_4_7b" onclick="$('#section-4_4').click()">Vše</button>
        <button class="item-section-nav" id="section-4_4_1b"  onclick="$('#section-4_4_1').click()">${$('#section-4_4_1').text()}</button>
        <button class="item-section-nav" id="section-4_4_2b" onclick="$('#section-4_4_2').click()">${$('#section-4_4_2').text()}</button>
        <button class="item-section-nav" id="section-4_4_3b" onclick="$('#section-4_4_3').click()">${$('#section-4_4_3').text()}</button>
        <button class="item-section-nav" id="section-4_4_4b" onclick="$('#section-4_4_4').click()">${$('#section-4_4_4').text()}</button>
        <button class="item-section-nav" id="section-4_4_5b" onclick="$('#section-4_4_5').click()">${$('#section-4_4_5').text()}</button>
        <button class="item-section-nav" id="section-4_4_6b" >${$('#section-4_4_6').text()}</button>
        `)
        $('#section-4_4_6b').addClass('sidebar-btn-clicked')
        $('#section-4_4a').addClass('sidebar-btn-clicked')
    })


    //UCESY - TEXT - DOPRAVA

    // $('.btn-nav, .item-section-nav, .sidebar-btn, .section-3').on('click', () => {
    //     console.log('cs');
    //     $('.actual-item-body-description').each(function () {
    //         $(this).css('padding-left', '7px');
    //     })
    // })

    $('#section-3').on('click', () => {
        $('#items-section-nav').hide();
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#category-name-text').text($('#section-3').text())
    })

    $('#section-3_1, #section-3_1a').on('click', () => {
        $('.section-content-items-menu').html('');
        $('#category-name-text').text(`${$('#section-3').text()} - ${$('#section-3_1').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#items-section-nav').show();
        $('#items-section-nav').html(`
        <button class="item-section-nav" id="section-3_1_5b" onclick="$('#section-3_1').click()">Vše</button>
        <button class="item-section-nav" id="section-3_1_1b" onclick="$('#section-3_1_1').click()">${$('#section-3_1_1').text()}</button>
        <button class="item-section-nav" id="section-3_1_2b" onclick="$('#section-3_1_2').click()">${$('#section-3_1_2').text()}</button>
         <button class="item-section-nav" id="section-3_1_3b" onclick="$('#section-3_1_3').click()">${$('#section-3_1_3').text()}</button>
        <button class="item-section-nav" id="section-3_1_4b" onclick="$('#section-3_1_4').click()">${$('#section-3_1_4').text()}</button>
        `)
        $('#section-3_1_5b').addClass('sidebar-btn-clicked')
        $('#section-3_1a').addClass('sidebar-btn-clicked')
    })
    $('#section-3_1_1, #section-3_1_1a').on('click', () => {
        $('#category-name-text').text(`${$('#section-3').text()} - ${$('#section-3_1').text()} - ${$('#section-3_1_1').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#items-section-nav').show();
        $('#items-section-nav').html(`
        <button class="item-section-nav" id="section-3_1_5b" onclick="$('#section-3_1').click()">Vše</button>
        <button class="item-section-nav" id="section-3_1_1b">${$('#section-3_1_1').text()}</button>
         <button class="item-section-nav" id="section-3_1_2b" onclick="$('#section-3_1_2').click()">${$('#section-3_1_2').text()}</button>
                <button class="item-section-nav" id="section-3_1_3b">${$('#section-3_1_3').text()}</button>
         <button class="item-section-nav" id="section-3_1_4b" onclick="$('#section-3_1_4').click()">${$('#section-3_1_4').text()}</button>
        `)
        $('#section-3_1_1b').addClass('sidebar-btn-clicked')
        $('#section-3_1a').addClass('sidebar-btn-clicked')
    })
    $('#section-3_1_2, #section-3_1_2a').on('click', () => {
        $('#category-name-text').text(`${$('#section-3').text()} - ${$('#section-3_1').text()} - ${$('#section-3_1_2').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#items-section-nav').show();
        $('#items-section-nav').html(`
        <button class="item-section-nav" id="section-3_1_5b" onclick="$('#section-3_1').click()">Vše</button>
        <button class="item-section-nav" id="section-3_1_1b" onclick="$('#section-3_1_1').click()">${$('#section-3_1_1').text()}</button>
        <button class="item-section-nav" id="section-3_1_2b">${$('#section-3_1_2').text()}</button>
        <button class="item-section-nav" id="section-3_1_3b" onclick="$('#section-3_1_3').click()">${$('#section-3_1_3').text()}</button>
        <button class="item-section-nav" id="section-3_1_4b" onclick="$('#section-3_1_4').click()" >${$('#section-3_1_4').text()}</button>
        `)
        $('#section-3_1_2b').addClass('sidebar-btn-clicked')
        $('#section-3_1a').addClass('sidebar-btn-clicked')
    })
    $('#section-3_1_3, #section-3_1_3a').on('click', () => {
        $('#category-name-text').text(`${$('#section-3').text()} - ${$('#section-3_1').text()} - ${$('#section-3_1_3').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#items-section-nav').show();
        $('#items-section-nav').html(`
        <button class="item-section-nav" id="section-3_1_5b" onclick="$('#section-3_1').click()">Vše</button>
        <button class="item-section-nav" id="section-3_1_1b" onclick="$('#section-3_1_1').click()">${$('#section-3_1_1').text()}</button>
        <button class="item-section-nav" id="section-3_1_2b" onclick="$('#section-3_1_2').click()" >${$('#section-3_1_2').text()}</button>
        <button class="item-section-nav" id="section-3_1_3b">${$('#section-3_1_3').text()}</button>
        <button class="item-section-nav" id="section-3_1_4b" onclick="$('#section-3_1_4').click()" >${$('#section-3_1_4').text()}</button>
        `)
        $('#section-3_1_3b').addClass('sidebar-btn-clicked')
        $('#section-3_1a').addClass('sidebar-btn-clicked')
    })
    $('#section-3_1_4, #section-3_1_4a').on('click', () => {
        $('#category-name-text').text(`${$('#section-3').text()} - ${$('#section-3_1').text()} - ${$('#section-3_1_4').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#items-section-nav').show();
        $('#items-section-nav').html(`
        <button class="item-section-nav" id="section-3_1_5b" onclick="$('#section-3_1').click()">Vše</button>
        <button class="item-section-nav" id="section-3_1_1b" onclick="$('#section-3_1_1').click()">${$('#section-3_1_1').text()}</button>
        <button class="item-section-nav" id="section-3_1_2b" onclick="$('#section-3_1_2').click()">${$('#section-3_1_2').text()}</button>
        <button class="item-section-nav" id="section-3_1_3b" onclick="$('#section-3_1_3').click()">${$('#section-3_1_3').text()}</button>
        <button class="item-section-nav" id="section-3_1_4b">${$('#section-3_1_4').text()}</button>
        `)
        $('#section-3_1_4b').addClass('sidebar-btn-clicked')
        $('#section-3_1a').addClass('sidebar-btn-clicked')
    })

    $('#section-3_2, #section-3_2a').on('click', () => {
        $('.section-content-items-menu').html('');
        $('#category-name-text').text(`${$('#section-3').text()} - ${$('#section-3_2').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#items-section-nav').show();
        $('#items-section-nav').html(`
        <button class="item-section-nav" id="section-3_2_3b" onclick="$('#section-3_2').click()">Vše</button>
        <button class="item-section-nav" id="section-3_2_1b" onclick="$('#section-3_2_1').click()">${$('#section-3_2_1').text()}</button>
        <button class="item-section-nav" id="section-3_2_2b" onclick="$('#section-3_2_2').click()">${$('#section-3_2_2').text()}</button>
        `)
        $('#section-3_2_3b').addClass('sidebar-btn-clicked')
        $('#section-3_2a').addClass('sidebar-btn-clicked')
    })
    $('#section-3_2_1, #section-3_2_1a').on('click', () => {
        $('#category-name-text').text(`${$('#section-3').text()} - ${$('#section-3_2').text()} - ${$('#section-3_2_1').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#items-section-nav').show();
        $('#items-section-nav').html(`
        <button class="item-section-nav" id="section-3_2_3b" onclick="$('#section-3_2').click()">Vše</button>
        <button class="item-section-nav" id="section-3_2_1b">${$('#section-3_2_1').text()}</button>
         <button class="item-section-nav" id="section-3_2_2b" onclick="$('#section-3_2_2').click()">${$('#section-3_2_2').text()}</button>
        `)
        $('#section-3_2_1b').addClass('sidebar-btn-clicked')
        $('#section-3_2a').addClass('sidebar-btn-clicked')
    })
    $('#section-3_2_2, #section-3_2_2a').on('click', () => {
        $('#category-name-text').text(`${$('#section-3').text()} - ${$('#section-3_2').text()} - ${$('#section-3_2_2').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#items-section-nav').show();
        $('#items-section-nav').html(`
        <button class="item-section-nav" id="section-3_2_3b" onclick="$('#section-3_2').click()">Vše</button>
        <button class="item-section-nav" id="section-3_2_1b" onclick="$('#section-3_2_1').click()">${$('#section-3_2_1').text()}</button>
         <button class="item-section-nav" id="section-3_2_2b" >${$('#section-3_2_2').text()}</button>
        `)
        $('#section-3_2_2b').addClass('sidebar-btn-clicked')
        $('#section-3_2a').addClass('sidebar-btn-clicked')
    })

    $('#section-3_3, #section-3_3a').on('click', () => {
        $('#category-name-text').text(`${$('#section-3').text()} - ${$('#section-3_3').text()}`)
        $('.section-content-items-menu').html('');
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#items-section-nav').show();
        $('#section-3_3_3b').addClass('sidebar-btn-clicked')
        $('#section-3_3a').addClass('sidebar-btn-clicked')
    })
    $('#section-3_3_1, #section-3_3_1a').on('click', () => {
        $('#category-name-text').text(`${$('#section-3').text()} - ${$('#section-3_3').text()} - ${$('#section-3_3_1').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#items-section-nav').show();
        $('#items-section-nav').html(`
        <button class="item-section-nav" id="section-3_3_3b" onclick="$('#section-3_3').click()">Vše</button>
        <button class="item-section-nav" id="section-3_3_1b">${$('#section-3_3_1').text()}</button>
         <button class="item-section-nav" id="section-3_3_2b" onclick="$('#section-3_3_2').click()">${$('#section-3_3_2').text()}</button>
        `)
        $('#section-3_3_1b').addClass('sidebar-btn-clicked')
        $('#section-3_3a').addClass('sidebar-btn-clicked')
    })
    $('#section-3_3_2, #section-3_3_2a').on('click', () => {
        $('#category-name-text').text(`${$('#section-3').text()} - ${$('#section-3_3').text()} - ${$('#section-3_3_2').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#items-section-nav').show();
        $('#items-section-nav').html(`
        <button class="item-section-nav" id="section-3_3_3b" onclick="$('#section-3_3').click()">Vše</button>
        <button class="item-section-nav" id="section-3_3_1b" onclick="$('#section-3_3_1').click()">${$('#section-3_3_1').text()}</button>
         <button class="item-section-nav" id="section-3_3_2b" >${$('#section-3_3_2').text()}</button>
        `)
        $('#section-3_3_2b').addClass('sidebar-btn-clicked')
        $('#section-3_3a').addClass('sidebar-btn-clicked')
    })

    $('#section-3_4, #section-3_4a').on('click', () => {
        $('#category-name-text').text(`${$('#section-3').text()} - ${$('#section-3_4').text()}`)
        $('.section-content-items-menu').html('');
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#section-3_4a').addClass('sidebar-btn-clicked')
    })

    $('#section-2').on('click', () => {
        $('.section-content-items-menu').html('');
        $('#items-section-nav').hide();
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#category-name-text').text($('#section-2').text())
    })
    $('#section-2_1, #section-2_1a').on('click', () => {
        $('.section-content-items-menu').html('');
        $('#category-name-text').text(`${$('#section-2').text()} - ${$('#section-2_1').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#section-2_1a').addClass('sidebar-btn-clicked')
    })

    $('#section-2_2, #section-2_2a').on('click', () => {
        $('.section-content-items-menu').html('');
        $('#category-name-text').text(`${$('#section-2').text()} - ${$('#section-2_2').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#section-2_2a').addClass('sidebar-btn-clicked')
    })

    $('#section-2_3, #section-2_3a').on('click', () => {
        $('#category-name-text').text(`${$('#section-2').text()} - ${$('#section-2_3').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#items-section-nav').show();
        // $('#items-section-nav').html(`
        // <button class="item-section-nav" id="section-2_3_3b" onclick="$('#section-2_3').click()">Vše</button>
        // <button class="item-section-nav" id="section-2_3_1b" onclick="$('#section-2_3_1').click()">Animovaná</button>
        // <button class="item-section-nav" id="section-2_3_2b" onclick="$('#section-2_3_2').click()">Statická</button>
        // `)
        $('#section-2_3_3b').addClass('sidebar-btn-clicked')
        $('#section-2_3a').addClass('sidebar-btn-clicked')
    })
    $('#section-2_3_1, #section-2_3_1a').on('click', () => {
        $('#category-name-text').text(`${$('#section-2').text()} - ${$('#section-2_3').text()} - ${$('#section-2_3_1').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#items-section-nav').show();
        $('#items-section-nav').html(`
        <button class="item-section-nav" id="section-2_3_3b" onclick="$('#section-2_3').click()">Vše</button>
        <button class="item-section-nav" id="section-2_3_1b" >${$('#section-2_3_1').text()}</button>
         <button class="item-section-nav" id="section-2_3_2b" onclick="$('#section-2_3_2').click()">${$('#section-2_3_2').text()}</button>
        `)
        $('#section-2_3_1b').addClass('sidebar-btn-clicked')
        $('#section-2_3a').addClass('sidebar-btn-clicked')
    })



    $('#section-2_3_2, #section-2_3_2a').on('click', () => {
        $('#category-name-text').text(`${$('#section-2').text()} - ${$('#section-2_3').text()} - ${$('#section-2_3_2').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        //$('#items-section-nav').html('');
        $('#items-section-nav').show();
        $('#items-section-nav').html(`
        <button class="item-section-nav" id="section-2_3_3b" onclick="$('#section-2_3').click()">Vše</button>
        <button class="item-section-nav" id="section-2_3_1b" onclick="$('#section-2_3_1').click()">${$('#section-2_3_1').text()}</button>
         <button class="item-section-nav" id="section-2_3_2b">${$('#section-2_3_2').text()}</button>
        `)
        $('#section-2_3_2b').addClass('sidebar-btn-clicked')
        $('#section-2_3a').addClass('sidebar-btn-clicked')
    })

    $('#section-2_4, #section-2_4a').on('click', () => {
        $('.section-content-items-menu').html('');
        $('#category-name-text').text(`${$('#section-2').text()} - ${$('#section-2_4').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#section-2_4a').addClass('sidebar-btn-clicked')
    })


    $('#section-1').on('click', () => {
        $('.section-content-items-menu').html('');
        $('#items-section-nav').hide();
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#category-name-text').text($('#section-1').text())



        //createItems(section1Items);
    })
    $('#section-1_1, #section-1_1a').on('click', () => {
        $('.section-content-items-menu').html('');
        $('#items-section-nav').hide();
        $('#category-name-text').text(`${$('#section-1').text()} - ${$('#section-1_1').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#section-1_1a').addClass('sidebar-btn-clicked')
    })

    $('#section-1_2, #section-1_2a').on('click', () => {
        $('.section-content-items-menu').html('');
        $('#items-section-nav').hide();
        $('#category-name-text').text(`${$('#section-1').text()} - ${$('#section-1_2').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#section-1_2a').addClass('sidebar-btn-clicked')
    })

    $('#section-1_3, #section-1_3a').on('click', () => {
        $('.section-content-items-menu').html('');
        $('#items-section-nav').hide();
        $('#category-name-text').text(`${$('#section-1').text()} - ${$('#section-1_3').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#section-1_3a').addClass('sidebar-btn-clicked')
    })


    $('#section-1_4, #section-1_4a').on('click', () => {
        $('.section-content-items-menu').html('');
        $('#items-section-nav').hide();
        $('#category-name-text').text(`${$('#section-1').text()} - ${$('#section-1_4').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#section-1_4a').addClass('sidebar-btn-clicked')
    })
    $('#section-1_5, #section-1_5a').on('click', () => {
        $('.section-content-items-menu').html('');
        $('#category-name-text').text(`${$('#section-1').text()} - ${$('#section-1_5').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#section-1_5a').addClass('sidebar-btn-clicked')
    })
    $('#section-1_6, #section-1_6a').on('click', () => {
        $('.section-content-items-menu').html('');
        $('#category-name-text').text(`${$('#section-1').text()} - ${$('#section-1_6').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#section-1_6a').addClass('sidebar-btn-clicked')
    })
    $('#section-1_7, #section-1_7a').on('click', () => {
        $('.section-content-items-menu').html('');
        $('#category-name-text').text(`${$('#section-1').text()} - ${$('#section-1_7').text()}`)
        $('.sidebar-btn').removeClass('sidebar-btn-clicked')
        $('#section-1_7a').addClass('sidebar-btn-clicked')
    })

    let disabled = 0;
    $('.section-10,.section-9,.section-8,.section-6,.section-1,.section-2,.section-3,.section-4,.section-5, .sidebar-btn, .dropdown-item-text2, .dropdown-item-text3').on('click', function () {
        if (disabled === 0) {
            $('.section-content-items-main').css('overflow-y', 'hidden');
            $('.section-content-items-main').html(`
          <div class="lds-spinner"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>
  <span class="sr-only">Loading...</span>
</div>
            `);
            disabled = 1;
            let temp = $(this).attr('id');
            if (temp[temp.length - 1] === 'a') {
                temp = temp.substring(0, temp.length - 1)
            }
            temp = temp.substring(8, temp.length)

            fetch('/getisitems.php?c=' + temp, {
                method: 'GET',
                credentials: 'same-origin'
            })
                .then(res => res.json())
                .then(data => {
                    const newData = data.map(item => {
                        return {
                            id: item.id,
                            currency: item.currency,
                            price: item.price,
                            itemname_cz: item.itemname_cz,
                            itemname_en: item.itemname_en,
                            description2_cz: item.description2_cz,
                            description2_en: item.description2_en,
                            itemcount: item.itemcount,
                            itemdesc_cz: item.itemdesc_cz,
                            itemdesc_en: item.itemdesc_en,
                            description1_cz: item.description1_cz,
                            description1_en: item.description1_en,
                            currentPhoto: 0,
                            images: item.images.map(item => '/assets/images/itemshop/items/' + item)
                        }
                    })
                    $('.section-content-items-main').html('');
                    $('.section-content-items-main').css('overflow-y', 'auto');
                    createItems(newData, '.section-content-items-main');

                })
                .catch(err => {
                    throw err;
                })
        }
        disabled = 0;
    })

    let disabledbuy = 0;

    const createItems = (items, container) => {
        //console.log(items.length);
        items.forEach(item => {
            $(container).append(`  
             <div class="actual-item" data-toggle="modal" data-target="#exampleModal${item.id}">
                 <div class= "footer-title-item" > ${item.itemname_cz}</div >
                 <div class="actual-item-body">
                    <div class="actual-item-body-photo"><img src="${item.images[0]}" alt="xd"  style="margin-left: 2.67px; margin-top: 2.75px;" /></div>
                     <div class="actual-item-body-description"><span style="font-size:12px">${item.itemdesc_cz.substring(0, 70) + '...'}</span></div>
                 </div>
                 <div class="actual-item-price">
                     <span>
                         ${item.currency === 'DM' ? '<img class="icon-dm" src="/assets/images/itemshop/kategorie/ikonka dm.png" width="15px" height="15px" />' : '<img src="/assets/images/itemshop/kategorie/ikonka dz.png" width="15px" height="15px" /></span>'}
                         <span id="amount_dm">${item.price}</span>
                         <span > ${item.currency === 'DM' ? 'mincí' : 'známek'}</span>
                     </span>
                     <span style="float: right; margin-right: 33px;">${item.description1_cz}</span>
                 </div>
             </div>
            <div class="modal fade innerItemModal" id="exampleModal${item.id}">
            <div class="modal-dialog xDxD" role="document">
                <div class="modal-content main-container2">
                    <div class="actual-item-nav">
                        <div class="actual-item-nav-name">
                            <span>${item.itemname_cz}</span>
                            <span style=" font-size: 12px;">${item.description2_cz}</span>
                        </div>
                        <div class="actual-item-nav-price">
                            <span>${'Cena:' + ' '}${item.currency === 'DM' ? '<img class="icon-dm" src="/assets/images/itemshop/kategorie/ikonka dm.png" width="15px" height="15px" />' + ' ' + item.price + '</span>' : '<img src="/assets/images/itemshop/kategorie/ikonka dz.png" width="15px" height="15px" />' + item.price + '</span>'}  
                            ${item.currency === 'DM' ? (`<span style="color:green;font-size:13px;font-weight: normal;">${'Obdržíte navíc:'}  <img src="/assets/images/itemshop/kategorie/ikonka dz.png" width="15px" height="15px" /> ${item.price}</span>`) : ''}
                        </div>
                    </div>
                    <div class="actual-item-content">
                        <div class="actual-item-content-galery">
                            <span id="levo${item.id}" class="${item.images.length > 2 ? 'sipkavlevo' : ''}"></span>
                            <div class="actual-item-content-photo">
                                <center><img id="photo${item.id}" src="${item.images[1]}" alt="xd"/></center>
                            </div>
                            <span id="pravo${item.id}" class="${item.images.length > 2 ? 'sipkavpravo' : ''}" ></span>
                        </div>
                        <div class="actual-item-content-description">
                            <span>${'Popis'}</span>
                            <span style="color:#3c1e16;font-size:13px; margin-top: 5px; overflow:auto;margin-top:">${item.itemdesc_cz}</span>
                        
                        </div>
                    </div>
                    <div class="actual-item-footer">
                        <div class="actual-item-info">
                            <span>${item.itemname_cz}</span>
                            <span style="color:green">${'Předmět nalezneš ve svém itemshop skladu.'}</span>
                        </div>
                        <div class="actual-item-final-price">
                            <div>
                            <span>${'Nyní dostupné za:'}</span>
                            <br>
                            ${item.currency === 'DM' ? '<span style="font-size:30px"><img class= "icon-dm" src = "/assets/images/itemshop/kategorie/ikonka dm.png" width = "15px" height = "15px" />' : '<img src="/assets/images/itemshop/kategorie/ikonka dz.png" width="15px" height="15px" />'} ${item.price}</span></span>
                            <br>
                            </div>
                            <button class="buy-btn" id="buy-btn${item.id}">${'KOUPIT'}</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
             `)

        })

        $('.actual-item').on('click', function () {
            isItemModal = true;
            $('#pozadiPres').show();
            console.log($(this))
            inItem = true;
            let modal = $(this).attr('data-target');
            modalNameOpen = modal;
            $(`${modal}`).on('hidden.bs.modal', function () {
                console.log('modalHidden');
                $('html').css('overflow', 'hidden');
                $('#pozadiPres').hide();
            })
        })


        $('.buy-btn').on('click', function () {
            if (disabledbuy == 0) {
                disabledbuy = 1;
                const id = $(this).attr('id');
                //console.log(('#' + id);


                const newId = Number(id.split('').splice(7, 5).join(''));
                fetch('/buyisitem.php?id=' + newId, {
                    method: 'GET',
                    credentials: 'same-origin'
                })
                    .then(res => res.json())
                    .then(data => {

                        getUserInfo()
                        if (data[0].success === true) {
                            showSuccesModal()
                            $('#' + id).attr('disabled', true)
                            $('#' + id).css('opacity', 0.4)
                            setTimeout(() => {
                                $('#' + id).attr('disabled', false);
                                $('#' + id).css('opacity', 1)
                                disabledbuy = 0;
                            }, 2000);

                        } else {
                            showErrorModal()
                            $('#' + id).attr('disabled', true)
                            $('#' + id).css('opacity', 0.4)
                            setTimeout(() => {
                                $('#' + id).attr('disabled', false);
                                $('#' + id).css('opacity', 1)
                                disabledbuy = 0;
                            }, 2000);

                        }

                    })
                    .catch(err => {
                        console.log(err);
                    })
            }


        })

        $('.sipkavpravo').on('click', function () {

            const id = $(this).attr('id');
            const newId = Number(id.split('').splice(5, 5).join(''));
            // console.log(newId);
            const chosenItem = items.find(e => e.id == newId);
            const currentPhoto = chosenItem.currentPhoto;
            //const id = chosenItem.id.split('').splice(0, 5);
            const icons = chosenItem.images;
            const iconAmount = icons.length;
            console.log(icons[chosenItem.currentPhoto])
            if (currentPhoto === iconAmount - 1) {
                $('#photo' + newId.toString()).attr('src', icons[1])
                chosenItem.currentPhoto = 1;
            } else {
                chosenItem.currentPhoto += 1;
                $('#photo' + newId.toString()).attr('src', icons[chosenItem.currentPhoto])
            }
        })

        $('.sipkavlevo').on('click', function () {

            const id = $(this).attr('id');
            const newId = Number(id.split('').splice(4, 5).join(''));
            // console.log(newId);
            const chosenItem = items.find(e => e.id == newId);
            const currentPhoto = chosenItem.currentPhoto;
            //const id = chosenItem.id.split('').splice(0, 5);
            const icons = chosenItem.images;
            const iconAmount = icons.length;
            console.log(icons[chosenItem.currentPhoto])
            if (currentPhoto === 1) {
                $('#photo' + newId.toString()).attr('src', icons[iconAmount - 1])
                chosenItem.currentPhoto = iconAmount - 1;
            } else {
                chosenItem.currentPhoto -= 1;

                $('#photo' + newId.toString()).attr('src', icons[chosenItem.currentPhoto])
            }
        })
    }



})