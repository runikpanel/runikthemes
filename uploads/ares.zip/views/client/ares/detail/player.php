<?php
$name = $this->all["name"];
?>
<div class="update-available">
    <div class="update-inner">
        <div class="update-label">
            <h3><?=$lng[32]?></h3>
        </div>
        <div class="update-available-inner">
            <section id="ucp_top">
				<?php Cache::open($name."_player");?>
				<?php if (Cache::check($name."_player")):?>
					<?php
					$info = $this->all["info"];
					$playerInfo = $info->data[0];
					?>
                    <section id="ucp_info" style="padding-right:15px;padding-left:15px;width: 100%;">
                        <aside class="detail-section">
                            <div class="leader">
                                <img src="<?=URL.'data/chrs/big/'.$playerInfo->job.'/'.Functions::playerPortrait($playerInfo->level).'.png'?>" style="width:200px">
                            </div>
                        </aside>
                        <aside class="detail-section">
                            <table width="100%">
                                <tbody>
                                <tr>
                                    <td width="40%"><?=$lng[35]?> :</td>
                                    <td width="50%" class="wheat"><?=$playerInfo->name?></td>
                                </tr>
                                <tr>
                                    <td width="40%"><?=$lng[68]?> :</td>
                                    <td width="50%" class="wheat"><?=$playerInfo->level?></td>
                                </tr>
                                <tr>
                                    <td width="40%"><?=$lng[37]?> :</td>
                                    <td width="50%" class="wheat"><?=Functions::flagName($playerInfo->empire)[1]?></td>
                                </tr>
                                <tr>
                                    <td width="40%"><?=$lng[66]?> :</td>
                                    <td width="50%" class="wheat"><?= ($playerInfo->lonca == null) ? 'Yok' : $playerInfo->lonca?></td>
                                </tr>
                                </tbody>
                            </table>
                        </aside>
                        <aside class="detail-section">
                            <table width="100%">
                                <tbody>
                                <tr>
                                    <td width="40%"><?=$lng[39]?> :</td>
                                    <td width="50%" class="wheat"><?=Functions::prettyDateTime1($playerInfo->last_play)?></td>
                                </tr>
                                <tr>
                                    <td width="40%"><?=$lng[40]?> :</td>
                                    <td width="50%" class="wheat"><?=$playerInfo->playtime?> <?=$lng[42]?></td>
                                </tr>
                                <tr>
                                    <td width="40%"><?=$lng[41]?> :</td>
                                    <td width="50%" class="wheat"><img src="<?=URL.'data/chrs/small/'.Functions::playerOnlineStatus($playerInfo->last_play).'.png'?>" style="width: 12px;" alt=""></td>
                                </tr>
                                <tr>
                                    <td width="40%"><?=$lng[109]?> :</td>
                                    <td width="50%" class="wheat"><?=Functions::map($playerInfo->map_index)?></td>
                                </tr>
                                </tbody>
                            </table>
                        </aside>
                    </section>
				<?php endif;?>
				<?php Cache::close($name."_player");?>
                <div class="clear"></div>
            </section>
        </div>
    </div>
</div>