</div>
<div class="right-part">
    <a href="<?=URI::get_path('download')?>">
        <div class="download-game">
            <div class="top">
                <img src="<?=URI::public_path("asset/images/top-flower.png")?>" alt="flower" class="img-fluid">
            </div>
            <button class="btn btn-download">
                <span>İNDİR</span>
                Ücretsiz!
            </button>
            <div class="bottom">
                <img src="<?=URI::public_path("asset/images/bottom-flower.png")?>" alt="flower" class="img-fluid">
            </div>
        </div>
    </a>

    <div class="vote-btns">
        <div class="vote-btn-bg">
            <a href="<?=\StaticDatabase\StaticDatabase::settings('facebook')?>" target="_blank">
                <div class="btn btn-vote">
                    <img src="<?=URI::public_path("asset/images/vote-icon.png")?>" alt="icon" class="img-fluid">
                    Facebook Sayfamız
                </div>
            </a>
        </div>
        <div class="vote-btn-bg">
            <a href="<?=\StaticDatabase\StaticDatabase::settings('discord_link')?>" target="_blank">
                <div class="btn btn-coin">
                    <img src="<?=URI::public_path("asset/images/nitemstone.png")?>" alt="icon" class="img-fluid">
                    Discord Adresimiz
                </div>
            </a>
        </div>
    </div>

    <div class="shop-item">
        <img src="<?=URI::public_path("asset/images/shop-image.jpg")?>" alt="shop" class="img-fluid">
        <a href="<?=URL.SHOP?>" class="itemshop itemshop-btn iframe"><button class="btn btn-shop disable-btn"><?=$lng[12]?></button></a>
    </div>

	<?php if (\StaticDatabase\StaticDatabase::settings('event_type') != "3"):?>
    <div class="bottom-table">
        <div class="c-panel-header">
            <h2>EVENT TAKVİMİ</h2>
        </div>
        <div id="ranking_side_player">
			<?php if(\StaticDatabase\StaticDatabase::settings('event_type') == "1"):?>
                <center><iframe src="<?=URI::get_path('event')?>" class="event-frame"></iframe></center>
			<?php else:?>
                <iframe src="<?=URI::get_path('event/dynamic')?>" style="border: none;width: 106%;height: 307px;left: 20px;margin-top: 20px;" id="fancybox-frame"></iframe>
			<?php endif;?>
        </div>
    </div>
	<?php endif;?>


</div>
</div>
</div>
</div>
<!-- content end -->