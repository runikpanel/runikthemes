<?php
$isBanned = $this->all["is_banned"];
$mailActive = $this->all["mail_active"];
?>
<div class="update-available">
    <div class="update-inner">
        <div class="update-label">
            <h3><?=$lng[98]?></h3>
        </div>
        <div class="update-available-inner">
            <form  id="mailActivationForm" action="<?=URI::get_path('profile/aktivechange')?>" method="POST" accept-charset="utf-8" class="page_form" autocomplete="off">
                <table border="0" align="center" width="100%">
                    <tbody>
                    <tr>
                        <td align="center">
                            <label><?=$lng[22]?>
                                <br>
                                <input id="password" type="password" name="password" placeholder="<?=$lng[23]?>">
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <td align="center">
                            <label>
                                <span style="color:darkred;text-shadow:none;"></span>
                                <br>
								<?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <td align="center">
                            <br>
                            <input type="submit" value="<?=$lng[104]?>">
                        </td>
                    </tr>
                    </tbody>
                </table>
            </form>
        </div>
    </div>
</div>
<script>
    $("#mailActivationForm").on("submit", function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                grecaptcha.reset();
                if (response.result)
                    successNotify(response.message);
                else
                    errorNotify(response.message);
            }
        });
    });
</script>