<?php $isBanned = $this->all["is_banned"];?>
<div class="update-available">
    <div class="update-inner">
        <div class="update-label">
            <h3><?=$lng[141]?></h3>
        </div>
        <div class="update-available-inner">
			<?php if ($isBanned):?>
				<?= Client::alert('error', $lng[112]);?>
			<?php else:?>
                <form id="passwordChangeForm" action="<?=URI::get_path('profile/passwordchange')?>" method="post" accept-charset="utf-8" class="page_form" autocomplete="off">
                    <table border="0" align="center" width="100%">
                        <tbody>
                        <tr>
                            <td align="center">
                                <label><?=$lng[165]?>
                                    <br>
                                    <input type="password" name="old_password" id="oldPassword" placeholder="<?=$lng[165]?>">
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <td align="center">
                                <label><?=$lng[166]?>
                                    <br>
                                    <input type="password" name="new_password" id="newPassword" placeholder="<?=$lng[166]?>">
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <td align="center">
                                <label><?=$lng[167]?>
                                    <br>
                                    <input type="password" name="re_password" id="rePassword" placeholder="<?=$lng[167]?>">
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <td align="center">
                                <label>
                                    <span style="color:darkred;text-shadow:none;"></span>
                                    <br>
									<?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <td align="center">
                                <br>
                                <input type="submit" value="<?=$lng[141]?>">
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </form>
			<?php endif;?>
        </div>
    </div>
</div>
<script>
    $("#passwordChangeForm").on("submit", function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                grecaptcha.reset();
                if (response.result)
                    successNotify(response.message);
                else
                    errorNotify(response.message);
            }
        });
    });
</script>