<div class="update-available">
    <div class="update-inner">
        <div class="update-label">
            <h3><?=$lng[98]?></h3>
        </div>
        <div class="update-available-inner">
			<?php if($this->response['result'] == false): ?>
				<?php echo Client::alert('error',$lng[81]);?>
			<?php elseif ($this->response['result'] == true):?>
				<?php echo Client::alert('success',$lng[105]);?>
			<?php endif;?>
        </div>
    </div>
</div>