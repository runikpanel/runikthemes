<?php
$isBanned = $this->all["is_banned"];
$mailActive = $this->all["mail_active"];
?>
<div class="update-available">
    <div class="update-inner">
        <div class="update-label">
            <h3><?=$lng[122]?></h3>
        </div>
        <div class="update-available-inner">
			<?php if ($isBanned):?>
				<?= Client::alert('error',$lng[112]); ?>
			<?php elseif ($mailActive === "1"):?>
                <form id="emailChangeForm" action="<?=URI::get_path('profile/emailchange2')?>" method="POST" class="page_form" autocomplete="off" >
                    <table border="0" align="center" width="100%">
                        <tbody>
                        <tr>
                            <td align="center">
                                <label><?=$lng[23]?>
                                    <br>
                                    <input id="password" type="password" name="password" class="form-control2" placeholder="<?=$lng[23]?>">
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <td align="center">
                                <label>
                                    <span style="color:darkred;text-shadow:none;"></span>
                                    <br>
									<?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <td align="center">
                                <br>
                                <input type="submit" value="<?=$lng[122]?>">
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </form>
			<?php else:?>
                <form id="emailChangeForm" action="<?=URI::get_path('profile/emailchange')?>" method="POST" class="page_form" autocomplete="off" >
                    <table border="0" align="center" width="100%">
                        <tbody>
                        <tr>
                            <td align="center">
                                <label><?=$lng[23]?>
                                    <br>
                                    <input id="password" type="password" name="password" class="form-control2" placeholder="<?=$lng[23]?>">
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <td align="center">
                                <label><?=$lng[133]?>
                                    <br>
                                    <input type="email" id="newMail" name="new_mail" class="form-control2" placeholder="<?=$lng[133]?>">
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <td align="center">
                                <label><?=$lng[134]?>
                                    <br>
                                    <input type="email" id="reMail" name="re_mail" class="form-control2" placeholder="<?=$lng[134]?>">
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <td align="center">
                                <label>
                                    <span style="color:darkred;text-shadow:none;"></span>
                                    <br>
									<?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <td align="center">
                                <br>
                                <input type="submit" value="<?=$lng[122]?>">
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </form>
			<?php endif;?>
        </div>
    </div>
</div>
<script>
    $("#emailChangeForm").on("submit", function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                grecaptcha.reset();
                if (response.result)
                    successNotify(response.message);
                else
                    errorNotify(response.message);
            }
        });
    });
</script>