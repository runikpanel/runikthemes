<div class="update-available">
    <div class="update-inner">
        <div class="update-label">
            <h3><?=$lng[25]?></h3>
        </div>
        <div class="update-available-inner">
			<?php if (isset($aid)):?>
				<?= Client::alert('error',$lng[74]);?>
			<?php else:?>
                <form id="forgetPasswordForm" action="<?=URI::get_path('recuperare/control')?>" method="post" accept-charset="utf-8" class="page_form" autocomplete="off">
                    <table border="0" align="center" width="100%">
                        <tbody>
                        <tr>
                            <td align="center">
                                <label><?=$lng[22]?>
                                    <br>
                                    <input type="text" name="login" id="login" required maxlength="16"/>
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <td align="center">
                                <label><?=$lng[23]?>
                                    <br>
                                    <input type="text" name="email" id="email" placeholder="<?=$lng[78]?>">
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <td align="center">
                                <label>
                                    <span style="color:darkred;text-shadow:none;"></span>
                                    <br>
									<?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <td align="center">
                                <br>
                                <input type="submit" value="<?=$lng[79]?>">
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </form>
            <?php endif;?>
        </div>
    </div>
</div>
<script>
    $("#forgetPasswordForm").on("submit", function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                grecaptcha.reset();
                if (response.result)
                    successNotify(response.message);
                else
                    errorNotify(response.message);
            }
        });
    });
</script>