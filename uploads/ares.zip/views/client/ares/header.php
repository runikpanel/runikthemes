<!DOCTYPE html>
<html lang="en">
<head>

    <!-- Meta start -->
    <meta charset="UTF-8">
    <meta name="robots" content="follow, index"/>
    <meta http-equiv="Content-Language" content="pl"/>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <base href="<?=URL?>">
    <title><?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> - <?=\StaticDatabase\StaticDatabase::settings('slogan')?></title>
    <!-- /meta start -->

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="<?=URL?>favicon.ico" sizes="16x16" />
    <!-- /favicon -->

    <!-- Meta -->
    <meta name="keywords" content="metin2, <?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?>, emek, orta emek, metin, pvp server metin2"/>
    <meta name="description" content="<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> pvp server Metin2 emek/zor."/>
    <!-- /meta -->

    <!-- OpenGraph tags (espec. Facebook) -->
    <meta property="og:type" content="article"/>
    <meta property="og:url" content="<?=URL?>"/>
    <meta property="og:title" content="<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> - Metin2 PVP Server"/>
    <meta property="og:description" content="<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?>-<?=\StaticDatabase\StaticDatabase::settings('slogan')?>. Uzun süre boyunca, hoş dengeli ve ilginç oyun sunuyoruz!"/>
    <meta property="og:image" content="<?=\StaticDatabase\StaticDatabase::settings('logo')?>"/>
    <!-- /openGraph tags -->

    <!-- Bootstrap -->
    <link href="https://fonts.googleapis.com/css2?family=Cinzel&amp;display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:ital,wght@0,300;0,400;0,600;0,700;1,600&amp;display=swap" rel="stylesheet">
    <link href="<?=URI::public_path("asset/css/bootstrap.css")?>" rel="stylesheet">
    <link rel="stylesheet" href="<?=URI::public_path("asset/css/jquery.toast.min.css")?>">

    <!--=== Add By Designer ===-->
    <link href="<?=URI::public_path("asset/css/style.css")?>" rel="stylesheet">
    <link href="<?=URI::public_path("asset/css/responsive.css")?>" rel="stylesheet">
    <link href="<?=URI::public_path("asset/fonts/fonts.css")?>" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?=URI::public_path("asset/css/font-awesome.min.css")?>" rel="stylesheet">
    <link rel="stylesheet" href="<?=URI::public_path()?>main/css/extra.css" type="text/css" media="screen"/>
    <link rel="stylesheet" href="<?=URI::public_path()?>main/css/fancybox.css" type="text/css" media="screen"/>
    <link rel="stylesheet" type="text/css" href="<?=URI::public_path('notify/css/notify.css')?>">
    <link rel="stylesheet" type="text/css" href="<?=URI::public_path('notify/css/prettify.css')?>">


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="<?=URI::public_path("asset/js/jquery-2.2.4.min.js")?>"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?=URI::public_path("asset/js/tether.min.js")?>"></script>
    <script src="<?=URI::public_path("asset/js/bootstrap.min.js")?>"></script>
    <script src="<?=URI::public_path("asset/js/popper.min.js")?>"></script>
    <!-- Object Fit -->

    <script type='text/javascript' src='<?=URI::public_path("asset/js/select.js")?>'></script>
    <script type='text/javascript' src='<?=URI::public_path("asset/js/popuplogin.js")?>'></script>
    <script type='text/javascript' src='<?=URI::public_path("asset/js/ajaxpageloading.js")?>'></script>
    <script type='text/javascript' src='<?=URI::public_path("asset/js/modernizr.js")?>'></script>
    <script type='text/javascript' src='<?=URI::public_path("asset/js/jquery.history.js")?>'></script>
    <script type='text/javascript' src='<?=URI::public_path("asset/js/form-validation.js")?>'></script>
    <script src="<?=URI::public_path("asset/js/main.js")?>" type="text/javascript" charset="utf-8"></script>
    <script src="<?=URI::public_path("asset/js/jquery.easing.1.3.js")?>"></script>
    <script src="<?=URI::public_path("asset/js/jquery.animate-enhanced.min.js")?>"></script>
    <script src="<?=URI::public_path("asset/js/jquery.superslides.js")?>" type="text/javascript" charset="utf-8"></script>
    <script src="<?=URI::public_path("asset/js/lightbox.js")?>"></script>

    <script type="text/javascript" src="<?=URI::public_path('')?>main/js/fancybox.js"></script>
    <script src="<?=URI::public_path()?>main/js/notify.js"></script>
    <script type="text/javascript" src="<?=URI::public_path('notify/js/notify.js')?>"></script>
    <script type="text/javascript" src="<?=URI::public_path('notify/js/prettify.js')?>"></script>
    <script type="text/javascript" src="<?=URI::public_path('notify/js/notify-function.js')?>"></script>

    <script src='https://www.google.com/recaptcha/api.js'></script>

    <script type="text/javascript">
        $(document).ready(function () {
            var screenSize = $(window).height();
            var compareW = 767;
            if (screenSize > 0 && screenSize < compareW) {
                var fancy_a = 740;
                var fancy_b = 550;
                var fancy_c = "ishopbg-small";
                var fancy_d = "13px";
                var fancy_e = "3px";
                var fancy_f = "13px";
                var fancy_g = 754;
                var fancy_h = 574;
                var fancy_i = 6;
                var fancy_j = 20;
            }
            else
            {
                var fancy_a = 1016;
                var fancy_b = 655;
                var fancy_c = "ishopbg";
                var fancy_d = "16px";
                var fancy_e = "7px";
                var fancy_f = "16px";
                var fancy_g = 1032;
                var fancy_h = 690;
                var fancy_i = 8;
                var fancy_j = 28;
            }
            var fancybox_css = {
                'outer': {'background': null},
                'close': {'background_image': null, 'height': null, 'right': null, 'top': null, 'width': null}
            };
            $('a.itemshop').fancybox({
                'autoDimensions': false,
                'width': fancy_a,
                'height': fancy_b,
                'padding': 0,
                'scrolling': 'yes',
                'overlayColor': '#000',
                'overlayOpacity': 0.8,
                'onStart': function () {
                    fancybox_css.outer.background = $('#fancybox-outer').css('background');
                    fancybox_css.close.background_image = $('#fancybox-close').css('background-image');
                    fancybox_css.close.height = $('#fancybox-close').css('height');
                    fancybox_css.close.right = $('#fancybox-close').css('right');
                    fancybox_css.close.top = $('#fancybox-close').css('top');
                    fancybox_css.close.width = $('#fancybox-close').css('width');
                    $('#fancybox-outer').css({'background': 'transparent url("<?=URI::public_path('')?>static/images/'+fancy_c+'.png") center center no-repeat'});
                    $('#fancybox-close').css({
                        'background-image': 'none',
                        'cursor': 'pointer',
                        'height': fancy_d,
                        'right': '3px',
                        'top': fancy_e,
                        'width': fancy_f
                    });
                },
                'onComplete': function () {
                    $('#fancybox-inner').css({'top': fancy_j, 'left': fancy_i});
                    $('#fancybox-wrap').css({'width': fancy_g, 'height': fancy_h});
                },
                'onClosed': function () {
                    if (null != fancybox_css.outer.background) {
                        $('#fancybox-outer').css('background', fancybox_css.outer.background);
                    }
                    if (null != fancybox_css.close.background_image) {
                        $('#fancybox-close').css('background-image', fancybox_css.close.background_image);
                    }
                    if (null != fancybox_css.close.height) {
                        $('#fancybox-close').css('height', fancybox_css.close.height);
                    }
                    if (null != fancybox_css.close.right) {
                        $('#fancybox-close').css('right', fancybox_css.close.right);
                    }
                    if (null != fancybox_css.close.top) {
                        $('#fancybox-close').css('top', fancybox_css.close.top);
                    }
                    if (null != fancybox_css.close.width) {
                        $('#fancybox-close').css('width', fancybox_css.close.width);
                    }
                }
            });
        });
    </script>
</head>
<body>















