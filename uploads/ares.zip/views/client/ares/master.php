<?php
$sId = Session::get('sId');
$urlLang = isset($_GET['url']) ? $_GET['url'] : null;
$urlLang = rtrim($urlLang,'/');
$urlLang = filter_var($urlLang,FILTER_SANITIZE_URL);
$urlLang = explode('/', $urlLang);
if($sId == null){
	Session::set('sId','site');
}
$aid = isset($_SESSION['aid']) ? $_SESSION['aid'] : null;
if (isset($aid)){
	$getAin = Statistics::getCashAndMileage($aid);
}

if (Cache::check('server_statistics')){
	if (\StaticDatabase\StaticDatabase::settings('total_online_status')){
		$getCount['totalOnline'] = Statistics::online();
	}

	if (\StaticDatabase\StaticDatabase::settings('total_player_status')){
		$getCount['totalPlayer'] = Statistics::player();
	}

	if (\StaticDatabase\StaticDatabase::settings('total_account_status')){
		$getCount['totalAccount'] = Statistics::account();
	}

	if (\StaticDatabase\StaticDatabase::settings('today_login_status')){
		$getCount['todayLogin'] = Statistics::todayLogin();
	}

	if (\StaticDatabase\StaticDatabase::settings('active_pazar_status')){
		$getCount['activePazar'] = Statistics::offlineShop();
	}
}

if (Cache::check('player_ranking')){
	$result['topplayer'] = Statistics::topPlayer(5);
}

if (Cache::check('guild_ranking')){
	$result['topguild'] =  Statistics::topGuild(5);
}
?>
<?php if (\StaticDatabase\StaticDatabase::settings('multi_languages')):?>
	<?php
	$getLanguage = \StaticDatabase\StaticDatabase::init()->prepare("SELECT * FROM language");
	$getLanguage->execute();
	$languagesS = $getLanguage->fetchAll(PDO::FETCH_ASSOC);
	?>
    <style>
        .languagepicker {
            background-color: #FFF;
            display: inline-block;
            padding: 0;
            height: 40px;
            overflow: hidden;
            transition: all .3s ease;
            margin: 30px 0 0 0;
            vertical-align: top;
            float: left;
            position: fixed;
            right: 0px;
            z-index: 999;
        }

        .languagepicker:hover {
            /* don't forget the 1px border */
            height: 81px;
        }

        .languagepicker a{
            color: #000;
            text-decoration: none;
        }

        .languagepicker li {
            display: block;
            padding: 0px 10px;
            line-height: 40px;
            border-top: 1px solid #EEE;
        }

        .languagepicker li:hover{
            background-color: #EEE;
        }

        .languagepicker a:first-child li {
            border: none;
            background: #FFF !important;
        }

        .languagepicker li img {
            margin-top: 7px;
        }

        .roundborders {
            -webkit-border-top-left-radius: 5px;
            -webkit-border-bottom-left-radius: 5px;
            -moz-border-radius-topleft: 5px;
            -moz-border-radius-bottomleft: 5px;
            border-top-left-radius: 5px;
            border-bottom-left-radius: 5px;
        }

        .large:hover {
            height: <?=count($languagesS) * 45?>px;
        }
    </style>
    <ul class="languagepicker roundborders large">
		<?php foreach ($languagesS as $languages):?>
			<?php if ($languages['code'] === $_SESSION['language']):?>
                <a href="#nl"><li><img src="<?=URL."data/flags/country/".$languages['code'].".png"?>"/></li></a>
			<?php endif;?>
		<?php endforeach;?>
		<?php foreach ($languagesS as $languages):?>
			<?php if ($languages['code'] !== $_SESSION['language']):?>
                <a href="<?=URI::get_path('languages/select/'.$languages['code'])?>"><li><img src="<?=URL."data/flags/country/".$languages['code'].".png"?>"/></li></a>
			<?php endif;?>
		<?php endforeach;?>
    </ul>
<?php endif;?>
<style>
    .logo-header .logo
    {
        display: block;
        margin-right: auto;
        margin-left: auto;
        width: <?=\StaticDatabase\StaticDatabase::settings('logo_width')?>;
        left: <?=\StaticDatabase\StaticDatabase::settings('logo_position_x')?>;
        right: 0;
        position: relative;
        filter: <?=\StaticDatabase\StaticDatabase::settings('logo_filter')?>;
        top: <?=\StaticDatabase\StaticDatabase::settings('logo_position_y')?>;
    }

    .logo:hover
    {
        filter: <?=\StaticDatabase\StaticDatabase::settings('logo_hover')?>;
    }
</style>
<div class="wrap">
    <!-- header start -->
    <header class="header clearfix">
        <nav class="navigation-custom">
            <div class="navigation-inner">
                <ul class="left-menu">
                    <li><a href="<?=URI::get_path('index')?>"><?=$lng[8]?></a></li>
					<?php if (isset($_SESSION['aid'])):?>
                        <li><a href="<?=URI::get_path('profile')?>"><?=$lng[19]?></a></li>
					<?php else:?>
                        <li><a href="<?=URI::get_path('register')?>"><?=$lng[10]?></a></li>
					<?php endif;?>
                    <li><a href="<?=URI::get_path('download')?>"><?=$lng[0]?></a></li>
                </ul>
                <div class="logo">
                    <a href="<?=URI::get_path('index')?>" class="logo-header">
                        <img src="<?=\StaticDatabase\StaticDatabase::settings('logo')?>" alt="logo" class="logo">
                    </a>
                </div>
                <ul class="right-menu">
                    <li><a href="<?=URI::get_path('ranked/player')?>">Sıralama</a></li>
                    <li><a class="itemshop itemshop-btn iframe" href="<?=URL.MUTUAL?>"><?=$lng[13]?></a></li>
                    <li><a href="<?=\StaticDatabase\StaticDatabase::settings('tanitim')?>"><?=$lng[184]?></a></li>
                </ul>
            </div>
        </nav>
    </header>
    <!-- header end -->

    <!-- content start -->
    <div class="content clearfix">
        <div class="container">
            <div class="content-main">
                <div class="left-part">
					<?php if (isset($_SESSION['aid'])):?>
                        <div class="login">
                            <h2>Hesabım</h2>
                            <div class="login-block p-block">
                                <center style="line-height: 1.5;">
									<?=$lng[22]?> <b><?=Session::get('cLogin')?></b><br>
									<?=$lng[17]?> <b><?=$getAin[CASH]?> EP</b><br>
									<?=$lng[17]?> <b><?=$getAin[MILEAGE]?> EM</b>

                                    <div class="kayip-buttonlar2">
                                        <a href="<?=URI::get_path('profile')?>"><div class="btn account-btn"><?=$lng[19]?></div></a>
                                        <a href="<?=URI::get_path('login/logout')?>"><div class="btn account-btn"><?=$lng[20]?></div></a>
                                    </div>
                                </center>
                            </div>
                        </div>
					<?php else:?>
					<?php if ($urlLang[0] != 'register' && $urlLang[0] != 'login' && $urlLang[0] != 'recuperare'):?>
                            <div class="login">
						    <?php if (\StaticDatabase\StaticDatabase::settings('pin_status') !== "1"): ?>
                                <h2>Giriş Yap</h2>
							<?php endif;?>
                                <form method="post" action="<?=URI::get_path('login/control')?>" id="loginForm" accept-charset="utf-8" onkeypress="return event.keyCode != 13;" autocomplete="off">
                                    <div class="form-group">
                                        <input id="login_input" type="text" class="form-control" name="login" placeholder="<?=$lng[22]?>" maxlength="16" autocomplete="off">
                                    </div>
                                    <div class="form-group">
                                        <input type="password" class="form-control" name="password" placeholder="<?=$lng[23]?>" id="password_input" maxlength="20" autocomplete="off">
                                    </div>
						            <?php if (\StaticDatabase\StaticDatabase::settings('pin_status') === "1"): ?>
                                        <div class="form-group">
                                            <input type="password" class="form-control" placeholder="PIN" name="pin" id="pin" maxlength="<?=\StaticDatabase\StaticDatabase::settings('pin_count')?>" autocomplete="off">
                                        </div>
									<?php endif;?>
                                    <div class="g-recaptcha rc-anchor-blue" data-theme="dark" style="transform:scale(0.81);-webkit-transform:scale(0.81);transform-origin:0 0;-webkit-transform-origin:0 0;" data-sitekey="<?=\StaticDatabase\StaticDatabase::settings('sitekey')?>"></div>
                                    <div class="form-group">
                                        <a href="<?=URI::get_path('recuperare')?>" class="forgot"><?=$lng[25]?></a>
                                    </div>
                                    <button type="submit" class="btn login-btn">Giriş Yap</button>
                                    <a href="<?=URI::get_path('register')?>"><div class="btn account-btn">Kaydol</div></a>
                                </form>
                                <script>
                                    $("#loginForm").on('submit', function (event) {
                                        event.preventDefault();

                                        var url = $(this).attr("action");
                                        var data = $(this).serialize();

                                        $.ajax({
                                            url : url,
                                            type : 'POST',
                                            data : data,
                                            dataType : 'json',
                                            success : function (response) {
                                                if (response.result)
                                                    window.location.href = response.redirect;
                                                else
                                                {
                                                    errorNotify(response.message);
                                                    grecaptcha.reset();
                                                }
                                            }
                                        });
                                    });
                                </script>
                            </div>
						<?php endif;?>
					<?php endif;?>

					<?php if (\StaticDatabase\StaticDatabase::settings('active_pazar_status') != 0 || \StaticDatabase\StaticDatabase::settings('today_login_status') != 0 || \StaticDatabase\StaticDatabase::settings('total_account_status') != 0 || \StaticDatabase\StaticDatabase::settings('total_player_status') != 0):?>
					<?php Cache::open('server_statistics');?>
					<?php if (Cache::check('server_statistics')):?>
                        <div class="bottom-table">
                            <div class="c-panel-header">
                                <h2><?=$lng[2]?></h2>
                            </div>
                            <div id="ranking_side_player">
                                <table class="table">
                                    <center>
										<?php if (\StaticDatabase\StaticDatabase::settings('total_online_status')):?>
                                            <tr class="c1">
                                                <td class="pname"><i><b><?=$lng[3]?>:</i></b></td>
                                                <td class="score"><font id="online_oyuncu" class=""><?=$getCount['totalOnline']['count'] + \StaticDatabase\StaticDatabase::settings('online')?></font><br></td>
                                            </tr>
										<?php endif;?>
										<?php if (\StaticDatabase\StaticDatabase::settings('active_pazar_status')):?>
                                            <tr class="c1">
                                                <td class="pname"><i><b><?=$lng[7]?>:</i></b></td>
                                                <td class="score"><font id="online_oyuncu" class=""><?=$getCount['activePazar']['count'] + \StaticDatabase\StaticDatabase::settings('activepazar')?></font><br></td>
                                            </tr>
										<?php endif;?>
										<?php if (\StaticDatabase\StaticDatabase::settings('today_login_status')):?>
                                            <tr class="c1">
                                                <td class="pname"><i><b><?=$lng[7]?>:</i></b></td>
                                                <td class="score"><font id="online_oyuncu" class=""><?=$getCount['todayLogin']['count'] + \StaticDatabase\StaticDatabase::settings('todaylogin')?></font><br></td>
                                            </tr>
										<?php endif;?>
										<?php if (\StaticDatabase\StaticDatabase::settings('total_account_status')):?>
                                            <tr class="c1">
                                                <td class="pname"><i><b><?=$lng[7]?>:</i></b></td>
                                                <td class="score"><font id="online_oyuncu" class=""><?=$getCount['totalAccount']['count'] + \StaticDatabase\StaticDatabase::settings('totalaccount')?></font><br></td>
                                            </tr>
										<?php endif;?>
										<?php if (\StaticDatabase\StaticDatabase::settings('total_player_status')):?>
                                            <tr class="c1">
                                                <td class="pname"><i><b><?=$lng[7]?>:</i></b></td>
                                                <td class="score"><font id="online_oyuncu" class=""><?=$getCount['totalPlayer']['count'] + \StaticDatabase\StaticDatabase::settings('totalplayer')?></font><br></td>
                                            </tr>
										<?php endif;?>
                                    </center>
                                </table>
                            </div>
                        </div>
						<?php endif;?>
						<?php Cache::close('server_statistics');?>
					<?php endif;?>

                    <div class="bottom-table">
                        <div class="c-panel-header">
                            <h2><?=$lng[176]?></h2>
                        </div>
                        <div id="ranking_side_player">
                            <table class="table">
                                <tbody>
								<?php Cache::open('player_ranking');?>
								<?php if (Cache::check('player_ranking')):?>
									<?php if (count($result['topplayer']) != 0):?>
										<?php foreach ($result['topplayer'] as $key=>$row):?>
                                            <tr class="c1">
                                                <td class="pname"><i><b><?=$key+1?></i></b></td>
                                                <td class="pname"><a href="<?=URI::get_path('detail/player/'.$row['name'])?>"><?=$row['name']?></a></td>
                                                <td class="score"><font id="online_oyuncu" class=""><?=$row['level']?></font><br></td>
                                            </tr>
										<?php endforeach;?>
									<?php endif;?>
								<?php endif;?>
								<?php Cache::close('player_ranking')?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="bottom-table">
                        <div class="c-panel-header">
                            <h2><?=$lng[177]?></h2>
                        </div>
                        <div id="ranking_side_player">
                            <table class="table">
                                <tbody>
								<?php Cache::open('guild_ranking');?>
								<?php if (Cache::check('guild_ranking')):?>
									<?php if (count($result['topguild']) != 0):?>
										<?php foreach ($result['topguild'] as $key2=>$row2):?>
                                            <tr class="c1">
                                                <td class="pname"><i><b><?=$key2+1?></i></b></td>
                                                <td class="pname"><a href="<?=URI::get_path('detail/guild/'.$row2['name'])?>"><?=$row2['name']?></a></td>
                                                <td class="score"><font id="online_oyuncu" class=""><?=$row2["ladder_point"];?></font><br></td>
                                            </tr>
										<?php endforeach;?>
									<?php endif;?>
								<?php endif;?>
								<?php Cache::close('guild_ranking')?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>
                <div class="middle-part">
                    <div class="top-banner-middle">
                        <img src="<?=URI::public_path("asset/images/top-banner-img.png")?>" alt="top-banner-img">
                    </div>
