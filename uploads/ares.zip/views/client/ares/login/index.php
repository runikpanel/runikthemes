<div class="update-available">
    <div class="update-inner">
        <div class="update-label">
            <h3><?=$lng[21]?></h3>
        </div>
        <div class="update-available-inner">

            <form  id="loginForm" class="page_form" action="<?=URI::get_path('login/control')?>" method="POST" autocomplete="off">
                <table border="0" align="center" width="100%">
                    <tbody>
                    <tr>
                        <td align="center">
                            <label><?=$lng[22]?>
                                <br>
                                <input type="text" name="login" id="login" required maxlength="16"/>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <td align="center">
                            <label><?=$lng[23]?>
                                <br>
                                <input type="password" name="password" id="password"/>
                            </label>
                        </td>
                    </tr>
					<?php if (\StaticDatabase\StaticDatabase::settings('pin_status') === "1"): ?>
                        <tr>
                            <td align="center">
                                <label>PIN
                                    <span style="color:darkred;text-shadow:none;"></span>
                                    <br>
                                    <input type="password" name="pin" id="pin" maxlength="<?=\StaticDatabase\StaticDatabase::settings('pin_count')?>"/>
                                </label>
                            </td>
                        </tr>
					<?php endif;?>
                    <tr>
                        <td align="center">
                            <label>
                                <span style="color:darkred;text-shadow:none;"></span>
                                <br>
								<?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <td align="center">
                            <br>
                            <input type="submit" value="<?=$lng[21]?>">
                        </td>
                    </tr>
                    </tbody>
                </table>
            </form>
        </div>
    </div>
</div>
<script>
    $("#loginForm").on('submit', function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                if (response.result)
                    window.location.href = response.redirect;
                else
                {
                    errorNotify(response.message);
                    grecaptcha.reset();
                }
            }
        });
    });
</script>