function successNotify(text) {
    $.notify(text, {align:"right", color: "#fff", background: "#20D67B"});
}

function errorNotify(text) {
    $.notify(text, {align:"right", color: "#fff", background: "#D44950"});
}