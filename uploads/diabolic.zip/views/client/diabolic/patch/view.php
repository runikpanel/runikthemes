<?php
$patchInfo = $this->all["patch"];
?>
<div class="content_wrapper left">
    <div class="real_content">
		<?php Cache::open($patchInfo->id."_patch"); ?>
		<?php if (Cache::check($patchInfo->id."_patch")): ?>
            <h2 class="headline_news active"><span class="title"><?= $patchInfo->title ?></span></h2>
            <div class="p4px" style="display: block;">
                <div class="real_content">
                    <div class="inner_content news_content">
                        <p>
                        </p>
                        <p>
							<?=$patchInfo->content?>
                        </p>
                        <br>
                        <p></p>
                    </div>
                </div>
            </div>
		<?php endif; ?>
		<?php Cache::close($patchInfo->id."_patch"); ?>
    </div>
</div>