<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <base href="<?=URL?>">
    <title><?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> - <?= \StaticDatabase\StaticDatabase::settings('slogan')?></title>

    <meta name="keywords" content="<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> metin2,metin2 pvp, metin2 pvp serverler,metin2 emek server,metin2 emek" />
    <meta name="description" content="<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?>" />
    <meta name="robots" content="index,follow" />
    <meta name="copyright" content="" />
    <meta name="language" content="Turkish" />
    <meta property="og:locale" content="tr_TR" />
    <meta property="og:type" content="article" />
    <meta property="og:title" content="<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?>" />
    <meta property="og:description" content="<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?>" />
    <meta property="og:url" content="<?=URL?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="shortcut icon" sizes="16x16 32x32" href="<?=URL.'favicon.ico'?>">

    <link rel="stylesheet" href="<?=URI::public_path('assets/css/css-reset.css')?>">
    <link rel="stylesheet" href="<?=URI::public_path('assets/css/style.css')?>">
    <link rel="stylesheet" href="<?=URI::public_path('assets/css/extra.css')?>">
    <link rel="stylesheet" href="<?=URI::public_path('assets/css/fancybox.css')?>">
    <link rel="stylesheet" href="<?=URI::public_path('main/css/extra.css')?>">
    <link rel="stylesheet" href="<?=URI::public_path('notify/css/notify.css')?>">
    <link rel="stylesheet" href="<?=URI::public_path('notify/css/prettify.css')?>">

    <script src='https://www.google.com/recaptcha/api.js'></script>
</head>
<body>
