<div class="col-md-9"><div class="col-md-12 no-padding">
        <div class="panel panel-buyuk">
            <div class="panel-heading"><?=$lng[25]?></div>
            <div class="panel-body">
				<?php if (isset($aid)):?>
					<?= Client::alert('error',$lng[74]);?>
				<?php else:?>
                <form id="forgetPasswordForm" action="<?=URI::get_path('recuperare/control')?>" method="POST" class="form-horizontal" autocomplete="off">
                    <div class="form-group">
                        <label for="login" class="col-sm-3 control-label"><?=$lng[22]?> </label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" name="login" id="login" maxlength="30">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="email" class="col-sm-3 control-label"><?=$lng[78]?></label>
                        <div class="col-sm-6">
                            <input type="email" class="form-control" name="email" id="email" maxlength="30">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="reCaptcha" class="col-sm-3 control-label"><?=$lng[24]?></label>
                        <div class="col-sm-6">
							<?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-offset-3 col-sm-6">
                            <button type="submit" class="btn btn-giris" style="margin-top: 10px;"> <?=$lng[79]?></button>
                        </div>
                    </div>
                </form>
				<?php endif;?>
            </div>
        </div>
    </div>
</div>
<script>
    $("#forgetPasswordForm").on("submit", function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                grecaptcha.reset();
                if (response.result)
                    successNotify(response.message);
                else
                    errorNotify(response.message);
            }
        });
    });
</script>