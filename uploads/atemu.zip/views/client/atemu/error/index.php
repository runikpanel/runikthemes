<div class="col-md-9">
    <div class="col-md-12 no-padding" style="min-height: 1150px;">
        <div class="panel panel-buyuk">
            <div class="panel-heading">404 !</div>
            <div class="panel-body" style="text-align:center;">
                <p>
                </p><h1>404</h1>
				<?=$lng[60]?> <br>
                <p></p>
            </div>
        </div>
    </div>
</div>