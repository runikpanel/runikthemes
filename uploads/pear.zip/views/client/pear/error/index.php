<style>
    .main404 {
        position: relative;
        height: 500px;
        margin: 10px;
        font-weight: bold;
        text-align: center;
    }

    .sub404{
        position: absolute;
        left: 50%;
        top: 30%;
        transform: translate(-50%, -30%);
        color:#bfb3a9;

    }
</style>
<div class="title">
    404 Error
</div>
<div class="news page">
    <div class="main404">
        <div class="sub404">
            <h1 style="font-size:52px;font-weight:bold">404</h1>
			<?=$lng[60]?>
        </div>
    </div>
</div>