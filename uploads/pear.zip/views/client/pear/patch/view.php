<?php
$patchInfo = $this->all["patch"];
?>
<?php Cache::open($patchInfo->id."_patch");?>
<?php if (Cache::check($patchInfo->id."_patch")):?>
    <div class="title">
		<?=$patchInfo->title?>
    </div>
    <div class="news page">
        <div class="main-inner main-inner-news">
            <div class="main-text-bg">
                <div style="float: right;color: #83bb6d"><?=Functions::prettyDateTime1($patchInfo->tarih);?></div>
                <br><br>
                <div class="main-text">
					<?=$patchInfo->content?>
                </div>
            </div>
        </div>
    </div>
<?php endif;?>
<?php Cache::close($patchInfo->id."_patch");?>