<?php
$patchInfo = $this->all["patch"];
?>
<main class="content">
    <div class="panel panel-buyuk">
        <div class="panel-heading">
			<?php Cache::open($patchInfo->id."_patch");?>
			<?php if (Cache::check($patchInfo->id."_patch")):?>
                <div style="text-align: center">
					<?=$patchInfo->title?>
                </div>
                <div style="text-align: right;font-size: 12px;color:#798127">
					<?=Functions::prettyDateTime1($patchInfo->tarih);?>
                </div>
                <br>
                <span style="font-size: 13px;">
					<?=$patchInfo->content?>
                </span>
			<?php endif;?>
			<?php Cache::close($patchInfo->id."_patch");?>
        </div>
    </div>
</main>