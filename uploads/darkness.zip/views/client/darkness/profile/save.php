<?php
$isBanned = $this->all["is_banned"];
$playerInfo = $this->all["player_info"];
$randomKey = Functions::generateRandomString(32);
Session::setHash(['bug_key'=>$randomKey]);
?>
<div class="content_wrapper left">
    <div class="real_content">
        <h2 class="headline_news active"><span class="title"><?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> | <?=$lng[106]?></span></h2>
        <div class="p4px" style="display: block;">
            <div class="real_content">
                <div class="inner_content news_content">
					<?php if ($playerInfo->count <= 0):?>
						<?=Client::alert('warning',$lng[107]);?>
					<?php else:?>
						<?php foreach ($playerInfo->data as $player):?>
							<?php
							$bugHash = md5($player->name.$randomKey);
							?>
                            <div id="profileBox" class="player-table">
                                <div class="player-row">
                                    <img src="<?=URL.'data/chrs/medium/'.$player->job.'.png'?>" alt="<?=Functions::jobName($player->job);?>" style="    display: block;margin-left: auto;margin-right: auto;">
                                    <center>
                                        <span style="font: normal 18px 'Palatino Linotype', 'Times', serif; text-transform: none;"><?=$player->name?></span>
                                    </center>
                                    <br>
                                    <center>
                                        <span><?=$lng[109]?> : <?=Functions::map($player->map_index);?></span>
                                    </center>
                                    <a href="<?=URI::get_path('profile/saved/'.$player->name.'/'.$bugHash);?>" class="center-block">
                                        <input type="button" class="btn" style="margin-top: 10px;margin-right: auto;margin-left: auto;display: block;" value="<?=$lng[110]?>">
                                    </a>
                                </div>
                            </div>
						<?php endforeach;?>
					<?php endif;?>
                </div>
            </div>
        </div
    </div>
</div>
</div>