<?php
$guildInfo = $this->all["info"];
$name = $this->all["name"];
$guildMembers = $this->all["members"];
?>
<div class="content_wrapper left">
    <div class="real_content">
		<?php Cache::open($name."_guild");?>
		<?php if (Cache::check($name."_guild")):?>
            <h2 class="headline_news active"><span><?=$name?> | <?=$lng[43]?></span></h2>
            <div class="p4px" style="display: block;">
                <div class="real_content">
                    <div class="inner_content news_content">
                        <br>
                        <div style="clear:both"></div>
                        <div class="value">
                            <br>
                            <div class="table">
                                <div class="row">
                                    <div class="cell CharRight">
                                        <div class="main-title CharChild"><?=$lng[175]?></div>
                                        <div class="childrow"><span><?=$lng[46]?>:</span> <?=$guildInfo->name?></div>
                                        <div class="childrow"><span><?=$lng[47]?>:</span> <?=$guildInfo->ladder_point?></div>
                                        <div class="childrow"><span> EXP:</span> <?=$guildInfo->exp?></div>
                                        <div class="childrow"><span><?=$lng[48]?>:</span> <img src="<?=URL.'data/flags/'.$guildInfo->empire.'.png';?>" style="width:30px;" alt="<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?>"> </div>
                                        <div class="childrow"><span><?=$lng[49]?>:</span> <b><?=$guildInfo->win?></b> </div>
                                        <div class="childrow"><span><?=$lng[50]?>:</span> <b><?=$guildInfo->draw?></b> </div>
                                        <div class="childrow"><span><?=$lng[51]?>:</span> <?=$guildInfo->loss?> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
		<?php endif;?>
		<?php Cache::close($name."_guild");?>
    </div>
</div>
