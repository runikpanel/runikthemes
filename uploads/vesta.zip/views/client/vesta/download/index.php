<?php
$packList = $this->all;
?>
<div class="col-md-9"><div class="col-md-12 no-padding">
        <div class="panel panel-buyuk">
            <div class="panel-heading"><?=$lng[0]?>
            </div>
            <div class="panel-body">
				<?php foreach ($packList->data as $key => $pack):?>
                    <div class="modal fade" id="Indir_<?=$key?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                    <h4 class="modal-title" id="myModalLabel"><?=$lng[183]?></h4>
                                </div>
                                <div class="modal-body">
								<textarea class="sozlesme_txt" readonly="">
⚹ Her oyuncu hesap bilgilerini gizli tutmakla yükümlüdür.
⚹ Bir hesabı sadece hesabın kayıtlı olduğu mail adresinin sahibi kullanabilir (hesap paylaşılamaz, satılamaz, devir edilemez ve ortak kullanılamaz) <?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> takımı kaybedilen veya çalınan eşyaların iadesini yapmayacaktır.
⚹ Hesap bilgilerinin bir başkası tarafından kullanılması ve bilinmesi tamamıyle sizin sorumluluğunuzdadır. (hesap satmaya teşebbüs etmek, ortak kullanmak, Skype Facebook benzeri yerlerden ve kişilerden dosya almak bunların verdiği linklere tıklamak, şahısların vermiş olduğu sahte sitelere girmek ve bilgilerinizi oradaki formlara girmek, hesap satın almak veya teşebbüs etmek, aldığınız hesabı kullanmak.) Bu durum, oyun sözleşmesinin 1. maddesi hesap bilgilerini gizli tutmamak, sahip çıkmamak ve aşağıda belirtilen ortak hesap kullanımı yada hesap alım satım takası suçlarının vuku bulduğu anlamına gelir. Buna istinaden ticket ile başvuru yaptığınızda çalındığını idda ettiğiniz hesap ve karşı tarafın bütün hesapları süresiz kapatılır. Sizede hesap iade edilmez. (Uyarılarımızı dikkate almayıp düştüğünüz durumdur ve bu sizinde kesinlikle kural ihlali yaptığınız anlamına gelir.)
⚹ Eğer bir açık bulup bunu kendinize avantaj sağlamak için kullanırsanız oyun hesabınız süresiz olarak kapatılır.
⚹ Bulunan tüm oyun ve programlama açıkları derhal Destek Sistemi kullanılarak oyun takımına iletilmelidir.
⚹ Servislerin herhangi birinde (Facebook,Youtube,Forum, IRC, vb) gösterilen uygunsuz davranışların oyun içerisinde verilecek cezalarla sonuçlanabileceğini hesaba katmanız faydalı olacaktır.
⚹ <?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> takımı olarak 'biz', herhangi bir duyuru veya bildirim yapmadan oyun kurallarında herhangi bir zamanda değişiklik yapma/revize etme hakkını saklı tutarız.
⚹ Genel Kullanım Şartları kuralların üzerindedir ve kurallarla bütün halde uygulanır.
⚹ Hiç bir oyuncu oyuna ait hiç bir ortamda diğer oyuncuları gerçek hayata yönelik olarak tehdit edemez ve gerçek hayata yönelik eylemlere zorlayamaz.
⚹ Oyuna yönelik tehditler bu madde kapsamı dışındadır. Herhangi bir oyuncuyu, takım üyesini, <?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> görevlisini, yada herhangi bir şekilde oyun servisleri ile ilgili birini bulup ona zarar verileceğine yönelik imalar ve söylemler kesinlikle yasaktır.
⚹ <?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> sunucularının resmi dili Türkçedir. Oyun Sunucuları, Forum, resmi IRC kanalları bu kurala dahildir ancak bu kural yalnızca bu alanlarla sınırlı değildir.
⚹ Sohbette kaba/argo dil kullanımı ve küfür yasaktır. Spam (Sürekli olarak aynı mesajın tekrarlanması), www.<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?>.com oyun ve forum linkleri dışındaki linklerin paylaşılması, hile reklamı, hile talebi, yang satış reklamı vs. yasaktır.
⚹ Oyun takımının kararları için itiraz ancak Destek Sistemi üzerinden yapılabilir.
⚹ Destek sistemi üzerinden bir konu ile ilgili tek bir ticket açarak bildirim yapmalısınız.
⚹ Aynı ticket üzerinden cevap gelmeden tekrar tekrar yazmanız cevap alma sürenizi geciktirmekten başka bir fayda sağlamayacaktır.
⚹ Oyunun kullanıcı hesabı ve materyallerini gerçek para ile satmaya kalkışmak, satmak ve satın almak gibi eylemler kesinlikle yasaktır. Hiç bir kullanıcının böyle bir hakkı yoktur.
⚹ Detaylı incelemelere sonucu bu faaliyette bulunan kullanıcıların hesapları süresiz olarak kapatılır!
⚹ Eğer bir oyuncunun kurallara aykırı hareket ettiğini düşünüyorsanız bunu video kaydı alarak Destek Sistemi üzerinden en geç 2 gün içinde yönetime iletiniz.
⚹ Aksi halde şikayetiniz işleme konulmayacaktır.Bu yüzden oyundaki sol üst köşedeki tarih göstergesini kapatmayınız! Oyundaki sağ taraftaki server ismi kesinlikle gözükmelidr.Aksi halde şikayetiniz bu yüzdende işleme konulmayacaktır. <?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> takımı ilgili şikayetinizi inceleyerek, kural ihlali olup olmadığına karar verecek ve gerekiyorsa ceza sisteminde belirtilen yaptırımı uygulayacaktır.
⚹ Eğer bir oyun yöneticisinin kurallara aykırı hareket ettiğini düşünüyorsanız bunu ilgili delilleri ile birlikte ticket yoluyla bir üst yönetiye iletebilirsiniz.
⚹ Nesnelerin kontör & TL ile ticareti yasaktır.Bu tarz satış yapan ve alan kullanıcılar tespit edildiğinde karakteri süresiz olarak kapatılacaktır.
⚹ Bu tarz satış yapan kişiden nesne alanda kullanıcıların kontör & TL yollayıp nesnesini vermez ise veya tam tersi nesne verip kontör & TL yollamaz ise <?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> yönetimine hiçbir hak talep edemez.(Bu sebepten dolayı hesabı kısıtlanan oyuncu ve/veya oyuncular – lonca veya topluluklar yasal olarak hiçbir hak talep edemezler ve suç duyurusunda bulunamazlar.)
⚹ <?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> yöneticileri kullanıcı hesaplarını sebepsiz olarak açabilir ya da kapatabilir.
⚹ Bu insiyatif yöneticiler de bulunmaktadır.
⚹ Yasal talep gelmesi durumunda, <?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> oyunu, sitesi, bağlı bulunduğu şirket veya bağlı ortaklarına karşı hukuki uygunluk durumlarında, oyunu ve firmanın haklarını korumak ve müdafaa gerektiren durumlarda, olağandışı veya acil durumlarda, firmanın, oyunun ve halkın güvenliğini korumaya yönelik işlemlerde kişisel bilgiler ifşa edilebilir.
⚹ Kayıt olan her kullanıcı oyunun kurallarına uyacağına ve uymadığı taktir de hesabının kapatılacağını onaylar. Oyun kurallarına buradan erişilebilir.
⚹ Kayıt olan her kullanıcı, yukarıdaki maddeleri okuduğunu, uygulayacağını ve kullanıcı sözleşmesini kabul ettiğini taahhüt eder!
⚹ <?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> bu kuralları istediği anda haber vermeden değiştirme hakkını saklı tutar.
⚹ Bu üyelik ve hizmet sözleşmesi sayfası en son 04.01.2017 tarihinde güncellenmiştir.
⚹ Bu gizlilik politikasıyla ilgili herhangi bir sorunuz varsa, aşağıdaki bilgileri kullanarak bizimle iletişime geçebilirsiniz. info@<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?>.com
                                </textarea>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default" data-dismiss="modal"><?=$lng[177]?></button>
                                    <a href="<?=$pack->url?>" target="_new" class="btn btn-giris"><?=$lng[184]?></a>
                                </div>
                            </div>
                        </div>
                    </div>
				<?php endforeach;?>
                <table class="table table-striped table-hover">

                    <tbody>
					<?php foreach ($packList->data as $key => $pack):?>
                        <tr>
                            <td><?=$pack->name;?> <br><small><?=$lng[53]?> : <?=$pack->size;?></small></td>
                            <td><img src="<?=$pack->image?>" alt="<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?>" width="70px;" style=" margin-top: 12px;"></td>
                            <td style="vertical-align:middle;text-align:right;"><button class="btn btn-giris" data-toggle="modal" data-target="#Indir_<?=$key?>"><i class="glyphicon glyphicon-download-alt"></i> &nbsp; <?=$lng[0]?></button></td>
                        </tr>
					<?php endforeach;?>

                    </tbody>
                </table>
            </div>
        </div>

        <div class="panel panel-buyuk">
            <div class="panel-heading">Sistem Gereksinimleri</div>
            <div class="panel-body">
                <table class="table table-bordered">
                    <thead>
                    <tr>
                        <td><b>Bileşen Adı</b></td>
                        <td><b>En Düşük Gereksinim</b></td>
                        <td><b>Orta Derece Gereksinim</b></td>
                    </tr>
                    </thead>
                    <tbody>

                    <tr>
                        <td>Boş Alan (HDD)</td>
                        <td>2GB</td>
                        <td>3GB ve üzeri</td>
                    </tr>
                    <tr>
                        <td>Bellek (RAM)</td>
                        <td>2GB</td>
                        <td>4GB ve üzeri</td>
                    </tr>
                    <tr>
                        <td>İşlemci (CPU)</td>
                        <td>Pentium 3 , 1GHz</td>
                        <td>İntel core i3 ve üzeri</td>
                    </tr>
                    <tr>
                        <td>Ekran Kartı (GPU)</td>
                        <td>512Mb</td>
                        <td>1Gb ve üzeri</td>
                    </tr>
                    <tr>
                        <td>İşletim Sistemi</td>
                        <td>Win XP</td>
                        <td>Win 7 ve üzeri</td>
                    </tr>
                    <tr>
                        <td>DirectX</td>
                        <td>9</td>
                        <td>9 ve üzeri</td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>