</div>
<div class="row">
    <div class="col-md-12">
        <div class="footer">
            <div class="footer_ust hidden-xs">
                <ul>
                    <li><a href="<?=URI::get_path('download')?>"><?=$lng[0]?></a></li>
                    <li><a href="<?=URI::get_path('ranked/player')?>"><?=$lng[65]?></a></li>
                    <li><a href="<?=URI::get_path('ranked/guild')?>"><?=$lng[66]?></a></li>
                    <li><a href="<?=URI::get_path('privacy')?>"><?=$lng[171]?></a></li>
                    <li><a class="itemshop itemshop-btn iframe" href="<?=URL.MUTUAL?>"><?=$lng[146]?></a></li>
                    <li><a class="itemshop itemshop-btn iframe" href="<?=URL.SHOP?>"><?=$lng[147]?></a></li>
                    <li><a target="_blank" href="<?=\StaticDatabase\StaticDatabase::settings('facebook')?>">Facebook</a></li>
                    <li><a target="_blank" href="<?=\StaticDatabase\StaticDatabase::settings('forum')?>"><?=$lng[14]?></a></li>
                    <li><a target="_blank" href="<?=\StaticDatabase\StaticDatabase::settings('tanitim')?>"><?=$lng[175]?></a></li>
                </ul>
                <div style="clear:both"></div>
            </div>
            <div style="clear:both;"></div>
            <div class="col-md-12">
                <div class="col-md-6 col-md-offset-3">
                    <div class="text-center" style="margin-top: 5px;margin-bottom: 5px;color: #b1b1b1">
                        Copyright &copy; by <a href="<?=\StaticDatabase\StaticDatabase::settings('footer_link')?>"><?=\StaticDatabase\StaticDatabase::settings('footer_name')?></a> - <?=date("Y")?><br />
                        Tüm hakları saklıdır ve <a href="<?=URI::get_path('index')?>"><?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?></a> mülkiyetindedir.<br/>
                        <a href="https://payreks.com" target="_blank" title="Metin2 PVP Ödeme Sistemleri">Payreks</a> - +90 850 840 99 39 - <a href="mailto:bilgi@payreks.com">bilgi@payreks.com</a>
                        <a href="https://payreks.com" target="_blank"><img src="https://development.payreks.com/assets/images/logo-white-mini.png" style="display: block;width: 100px;margin-right: auto;margin-left: auto;" alt="Metin2 PVP Ödeme Sistemleri"></a>
                    </div>
                </div>

            </div>

        </div>
    </div>
</div>
</div>
</div>
<?php if (\StaticDatabase\StaticDatabase::settings('discord_status') == "1"):?>
    <style>

        .discord-widget {
            position: fixed;
            bottom: 0;
            z-index:10;
        }


        .discord-widget.active
        {
            right: 20px;
        }
    </style>
    <a class="discord-widget animated bounceInLeft" href="<?php echo \StaticDatabase\StaticDatabase::settings('discord_link')?>" title="Join us on Discord">
        <img src="https://discordapp.com/api/guilds/<?php echo \StaticDatabase\StaticDatabase::settings('discord_id')?>/embed.png?style=<?php echo \StaticDatabase\StaticDatabase::settings('discord_theme')?>">
    </a>
<?php endif;?>
<?php if (\StaticDatabase\StaticDatabase::settings('tawkto_status') == "1"):?>
    <!--Start of Tawk.to Script-->
    <script type="text/javascript">
        var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
        (function(){
            var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
            s1.async=true;
            s1.src='https://embed.tawk.to/'+"<?php echo \StaticDatabase\StaticDatabase::settings('tawkto_id')?>"+'/default';
            s1.charset='UTF-8';
            s1.setAttribute('crossorigin','*');
            s0.parentNode.insertBefore(s1,s0);
        })();
    </script>
    <!--End of Tawk.to Script-->
<?php endif;?>
<?php if (\StaticDatabase\StaticDatabase::settings('gtag_status') == "1"):?>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=<?= \StaticDatabase\StaticDatabase::settings('gtag_id')?>"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', '<?= \StaticDatabase\StaticDatabase::settings('gtag_id')?>');
    </script>
    <!-- Global site tag (gtag.js) - Google Analytics -->
<?php endif;?>

<div id="yukari" class="yukari_don" data-toggle="tooltip" data-placement="left" title="" data-original-title="Sayfanın başına dönmek için tıklayınız." style="display: none"><i class="glyphicon glyphicon-chevron-up"></i></div>
<script>
    $(window).scroll(function(){
        if ($(this).scrollTop() > 100)
            $("#yukari").fadeIn(500);
        else
            $("#yukari").fadeOut(500);
    });
    $(document).ready(function(){
        $("#yukari").click(function(){
            $("html, body").animate({ scrollTop: "0" }, 1000);
            return false;
        });
    });
</script>
<script>
    $(document).ready(function () {
        if ($(window).width() < 540) {
            document.getElementById('fb').style.display = 'none';
        }else{
            setTimeout(function () {
                $('#fbLoading').fadeOut(function () {
                    $('#fbContent').fadeIn(function () {

                    })
                });
            }, 3500);
        }
    });
</script>
<script>
    function textonly(e,id){
        var code;
        if (!e) var e = window.event;
        if (e.keyCode) code = e.keyCode;
        else if (e.which) code = e.which;
        var character = String.fromCharCode(code);
//alert('Character was ' + character);
        //alert(code);
        //if (code == 8) return true;
        var AllowRegex  = /^[\ba-zA-Z0-9\s-]$/;
        if (AllowRegex.test(character)){
            return true;
        }else{
            $(id).notify(
                "Sadece harf ve rakam",
                { position:"right" }
            );
            return false;
        }
    }
    $('#pass2').change(function () {
        var pass = $('#pass').val();
        var pass2 = $(this).val();
        if(pass != pass2){
            document.getElementById('passOk').style.display = "none";
            document.getElementById('passNo').style.display = "";
            $('#pass2').notify(
                "Şifreler uyuşmuyor !",
                { position:"right" }
            );
        }else{
            document.getElementById('passNo').style.display = "none";
            document.getElementById('passOk').style.display = "";
        }
    });
    $('#pass').change(function () {
        var pass = $('#pass2').val();
        var pass2 = $(this).val();
        if(pass != ''){
            if(pass != pass2){
                document.getElementById('passOk').style.display = "none";
                document.getElementById('passNo').style.display = "";
                $('#pass2').notify(
                    "Şifreler uyuşmuyor !",
                    { position:"right" }
                );
            }else{
                document.getElementById('passNo').style.display = "none";
                document.getElementById('passOk').style.display = "";
            }
        }
    });
    function textonly2(e,id){
        var code;
        if (!e) var e = window.event;
        if (e.keyCode) code = e.keyCode;
        else if (e.which) code = e.which;
        var character = String.fromCharCode(code);
//alert('Character was ' + character);
        //alert(code);
        //if (code == 8) return true;
        var AllowRegex  = /^[\ba-z-A-ZÇİĞÖŞÜçığöşü\s-]$/;
        if (AllowRegex.test(character)){
            return true;
        }else{
            $(id).notify(
                "Sadece harf !",
                { position:"right" }
            );
            return false;
        }
    }
    function numberonly(e,id){
        var code;
        if (!e) var e = window.event;
        if (e.keyCode) code = e.keyCode;
        else if (e.which) code = e.which;
        var character = String.fromCharCode(code);
//alert('Character was ' + character);
        //alert(code);
        //if (code == 8) return true;
        var AllowRegex  = /^[\b0-9\s-]$/;
        if (AllowRegex.test(character)){
            return true;
        }else{
            $(id).notify(
                "Sadece rakam !",
                { position:"right" }
            );
            return false;
        }
    }
    $('#question').mouseover(function () {
        document.getElementById('question2').style.display="";
    });
    $('#question').mouseout(function () {
        document.getElementById('question2').style.display="none";
    });
</script>
</body>
</html>