<?php
$patchInfo = $this->all["patch"];
?>
<div class="col-md-9">
    <div class="col-md-12 no-padding">
		<?php Cache::open($patchInfo->id."_patch"); ?>
		<?php if (Cache::check($patchInfo->id."_patch")): ?>
            <div class="panel panel-buyuk">
                <div class="panel-heading"><?= $patchInfo->title ?>
                    <small class="pull-right"><?= Functions::prettyDateTime1($patchInfo->tarih); ?> </small>
                </div>
                <div class="panel-body">
					<?= $patchInfo->content ?>
                </div>
            </div>
		<?php endif; ?>
		<?php Cache::close($patchInfo->id."_patch"); ?>
    </div>
</div>