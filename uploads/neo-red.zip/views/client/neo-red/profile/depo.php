<?php
$isBanned = $this->all["is_banned"];
$mailActive = $this->all["mail_active"];
?>
<div class="col-md-9"><div class="col-md-12 no-padding">
        <div class="panel panel-buyuk">
            <div class="panel-heading"><?=$lng[111]?></div>
            <div class="panel-body">
				<?php if ($isBanned):?>
				<?= Client::alert('error',$lng[112]); ?>
				<?php elseif ($mailActive === "0"):?>
				<?= Client::alert('error',$lng[113])?>
                <a href="<?=URI::get_path('profile/aktive')?>" ><button type="submit" class="center-block btn btn-grunge"><?=$lng[114]?></button></a>
				<?php else:?>
                <form id="safeBoxPasswordForm" action="<?=URI::get_path('profile/depochange')?>" method="POST" class="form-horizontal" autocomplete="off">
                    <div class="form-group">
                        <label for="password" class="col-sm-3 control-label"><?=$lng[23]?></label>
                        <div class="col-sm-6">
                            <input type="password" class="form-control" name="password" id="password">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="reCaptcha" class="col-sm-3 control-label"><?=$lng[24]?></label>
                        <div class="col-sm-6">
							<?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-offset-3 col-sm-6">
                            <button type="submit" class="btn btn-giris" style="margin-top: 10px;"> <?=$lng[119]?></button>
                        </div>
                    </div>
                </form>
				<?php endif;?>
            </div>
        </div>
    </div>
</div>
<script>
    $("#safeBoxPasswordForm").on("submit", function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                grecaptcha.reset();
                if (response.result)
                    successNotify(response.message);
                else
                    errorNotify(response.message);
            }
        });
    });
</script>