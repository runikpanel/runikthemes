<style>
    .select-box{
        background: url(http://gf2.geo.gfsrv.net/cdnac/a29fbb433fe4ad8ae6273a65f290e0.gif) repeat-x;
        border: 1px solid #622400;
        color: #534236;
        font-family: Arial, Helvetica, sans-serif;
        font-size: 16px;
        font-weight: bold;
        height: 32px;
        padding: 5px 10px;
        width: 265px;
    }
</style>
<div role="main">
    <div id="login" class="content content-last">
        <div class="content-bg">
            <div class="content-bg-bottom">
                <h2><?=$lng[10];?></h2>
                <div class="inner-form-border">
                    <div class="inner-form-box">
                        <div class="trenner"></div>
						<?php if (\StaticDatabase\StaticDatabase::settings('register_status') == "0"):?>
							<?php echo Client::alert('error','Kayıtlarımız şuanda kapalıdır!');?>
						<?php else:?>
                            <form id="registerForm" id="loginForm" action="<?=URI::get_path('register/control')?>" method="POST" autocomplete="off">
                                <div>
                                    <label for="login"><?=$lng[22]?>: *</label>
                                    <input type="text" name="login" id="login" required maxlength="16">
                                </div>
                                <div>
                                    <label for="password"><?=$lng[23]?>: *</label>
                                    <input type="password" id="password" name="password" required maxlength="32">
                                </div>
                                <div>
                                    <label for="password2"><?=$lng[94]?>: *</label>
                                    <input type="password" id="password2" name="password2" required maxlength="32">
                                </div>
								<?php if (\StaticDatabase\StaticDatabase::settings('pin_status') === "1"): ?>
                                    <div>
                                        <label for="pin">PIN: *</label>
                                        <input type="password" id="pin" name="pin" required maxlength="<?=\StaticDatabase\StaticDatabase::settings('pin_count')?>">
                                    </div>
								<?php endif;?>
                                <div>
                                    <label for="email"><?=$lng[78]?>: *</label>
                                    <input type="email"name="email" id="email" required>
                                </div>
                                <div>
                                    <label for="name"><?=$lng[95]?>: *</label>
                                    <input type="text" name="name" id="name" required>
                                </div>
                                <div>
                                    <label for="ksk"><?=$lng[96]?>: *</label>
                                    <input type="text" id="ksk" name="ksk"  maxlength="7" required>
                                </div>
                                <div>
                                    <label for="phone"><?=$lng[97]?>: *</label>
                                    <input type="text" id="phone" name="phone" maxlength="10" placeholder="555-555-55-55" required>
                                </div>
								<?php if (\StaticDatabase\StaticDatabase::settings('findme_status') === "1"): ?>
                                <div>
									<?php
									$findMeList = \StaticDatabase\StaticDatabase::init()->prepare("SELECT * FROM findme_list");
									$findMeList->execute();
									?>
                                    <label for="password">Bizi nerden buldunuz?: *</label>
                                    <select name="findme" class="select-box">
                                        <option value="0" selected>Lütfen seçiniz...</option>
										<?php foreach ($findMeList->fetchAll(PDO::FETCH_ASSOC) as $row):?>
                                            <option value="<?=$row["id"]?>"><?=$row["name"]?></option>
										<?php endforeach;?>
                                    </select>
                                </div>
								<?php endif;?>
                                <div>
                                    <label for="password"><?=$lng[24]?>: *</label>
                                    <script src='https://www.google.com/recaptcha/api.js'></script>
                                    <div class="g-recaptcha rc-anchor-dark" style="transform: scale(0.90);margin-left: -17px;" data-sitekey="<?=\StaticDatabase\StaticDatabase::settings('sitekey')?>"></div>
                                </div>
                                <div style="margin-bottom: 20px;"><span>Kayıt olarak <a href="<?=URI::get_path('privacy/index')?>" target="_blank" style="color: #478528;">üyelik sözleşmesini</a> kabul ederim.</span></div>
                                <input id="submitBtn" class="btn-big" type="submit" name="SubmitLoginForm" value="<?= $lng[10] ?>">
                            </form>
                        <?php endif;?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $('#pass2').change(function () {
        var pass = $('#pass').val();
        var pass2 = $(this).val();
        if(pass != pass2){
            document.getElementById('passOk').style.display = "none";
            document.getElementById('passNo').style.display = "";
            $('#pass2').notify(
                "Şifreler uyuşmuyor !",
                { position:"right" }
            );
        }else{
            document.getElementById('passNo').style.display = "none";
            document.getElementById('passOk').style.display = "";
        }
    });

    $("#registerForm").on("submit", function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                if (response.result)
                {
                    successNotify(response.message);
                    setTimeout(function () {
                        window.location.href = response.redirect;
                    },2000)
                }
                else
                {
                    errorNotify(response.message);
                    grecaptcha.reset();
                }
            }
        });
    });
</script>