<div role="main" id="guildHighscore">
    <div class="content content-last">
        <div class="content-bg">
            <div class="content-bg-bottom">
                <h2><?=$lng[66]?></h2>
                <div class="ranks-inner-content"><br>
                    <div class="ranks-nav prev prev-top">&nbsp;</div>

                    <div class="ranks-nav next next-top"><a href="javascript:void(0)"></a></div>
                    <br class="clearfloat">
                    <div class="bg-dark">
                        <div class="col-50">
                            <a class="btn" href="<?=URI::get_path('ranked/guild')?>" style="float: left;margin-right: 50px;margin-left: 50px;margin-bottom: 15px;margin-top: 15px;"><?=$lng[66]?></a>
                        </div>
                        <div class="col-50">
                            <a class="btn active" href="javascript:void(0);" style="float: left;margin-right: 50px;margin-left: 50px;margin-bottom: 15px;margin-top: 15px;"><?=$lng[65]?></a>
                        </div>
                    </div>
                    <br>
                    <br>
                    <br>
					<?php if (\StaticDatabase\StaticDatabase::settings('guild_rank_status') == "0"):?>
						<?php  echo Client::alert('error',"Lonca sıralaması şuanda kapalı!");?>
					<?php else:?>
                        <table border="0" style="table-layout:fixed">
                            <thead>
                            <tr>
                                <th class="rank-th-1"><?=$lng[178]?></th>
                                <th class="rank-th-2"><?=$lng[38]?></th>
                                <th class="rank-th-3"><?=$lng[44]?></th>
                                <th class="rank-th-4"><?=$lng[48]?></th>
                                <th class="rank-th-5"><?=$lng[47]?></th>
                                <th class="rank-th-5"><?=$lng[72]?></th>
                            </tr>
                            </thead>
                            <tbody>
							<?php Cache::open('guilds');?>
							<?php if (Cache::check('guilds')):?>
								<?php foreach ($this->all->data as $key => $guild):?>
									<?php if ($key % 2 == 0):?>
                                        <tr class="rankfirst zebra">
                                            <td class="rank-td-1-1"><?=($key+1)?></td>
                                            <td class="rank-td-1-2"><?=$guild->lonca?></td>
                                            <td class="rank-td-1-4"><?=$guild->baskan?></td>
                                            <td class="rank-td-1-3"><img src="<?=URL.'data/flags/'.$guild->bayrak.'.png'?>" width="34"></td>
                                            <td class="rank-td-1-5"><?=$guild->ladder_point;?></td>
                                            <td class="rank-td-1-5">
                                                <span class="label label-green"><?=$guild->win?></span> |
                                                <span class="label label-draw"><?=$guild->draw?></span> |
                                                <span class="label label-red"><?=$guild->loss?></span>
                                            </td>
                                        </tr>
									<?php else:?>
                                        <tr>
                                            <td class="rank-td-1-1"><?=($key+1)?></td>
                                            <td class="rank-td-1-2"><?=$guild->lonca?></td>
                                            <td class="rank-td-1-4"><?=$guild->baskan?></td>
                                            <td class="rank-td-1-3"><img src="<?=URL.'data/flags/'.$guild->bayrak.'.png'?>" width="34"></td>
                                            <td class="rank-td-1-5"><?=$guild->ladder_point;?></td>
                                            <td class="rank-td-1-5">
                                                <span class="label label-green"><?=$guild->win?></span> |
                                                <span class="label label-draw"><?=$guild->draw?></span> |
                                                <span class="label label-red"><?=$guild->loss?></span>
                                            </td>
                                        </tr>
									<?php endif;?>
								<?php endforeach;?>
							<?php endif;?>
							<?php Cache::close('guilds');?>
                            </tbody>
                        </table>
                    <?php endif;?>
                    <div class="clearfloat"></div>
                    <div class="box-foot"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="shadow">&nbsp;</div>
</div>
