<div role="main" id="highscore">
<div class="content content-last">
    <div class="content-bg">
        <div class="content-bg-bottom">
            <h2><?=$lng[65]?></h2>
            <div class="ranks-inner-content"><br>
                <div class="ranks-nav prev prev-top">&nbsp;</div>

                <div class="ranks-nav next next-top"><a href="javascript:void(0)"></a></div>
                <br class="clearfloat">
                <div class="bg-dark">
                    <div class="col-50">
                        <a class="btn active" href="javascript:void(0);" style="float: left;margin-right: 50px;margin-left: 50px;margin-bottom: 15px;margin-top: 15px;"><?=$lng[65]?></a>
                    </div>
                    <div class="col-50">
                        <a class="btn" href="<?=URI::get_path('ranked/guild')?>" style="float: left;margin-right: 50px;margin-left: 50px;margin-bottom: 15px;margin-top: 15px;"><?=$lng[66]?></a>
                    </div>
                </div>
                <br>
                <br>
                <br>
				<?php if (\StaticDatabase\StaticDatabase::settings('player_rank_status') == "0"):?>
					<?php  echo Client::alert('error',"Oyuncu sıralaması şuanda kapalı!");?>
				<?php else:?>
                    <table border="0" style="table-layout:fixed">
                        <thead>
                        <tr>
                            <th class="rank-th-1"><?=$lng[178]?></th>
                            <th class="rank-th-2"><?=$lng[35]?></th>
                            <th class="rank-th-4"><?=$lng[68]?></th>
                            <th class="rank-th-5"><?=$lng[69]?></th>
                            <th class="rank-th-3"><?=$lng[37]?></th>
                            <th class="rank-th-6"><?=$lng[33]?></th>
                            <th class="rank-th-7"><?=$lng[41]?></th>
                        </tr>
                        </thead>
                        <tbody>
						<?php Cache::open('players');?>
						<?php if (Cache::check('players')):?>
							<?php foreach ($this->all->data as $key => $player):?>
								<?php if ($key % 2 == 0):?>
                                    <tr class="rankfirst zebra">
                                        <td class="rank-td-1-1"><?=($key+1)?></td>
                                        <td class="rank-td-1-2"><?=$player->name?></td>
                                        <td class="rank-td-1-4">
                                            <?=$player->level?>
                                        </td>
                                        <td class="rank-td-1-4">
											<?php if ($player->guild_name != null):?>
                                                <?=$player->guild_name;?>
											<?php else:?>
                                                <b style="color: #8b303d"><?=$lng[70]?>
											<?php endif;?>
                                        </td>
                                        <td class="rank-td-1-3">
                                            <img src="<?=URL.'data/flags/'.$player->empire.'.png'?>" width="34">
                                        </td>
                                        <td>
                                            <img src="<?=URL.'data/chrs/small/'.$player->job.'.png'?>" alt="<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?>">
                                        </td>
                                        <td>
                                            <center>
                                                <img class="class-portrait" src="<?=URL.'data/chrs/small/'.Functions::playerOnlineStatus($player->last_play).'.png'?>"/>
                                            </center>
                                        </td>
                                    </tr>
								<?php else:?>
                                    <tr>
                                        <td class="rank-td-1-1"><?=($key+1)?></td>
                                        <td class="rank-td-1-2"><?=$player->name?></td>
                                        <td class="rank-td-1-4">
											<?=$player->level?>
                                        </td>
                                        <td class="rank-td-1-4">
											<?php if ($player->guild_name != null):?>
												<?=$player->guild_name;?>
											<?php else:?>
                                            <b style="color: #8b303d"><?=$lng[70]?>
												<?php endif;?>
                                        </td>
                                        <td class="rank-td-1-3">
                                            <img src="<?=URL.'data/flags/'.$player->empire.'.png'?>" width="34">
                                        </td>
                                        <td>
                                            <img src="<?=URL.'data/chrs/small/'.$player->job.'.png'?>" alt="<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?>">
                                        </td>
                                        <td>
                                            <center>
                                                <img class="class-portrait" src="<?=URL.'data/chrs/small/'.Functions::playerOnlineStatus($player->last_play).'.png'?>"/>
                                            </center>
                                        </td>
                                    </tr>
								<?php endif;?>
							<?php endforeach;?>
						<?php endif;?>
						<?php Cache::close('players');?>
                        </tbody>
                    </table>
                <?php endif;?>
                <div class="clearfloat"></div>
                <div class="box-foot"></div>
            </div>
        </div>
    </div>
</div>
</div>