<div role="main">
<center>
    <div class="inner-form-border" style="margin:0px;"><div class="inner-form-box">
            <h4 style="font-size: 230px;">404</h4>
			<p style="font-size: 20px;font-weight: 900">
				<?=$lng[60]?>
            </p>
        </div>
    </div>
</center>
</div>