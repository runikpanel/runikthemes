<?php
$isBanned = $this->all["is_banned"];
$mailActive = $this->all["mail_active"];
?>
<div role="main">
    <div id="login" class="content content-last">
        <div class="content-bg">
            <div class="content-bg-bottom">
                <h2><?=$lng[153]?></h2>
                <div class="inner-form-border">
                    <div class="inner-form-box">
                        <div class="trenner"></div>
						<?php if ($isBanned):?>
						<?= Client::alert('error',$lng[112]); ?>
						<?php elseif ($mailActive === "0"):?>
						<?= Client::alert('error',$lng[113])?>
                        <a href="<?=URI::get_path('profile/aktive')?>" ><button type="submit" class="center-block btn btn-grunge"><?=$lng[114]?></button></a>
						<?php else:?>
                        <form id="kskChangeForm" class="form-horizontal" action="<?=URI::get_path('profile/kskchange')?>" method="POST" autocomplete="off">
                            <div>
                                <label for="password"><?=$lng[23]?>: *</label>
                                <input type="password" id="password" name="password" value="">
                            </div>
                            <div>
                                <label for="reCpatcha"><?=$lng[24]?>: *</label>
                                <script src='https://www.google.com/recaptcha/api.js'></script>
                                <div class="g-recaptcha rc-anchor-dark" style="    transform: scale(0.90);margin-left: -17px;" data-sitekey="<?=\StaticDatabase\StaticDatabase::settings('sitekey')?>"></div>
                            </div>
                            <input id="submitBtn" class="btn-big" type="submit" name="SubmitLoginForm" value="<?= $lng[21] ?>">
                        </form>
						<?php endif;?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $("#kskChangeForm").on("submit", function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                grecaptcha.reset();
                if (response.result)
                    successNotify(response.message);
                else
                    errorNotify(response.message);
            }
        });
    });
</script>