<?php
$isBanned = $this->all["is_banned"];
$playerInfo = $this->all["player_info"];
$randomKey = Functions::generateRandomString(32);
Session::setHash(['bug_key'=>$randomKey]);
?>
<div role="main">
    <div id="register" class="content content-last">
        <div class="content-bg">
            <div class="content-bg-bottom">
                <h2><?=$lng[106]?></h2>
                <div class="row" style="margin: 0px;">
                    <div class="inner-form-border">
                        <div class="inner-form-box">
							<?php if ($playerInfo->count <= 0):?>
								<?=Client::alert('warning',$lng[107]);?>
							<?php else:?>
                                <h3><?=$lng[108]?></h3>
								<?php foreach ($playerInfo->data as $player):?>
									<?php
									$bugHash = md5($player->name.$randomKey);
									?>
                                    <div id="profileBox" class="player-table">
                                        <div class="player-row">
                                            <img src="<?=URL.'data/chrs/medium/'.$player->job.'.png'?>" alt="<?=Functions::jobName($player->job);?>" style="    display: block;margin-left: auto;margin-right: auto;">
                                            <center><span style="font: normal 18px 'Palatino Linotype', 'Times', serif; text-transform: none;color: wheat"><?=$player->name?></span></center><br>
                                            <center><span><?=$lng[109]?> : <?=Functions::map($player->map_index);?></span></center>
                                            <a href="<?=URI::get_path('profile/saved/'.$player->name.'/'.$bugHash);?>">
                                                <button class="btn" style="margin-top: 10px;"><?=$lng[110]?></button>
                                            </a>
                                        </div>
                                    </div>
								<?php endforeach;?>
							<?php endif;?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>