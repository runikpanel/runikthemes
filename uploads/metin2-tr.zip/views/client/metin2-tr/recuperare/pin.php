<div role="main">
    <div id="login" class="content content-last">
        <div class="content-bg">
            <div class="content-bg-bottom">
                <h2>PIN Unuttum</h2>
                <div class="inner-form-border">
                    <div class="inner-form-box">
                        <div class="trenner"></div>
						<?php if (isset($aid)):?>
							<?= Client::alert('error',$lng[74]);?>
						<?php else:?>
                            <form id="forgetPINForm" action="<?=URI::get_path('recuperare/control3')?>" class="form-horizontal" method="POST" autocomplete="off">
                                <div>
                                    <label for="login"><?=$lng[22]?>: *</label>
                                    <input type="text" id="login" name="login"">
                                </div>
                                <div>
                                    <label for="email"><?=$lng[78]?>: *</label>
                                    <input type="text" id="email" name="email">
                                </div>
                                <div>
                                    <label for="password"><?=$lng[24]?>: *</label>
                                    <script src='https://www.google.com/recaptcha/api.js'></script>
                                    <div class="g-recaptcha rc-anchor-dark" style="    transform: scale(0.90);margin-left: -17px;" data-sitekey="<?=\StaticDatabase\StaticDatabase::settings('sitekey')?>"></div>
                                </div>
                                <input id="submitBtn" class="btn-big" type="submit" name="SubmitLoginForm" value="<?= $lng[79] ?>">
                            </form>
						<?php endif;?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $("#forgetPINForm").on("submit", function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                grecaptcha.reset();
                if (response.result)
                    successNotify(response.message);
                else
                    errorNotify(response.message);
            }
        });
    });
</script>