<?php $isBanned = $this->all["is_banned"];?>
<div style="float: left; width: 665px; margin-left:20px;">
    <div style="float: left; margin-top: 10px;">
        <div class="windows windows-wbTop"></div>
        <div class="windows windows-wbCenter">
            <div class="content" style="padding-left:20px; padding-right:20px;">
                <span class="title"><?=$lng[141]?></span>
                <!-- register -->
                <div class="store-activity">
                    <div class="container_3 account-wide" align="center">
                        <p style="padding: 20px;">
                            <!-- FORMS -->
                        </p>
						<?php if ($isBanned):?>
							<?= Client::alert('error', $lng[112]);?>
						<?php else:?>
                            <form id="passwordChangeForm" action="<?=URI::get_path('profile/passwordchange')?>" method="POST" autocomplete="off">
                                <div class="seperator"></div>
                                <div class="row">
                                    <label for="oldPassword"><?=$lng[165]?>:</label>
                                    <input type="password" class="form-control grunge" name="old_password" required>
                                </div>
                                <div class="row">
                                    <label for="newPassword"><?=$lng[166]?>:</label>
                                    <input type="password" class="form-control grunge" name="new_password" required>
                                </div>
                                <div class="row">
                                    <label for="rePassword"><?=$lng[167]?>:</label>
                                    <input type="password" class="form-control grunge" name="re_password" required>
                                </div>
                                <div class="seperator"></div>
                                <div class="row">
									<?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                                </div>
                                <div class="row" style="margin-top: 30px;">
                                    <div class="wbuttons wbuttons-buttonBorder">
                                        <input type="submit" value="<?=$lng[141]?>" class="wbuttons wbuttons-bt" AutoCompleteType="None" />
                                    </div>
                                </div>
                            </form>
						<?php endif;?>
                        <br />
                        <br />
                        <br />
                        <!-- FORMS.End -->
                    </div>
                </div>
                <!-- register.End -->
            </div>
        </div>
        <div class="windows windows-wbBottom"></div>
    </div>
</div>
<script>
    $("#passwordChangeForm").on("submit", function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                grecaptcha.reset();
                if (response.result)
                    successNotify(response.message);
                else
                    errorNotify(response.message);
            }
        });
    });
</script>