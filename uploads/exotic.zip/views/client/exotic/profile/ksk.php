<?php
$isBanned = $this->all["is_banned"];
$mailActive = $this->all["mail_active"];
?>
<div style="float: left; width: 665px; margin-left:20px;">
    <div style="float: left; margin-top: 10px;">
        <div class="windows windows-wbTop"></div>
        <div class="windows windows-wbCenter">
            <div class="content" style="padding-left:20px; padding-right:20px;">
                <span class="title"><?=$lng[153]?></span>
                <!-- register -->
                <div class="store-activity">
                    <div class="container_3 account-wide" align="center">
                        <p style="padding: 20px;">
                            <!-- FORMS -->
                        </p>
						<?php if ($isBanned):?>
						<?= Client::alert('error',$lng[112]); ?>
						<?php elseif ($mailActive === "0"):?>
						<?= Client::alert('error',$lng[113])?>
                        <a href="<?=URI::get_path('profile/aktive')?>" ><button type="submit" class="center-block btn btn-grunge"><?=$lng[114]?></button></a>
						<?php else:?>
                            <form id="kskChangeForm" action="<?=URI::get_path('profile/kskchange')?>" method="POST" autocomplete="off">
                                <div class="seperator"></div>
                                <div class="row">
                                    <label for="password"><?=$lng[23]?>:</label>
                                    <input type="password" id="password" name="password" placeholder="<?=$lng[23]?>" required>
                                </div>
                                <div class="seperator"></div>
                                <div class="row">
									<?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                                </div>
                                <div class="row" style="margin-top: 30px;">
                                    <div class="wbuttons wbuttons-buttonBorder">
                                        <input type="submit" value="<?=$lng[156]?>" class="wbuttons wbuttons-bt" AutoCompleteType="None" />
                                    </div>
                                </div>
                            </form>
						<?php endif;?>
                        <br />
                        <br />
                        <br />
                        <!-- FORMS.End -->
                    </div>
                </div>
                <!-- register.End -->
            </div>
        </div>
        <div class="windows windows-wbBottom"></div>
    </div>
</div>
<script>
    $("#kskChangeForm").on("submit", function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                grecaptcha.reset();
                if (response.result)
                    successNotify(response.message);
                else
                    errorNotify(response.message);
            }
        });
    });
</script>