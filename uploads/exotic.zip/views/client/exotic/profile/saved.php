<?php
$response = $this->result;
?>
<div style="float: left; width: 665px; margin-left:20px;">
    <div style="float: left; margin-top: 10px;">
        <div class="windows windows-wbTop"></div>
        <div class="windows windows-wbCenter">
            <div class="content" style="padding-left:20px; padding-right:20px;">
                <span class="title"><?=$lng[110]?></span>
                <!-- register -->
                <div class="store-activity">
                    <div class="container_3 account-wide" align="center">
                        <p style="padding: 20px;">
                            <!-- FORMS -->
                        </p>
						<?php if ($response['result'] == false):?>
							<?=Client::alert('error',$response['message'])?>
						<?php elseif($response['result'] == true): ?>
							<?=Client::alert('success',$response['message'])?>
                            <center>
                                <span id="countDown" style="font-weight: bold;font-size: 45px;">600</span>
                                <br>
								<?=$lng[169]?>
                            </center>
						<?php endif;?>
                        <br />
                        <br />
                        <br />
                        <!-- FORMS.End -->
                    </div>
                </div>
                <!-- register.End -->
            </div>
        </div>
        <div class="windows windows-wbBottom"></div>
    </div>
</div>
<script type="text/javascript">
    var minute = 601;
    function countDown()
    {
        if(minute !== 0)
        {
            minute = minute - 1;
            document.getElementById("countDown").innerHTML = minute;
            setTimeout(countDown, 1000);
        }
    }
    window.onload=countDown;
</script>