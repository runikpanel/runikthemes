<?php
$name = $this->all["name"];
?>
<div style="float: left; width: 665px; margin-left:20px;">
    <div style="float: left; margin-top: 10px;">
        <div class="windows windows-wbTop"></div>
        <div class="windows windows-wbCenter">
			<?php Cache::open($name."_player");?>
			<?php if (Cache::check($name."_player")):?>
				<?php
				$info = $this->all["info"];
				$playerInfo = $info->data[0];
				?>
            <div class="content" style="text-align: center; padding-top: 30px; padding-bottom: 30px;">
                <div class="userback" style="text-align: left; display: inline-block;">
                    <ul class="kutu0" style="float: left;
    margin-left: 42px;
    margin-top: 96px;
    color: #584d45;
    font-size: 9pt;
    font-weight: bold;">
                        <li>
                            <img src="<?=URL.'data/chrs/big/'.$playerInfo->job.'/'.Functions::playerPortrait($playerInfo->level).'.png'?>" class="player-img" style="width: 83px;"><br>
                        </li>
                    </ul>
                    <ul class="kutu1" style="margin-top: 60px;width: 237px;">
                        <li>
                            <span><?=$lng[67]?>:</span>
                            <p>
								<?=$playerInfo->name?>
                            </p>
                        </li>
                        <li id="rank">
                            <span><?=$lng[36]?>:</span>
                            <p>
								<?=Functions::jobName($playerInfo->job)?>
                            </p>
                        </li>
                        <li>
                            <span><?=$lng[37]?>:</span>
                            <p>
								<?=Functions::flagName($playerInfo->empire)[1]?>
                            </p>
                        </li>
                        <li>
                            <span><?=$lng[38]?>:</span>
                            <p>
								<?= ($playerInfo->lonca == null) ? 'Yok' : $playerInfo->lonca?>
                            </p>
                        </li>
                        <li>
                            <span><?=$lng[39]?>:</span>
                            <p>
								<?=Functions::prettyDateTime1($playerInfo->last_play)?>
                            </p>
                        </li>
                    </ul>
                    <ul class="kutu2" style="width: 200px;">
                        <li>
                            <span><?=$lng[40]?>:</span>
                            <p>
								<?=$playerInfo->playtime?> <?=$lng[42]?>
                            </p>
                        </li>
                        <li>
                            <span><?=$lng[41]?>:</span>
                            <p>
                                <img src="<?=URL.'data/chrs/small/'.Functions::playerOnlineStatus($playerInfo->last_play).'.png'?>" style="width: 12px;" alt="">
                            </p>
                        </li>
                        <li>
                            <span><?=$lng[68]?>:</span>
                            <p>
								<?=$playerInfo->level?>
                            </p>
                        </li>
                        <li>
                            <span>Exp:</span>
                            <p>
								<?=$playerInfo->exp?>
                            </p>
                        </li>
                        <li>
                            <span><?=$lng[109]?>:</span>
                            <p>
								<?=Functions::map($playerInfo->map_index)?>
                            </p>
                        </li>
                    </ul>
                    <div class="clear">
                    </div>
                </div>
            </div>
			<?php endif;?>
			<?php Cache::close($name."_player");?>
        </div>
        <div class="windows windows-wbBottom"></div>
    </div>
</div>

