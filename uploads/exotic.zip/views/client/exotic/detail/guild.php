<?php
$guildInfo = $this->all["info"];
$name = $this->all["name"];
$guildMembers = $this->all["members"];
?>
<div style="float: left; width: 665px; margin-left:20px;">
    <div style="float: left; margin-top: 10px;">
        <div class="windows windows-wbTop"></div>
        <div class="windows windows-wbCenter">
			<?php Cache::open($name."_guild");?>
			<?php if (Cache::check($name."_guild")):?>
            <div class="content" style="text-align: center; padding-top: 30px; padding-bottom: 30px;">
                <div class="userback" style="text-align: left; display: inline-block;">
                    <ul class="kutu0" style="float: left;
    margin-left: 42px;
    margin-top: 96px;
    color: #584d45;
    font-size: 9pt;
    font-weight: bold;">
                        <li>
							<img src="<?=URL.'data/chrs/big/'.$guildInfo->job.'/'.Functions::playerPortrait($guildInfo->seviye).'.png'?>" alt="<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?>" style="width: 83px;"><br>
                        </li>
                    </ul>
                    <ul class="kutu1" style="margin-top: 60px;width: 237px;">
                        <li>
                            <span><?=$lng[46]?>:</span>
                            <p>
								<?=$guildInfo->name?>
                            </p>
                        </li>
                        <li>
                            <span><?=$lng[44]?>:</span>
                            <p>
								<?=$guildInfo->baskan?>
                            </p>
                        </li>
                        <li id="rank">
                            <span><?=$lng[47]?>:</span>
                            <p>
								<?=$guildInfo->ladder_point?>
                            </p>
                        </li>
                        <li>
                            <span>EXP:</span>
                            <p>
								<?=$guildInfo->exp?>
                            </p>
                        </li>
                        <li>
                            <span><?=$lng[48]?>:</span>
                            <p>
                                <img src="<?=URL.'data/flags/'.$guildInfo->empire.'.png';?>" style="width:30px;" alt="<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?>">
                            </p>
                        </li>
                    </ul>
                    <ul class="kutu2" style="width: 200px;">
                        <li>
                            <span><?=$lng[19]?>:</span>
                            <p>
								<?=$guildInfo->win?>
                            </p>
                        </li>
                        <li>
                            <span><?=$lng[50]?>:</span>
                            <p>
								<?=$guildInfo->draw?>
                            </p>
                        </li>
                        <li>
                            <span><?=$lng[51]?>:</span>
                            <p>
								<?=$guildInfo->loss?>
                            </p>
                        </li>
                    </ul>
                    <div class="clear">
                    </div>
                </div>
            </div>
			<?php endif;?>
			<?php Cache::close($name."_guild");?>
        </div>
        <div class="windows windows-wbBottom"></div>
    </div>
</div>