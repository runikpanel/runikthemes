<div style="float: left; width: 665px; margin-left:20px;">
    <div style="float: left; margin-top: 10px;">
        <div class="windows windows-wbTop"></div>
        <div class="windows windows-wbCenter">
            <div class="content" style="text-align: center; padding-top: 30px; padding-bottom: 30px;">
                <span class="title"><?=$lng[25]?></span>
                <div class="store-activity">
                    <div class="container_3 account-wide" align="center">
                        <p style="padding: 20px;">
                            <!-- FORMS -->
                        </p>
						<?php if (isset($aid)):?>
							<?= Client::alert('error',$lng[74]);?>
						<?php else:?>
                            <form id="forgetPasswordForm" action="<?=URI::get_path('recuperare/control')?>" method="POST" autocomplete="off">
                                <div class="seperator"></div>
                                <div class="row">
                                    <label for="register-username"><?=$lng[22]?>:</label>
                                    <input type="text" id="login" name="login" placeholder="<?=$lng[22]?>">
                                </div>
                                <div class="row">
                                    <label for="register-password"><?=$lng[78]?>:</label>
                                    <input type="text" id="email" name="email" placeholder="Email">
                                </div>
                                <div class="seperator"></div>
                                <div class="row">
									<?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                                </div>
                                <div class="row" style="margin-top: 30px;">
                                    <div class="wbuttons wbuttons-buttonBorder">
                                        <input type="submit" value="<?=$lng[79]?>" class="wbuttons wbuttons-bt" AutoCompleteType="None" />
                                    </div>
                                </div>
                            </form>
						<?php endif;?>
                        <br />
                        <br />
                        <br />
                        <!-- FORMS.End -->
                    </div>
                </div>
                <!-- register.End -->
            </div>
        </div>
        <div class="windows windows-wbBottom"></div>
    </div>
</div>
<script>
    $("#forgetPasswordForm").on("submit", function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                grecaptcha.reset();
                if (response.result)
                    successNotify(response.message);
                else
                    errorNotify(response.message);
            }
        });
    });
</script>