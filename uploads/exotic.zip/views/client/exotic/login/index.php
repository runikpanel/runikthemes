<div style="float: left; width: 665px; margin-left:20px;">
    <div style="float: left; margin-top: 10px;">
        <div class="windows windows-wbTop"></div>
        <div class="windows windows-wbCenter">
            <div class="content" style="padding-left:20px; padding-right:20px;">
                <span class="title"><?=$lng[21]?></span>
                <div class="store-activity">
                    <div class="container_3 account-wide" align="center">
                        <p style="padding: 20px;">
                            <!-- FORMS -->
                        </p>
                        <form id="loginForm" action="<?=URI::get_path('login/control')?>" method="POST" autocomplete="">
                            <div class="seperator"></div>
                            <div class="row">
                                <label for="register-username"><?=$lng[22]?>:</label>
                                <input type="text" class="form-control grunge" name="login" id="login" required maxlength="16" onkeypress="return textonly(event,'#login')"/>
                            </div>
                            <div class="row">
                                <label for="register-password"><?=$lng[23]?>:</label>
                                <input type="password" class="form-control grunge" name="password" id="pass"/>
                            </div>
							<?php if (\StaticDatabase\StaticDatabase::settings('pin_status') === "1"): ?>
                                <div class="row">
                                    <label for="register-password">PIN:</label>
                                    <input type="password" class="form-control grunge" name="pin" id="pin" maxlength="<?=\StaticDatabase\StaticDatabase::settings('pin_count')?>"/>
                                </div>
							<?php endif;?>
                            <div class="seperator"></div>
                            <div class="row">
								<?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                            </div>
                            <div class="row" style="margin-top: 30px;">
                                <div class="wbuttons wbuttons-buttonBorder">
                                    <input type="submit" value="<?=$lng[24]?>" class="wbuttons wbuttons-bt" AutoCompleteType="None" />
                                </div>
                            </div>
                        </form>
                        <br />
                        <br />
                        <br />
                        <!-- FORMS.End -->
                    </div>
                </div>
            </div>
        </div>
        <div class="windows windows-wbBottom"></div>
    </div>
</div>
<script>
    $("#loginForm").on('submit', function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                if (response.result)
                    window.location.href = response.redirect;
                else
                {
                    errorNotify(response.message);
                    grecaptcha.reset();
                }
            }
        });
    });
</script>