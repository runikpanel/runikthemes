<style>
    .privacy-list{
        list-style: circle;
        padding:20px;
        line-height: 25px;
    }
</style>
<div style="float: left; width: 665px; margin-left:20px;">
    <div style="float: left; margin-top: 10px;">
        <div class="windows windows-wbTop"></div>
        <div class="windows windows-wbCenter">
            <div class="content" style="text-align: center; padding-top: 30px; padding-bottom: 30px;">
                <span class="title">Üyelik ve Hizmet Sözleşmesi Beyanı</span>
                <!-- register -->
                <div class="store-activity">
                    <div class="container_3" style="text-align: left;color: #9e844f;">
                        <p style="padding: 20px;">
                        </p>
                        <ul class="privacy-list">
                            <li>Her oyuncu hesap bilgilerini gizli tutmakla yükümlüdür.</li>
                            <li>Bir hesabı sadece hesabın kayıtlı olduğu mail adresinin sahibi kullanabilir (hesap paylaşılamaz, satılamaz, devir edilemez ve ortak kullanılamaz) <?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> takımı kaybedilen veya çalınan eşyaların iadesini yapmayacaktır.</li>
                            <li>Hesap bilgilerinin bir başkası tarafından kullanılması ve bilinmesi tamamıyle sizin sorumluluğunuzdadır. (hesap satmaya teşebbüs etmek, ortak kullanmak, Skype Facebook benzeri yerlerden ve kişilerden dosya almak bunların verdiği linklere tıklamak, şahısların vermiş olduğu sahte sitelere girmek ve bilgilerinizi oradaki formlara girmek, hesap satın almak veya teşebbüs etmek, aldığınız hesabı kullanmak.) Bu durum, oyun sözleşmesinin 1. maddesi hesap bilgilerini gizli tutmamak, sahip çıkmamak ve aşağıda belirtilen ortak hesap kullanımı yada hesap alım satım takası suçlarının vuku bulduğu anlamına gelir. Buna istinaden ticket ile başvuru yaptığınızda çalındığını idda ettiğiniz hesap ve karşı tarafın bütün hesapları süresiz kapatılır. Sizede hesap iade edilmez. (Uyarılarımızı dikkate almayıp düştüğünüz durumdur ve bu sizinde kesinlikle kural ihlali yaptığınız anlamına gelir.)</li>
                            <li>Eğer bir açık bulup bunu kendinize avantaj sağlamak için kullanırsanız oyun hesabınız süresiz olarak kapatılır.</li>
                            <li>Bulunan tüm oyun ve programlama açıkları derhal Destek Sistemi kullanılarak oyun takımına iletilmelidir.</li>
                            <li>Servislerin herhangi birinde (Facebook,Youtube,Forum, IRC, vb) gösterilen uygunsuz davranışların oyun içerisinde verilecek cezalarla sonuçlanabileceğini hesaba katmanız faydalı olacaktır.</li>
                            <li><?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> takımı olarak 'biz', herhangi bir duyuru veya bildirim yapmadan oyun kurallarında herhangi bir zamanda değişiklik yapma/revize etme hakkını saklı tutarız.</li>
                            <li>Genel Kullanım Şartları kuralların üzerindedir ve kurallarla bütün halde uygulanır.</li>
                            <li>Hiç bir oyuncu oyuna ait hiç bir ortamda diğer oyuncuları gerçek hayata yönelik olarak tehdit edemez ve gerçek hayata yönelik eylemlere zorlayamaz.</li>
                            <li>Oyuna yönelik tehditler bu madde kapsamı dışındadır. Herhangi bir oyuncuyu, takım üyesini, <?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> görevlisini, yada herhangi bir şekilde oyun servisleri ile ilgili birini bulup ona zarar verileceğine yönelik imalar ve söylemler kesinlikle yasaktır.</li>
                            <li><?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> sunucularının resmi dili Türkçedir. Oyun Sunucuları, Forum, resmi IRC kanalları bu kurala dahildir ancak bu kural yalnızca bu alanlarla sınırlı değildir.</li>
                            <li>Sohbette kaba/argo dil kullanımı ve küfür yasaktır. Spam (Sürekli olarak aynı mesajın tekrarlanması), www.<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?>.com oyun ve forum linkleri dışındaki linklerin paylaşılması, hile reklamı, hile talebi, yang satış reklamı vs. yasaktır.</li>
                            <li>Oyun takımının kararları için itiraz ancak Destek Sistemi üzerinden yapılabilir.</li>
                            <li>Destek sistemi üzerinden bir konu ile ilgili tek bir ticket açarak bildirim yapmalısınız.</li>
                            <li>Aynı ticket üzerinden cevap gelmeden tekrar tekrar yazmanız cevap alma sürenizi geciktirmekten başka bir fayda sağlamayacaktır.</li>
                            <li>Oyunun kullanıcı hesabı ve materyallerini gerçek para ile satmaya kalkışmak, satmak ve satın almak gibi eylemler kesinlikle yasaktır. Hiç bir kullanıcının böyle bir hakkı yoktur.</li>
                            <li>Detaylı incelemelere sonucu bu faaliyette bulunan kullanıcıların hesapları süresiz olarak kapatılır!</li>
                            <li>Eğer bir oyuncunun kurallara aykırı hareket ettiğini düşünüyorsanız bunu video kaydı alarak Destek Sistemi üzerinden en geç 2 gün içinde yönetime iletiniz.</li>
                            <li>Aksi halde şikayetiniz işleme konulmayacaktır.Bu yüzden oyundaki sol üst köşedeki tarih göstergesini kapatmayınız! Oyundaki sağ taraftaki server ismi kesinlikle gözükmelidr.Aksi halde şikayetiniz bu yüzdende işleme konulmayacaktır. <?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> takımı ilgili şikayetinizi inceleyerek, kural ihlali olup olmadığına karar verecek ve gerekiyorsa ceza sisteminde belirtilen yaptırımı uygulayacaktır.</li>
                            <li>Eğer bir oyun yöneticisinin kurallara aykırı hareket ettiğini düşünüyorsanız bunu ilgili delilleri ile birlikte ticket yoluyla bir üst yönetiye iletebilirsiniz.</li>
                            <li>Nesnelerin kontör & TL ile ticareti yasaktır.Bu tarz satış yapan ve alan kullanıcılar tespit edildiğinde karakteri süresiz olarak kapatılacaktır.</li>
                            <li>Bu tarz satış yapan kişiden nesne alanda kullanıcıların kontör & TL yollayıp nesnesini vermez ise veya tam tersi nesne verip kontör & TL yollamaz ise <?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> yönetimine hiçbir hak talep edemez.(Bu sebepten dolayı hesabı kısıtlanan oyuncu ve/veya oyuncular – lonca veya topluluklar yasal olarak hiçbir hak talep edemezler ve suç duyurusunda bulunamazlar.)</li>
                            <li><?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> yöneticileri kullanıcı hesaplarını sebepsiz olarak açabilir ya da kapatabilir.</li>
                            <li>Bu insiyatif yöneticiler de bulunmaktadır.</li>
                            <li>Yasal talep gelmesi durumunda, <?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> oyunu, sitesi, bağlı bulunduğu şirket veya bağlı ortaklarına karşı hukuki uygunluk durumlarında, oyunu ve firmanın haklarını korumak ve müdafaa gerektiren durumlarda, olağandışı veya acil durumlarda, firmanın, oyunun ve halkın güvenliğini korumaya yönelik işlemlerde kişisel bilgiler ifşa edilebilir.</li>
                            <li>Kayıt olan her kullanıcı oyunun kurallarına uyacağına ve uymadığı taktir de hesabının kapatılacağını onaylar. Oyun kurallarına buradan erişilebilir.</li>
                            <li>Kayıt olan her kullanıcı, yukarıdaki maddeleri okuduğunu, uygulayacağını ve kullanıcı sözleşmesini kabul ettiğini taahhüt eder!</li>
                            <li><?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> bu kuralları istediği anda haber vermeden değiştirme hakkını saklı tutar.</li>
                            <li>Bu üyelik ve hizmet sözleşmesi sayfası en son 04.01.2017 tarihinde güncellenmiştir.</li>
                            <li>Bu gizlilik politikasıyla ilgili herhangi bir sorunuz varsa, aşağıdaki bilgileri kullanarak bizimle iletişime geçebilirsiniz. info@<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?>.com</li>

                        </ul>
                        <!-- FORMS.End -->
                    </div>
                </div>
                <!-- register.End -->
            </div>
        </div>
        <div class="windows windows-wbBottom"></div>
    </div>
</div>