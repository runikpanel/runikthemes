<?php
$patchInfo = $this->all["patch"];
?>
<?php Cache::open($patchInfo->id."_patch");?>
<?php if (Cache::check($patchInfo->id."_patch")):?>
    <div style="float: left; width: 665px; margin-left:20px;">
        <div style="float: left; margin-top: 10px;">
            <div class="windows windows-wbTop"></div>
            <div class="windows windows-wbCenter">
                <div class="content"
                     style="text-align:left; font-size:10pt; color:#776255; display:inline-block; padding-top:25px; padding-bottom:25px; font-weight:bold;">
                    <span class="title"><?=$patchInfo->title?></span><br><br><br>
					<?=$patchInfo->content?>
                    <div class="seperator" style="width: 571px;"></div>
					<?=$lng[64]?>  : <?=Functions::prettyDateTime1($patchInfo->tarih);?>
                </div>
            </div>
            <div class="windows windows-wbBottom"></div>
        </div>
    </div>
<?php endif;?>
<?php Cache::close($patchInfo->id."_patch");?>