<?php
$packList = $this->all;
?>
<div style="float: left; width: 665px; margin-left:20px;">
    <div style="float: left; margin-top: 10px;">
        <div class="windows windows-wbTop"></div>
        <div class="windows windows-wbCenter">
            <div class="content" style="padding-left:20px; padding-right:20px;">
                <span class="title">İndirme Linkleri</span>
                <table id='large' cellspacing='0' class='tablesorter'>
                    <thead>
                    <tr>
                        <th><?=$lng[52]?></th>
                        <th><?=$lng[53]?></th>
                        <th><?=$lng[54]?></th>
                        <th><?=$lng[55]?></th>
                    </tr></thead>
					<?php foreach ($packList->data as $pack):?>
                        <tr>
                            <td><?=$pack->name;?></td>
                            <td><?=$pack->size;?></td>
                            <td><img src="<?=$pack->image?>" alt="<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?>" width="70px"></td>
                            <td><a href="<?=$pack->url?>" target="_blank"><button  class="loginbt" style="height: 20px;">İndİr</button></a></td>
                        </tr>
					<?php endforeach;?>
                </table>
            </div>
        </div>
        <div class="windows windows-wbBottom"></div>
    </div>
</div>
