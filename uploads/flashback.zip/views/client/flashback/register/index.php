<div class="col-md-9">
    <div class="col-md-12 no-padding">
        <div class="panel panel-buyuk">
            <div class="panel-heading"><?=$lng[10]?></div>
            <div class="panel-body">
				<?php if (\StaticDatabase\StaticDatabase::settings('register_status') == "0"):?>
					<?php echo Client::alert('error','Kayıtlarımız şuanda kapalıdır!');?>
				<?php else:?>
                    <form id="registerForm" action="<?=URI::get_path('register/control')?>" method="POST" class="form-horizontal" autocomplete="off">
                        <div class="form-group">
                            <label for="login" class="col-sm-3 control-label"><?=$lng[22]?> </label>
                            <div class="col-sm-5">
                                <input type="text" class="form-control" name="login" id="login" maxlength="16" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="password" class="col-sm-3 control-label"><?=$lng[23]?></label>
                            <div class="col-sm-5">
                                <input type="password" class="form-control" name="password" id="password" maxlength="30" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="password2" class="col-sm-3 control-label"><?=$lng[94]?></label>
                            <div class="col-sm-5">
                                <input type="password" class="form-control" name="password2" id="password2" maxlength="30" required>
                            </div>
                        </div>
						<?php if (\StaticDatabase\StaticDatabase::settings('pin_status') === "1"): ?>
                            <div class="form-group">
                                <label for="pin" class="col-sm-3 control-label">PIN</label>
                                <div class="col-sm-5">
                                    <input type="password" class="form-control" name="pin" id="pin" maxlength="<?=\StaticDatabase\StaticDatabase::settings('pin_count')?>" onkeypress="return numberonly(event,this)" required>
                                </div>
                            </div>
						<?php endif;?>
                        <div class="form-group">
                            <label for="email" class="col-sm-3 control-label"><?=$lng[78]?> </label>
                            <div class="col-sm-5">
                                <input type="email" class="form-control" name="email" id="email" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="name" class="col-sm-3 control-label"><?=$lng[95]?> </label>
                            <div class="col-sm-5">
                                <input type="text" class="form-control" name="name" id="name" onkeypress="return textonly2(event,'#name')" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="ksk" class="col-sm-3 control-label"><?=$lng[96]?> </label>
                            <div class="col-sm-5">
                                <input type="text" class="form-control" name="ksk" id="ksk" onkeypress="return numberonly(event,'#ksk')" maxlength="7" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="phone" class="col-sm-3 control-label"><?=$lng[97]?> </label>
                            <div class="col-sm-5">
                                <input type="text" class="form-control" name="phone" id="phone" onkeypress="return numberonly(event,'#phone')" maxlength="10" placeholder="555-555-55-55" required>
                            </div>
                        </div>
						<?php if (\StaticDatabase\StaticDatabase::settings('findme_status') === "1"): ?>
                            <div class="form-group">
								<?php
								$findMeList = \StaticDatabase\StaticDatabase::init()->prepare("SELECT * FROM findme_list");
								$findMeList->execute();
								?>
                                <label for="findme" class="col-sm-3 control-label">Bizi nerden buldunuz? </label>
                                <div class="col-sm-5">
                                    <select id="findme" name="findme" class="form-control">
                                        <option value="0" selected>Lütfen seçiniz...</option>
										<?php foreach ($findMeList->fetchAll(PDO::FETCH_ASSOC) as $row):?>
                                            <option value="<?=$row["id"]?>"><?=$row["name"]?></option>
										<?php endforeach;?>
                                    </select>
                                </div>
                            </div>
						<?php endif;?>
                        <div class="form-group">
                            <label for="recaptcha" class="col-sm-3 control-label"><?=$lng[24]?></label>
                            <div class="col-sm-5">
								<?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-sm-offset-3 col-sm-5">
                                <span>Kayıt olarak <a href="<?=URI::get_path('privacy/index')?>" target="_blank">üyelik sözleşmesini</a> kabul ederim.</span>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-sm-offset-3 col-sm-5">
                                <button type="submit" class="btn btn-giris" style="margin-top: 10px;"> <?=$lng[10]?></button>
                            </div>
                        </div>
                    </form>
				<?php endif;?>
            </div>
        </div>
    </div>
</div>
<script>
    $('#pass2').change(function ()
    {
        var pass = $('#pass').val();
        var pass2 = $(this).val();
        if(pass != pass2){
            document.getElementById('passOk').style.display = "none";
            document.getElementById('passNo').style.display = "";
            $('#pass2').notify(
                "Şifreler uyuşmuyor !",
                { position:"right" }
            );
        }else{
            document.getElementById('passNo').style.display = "none";
            document.getElementById('passOk').style.display = "";
        }
    });

    $("#registerForm").on("submit", function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                if (response.result)
                {
                    successNotify(response.message);
                    setTimeout(function () {
                        window.location.href = response.redirect;
                    },2000)
                }
                else
                {
                    errorNotify(response.message);
                    grecaptcha.reset();
                }
            }
        });
    });
</script>