<?php
$isBanned = $this->all["is_banned"];
$mailActive = $this->all["mail_active"];
?>
<div class="col-md-9"><div class="col-md-12 no-padding">
        <div class="panel panel-buyuk">
            <div class="panel-heading"><?=$lng[122]?></div>
            <div class="panel-body">
				<?php if ($isBanned):?>
				<?= Client::alert('error',$lng[112]); ?>
				<?php elseif ($mailActive === "1"):?>
                <form id="emailChangeForm" action="<?=URI::get_path('profile/emailchange2')?>" method="POST" class="form-horizontal" autocomplete="off">
                    <div class="form-group">
                        <label for="password" class="col-sm-3 control-label"><?=$lng[23]?></label>
                        <div class="col-sm-6">
                            <input type="password" class="form-control" name="password" id="password" maxlength="30">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="reCaptcha" class="col-sm-3 control-label"><?=$lng[24]?></label>
                        <div class="col-sm-6">
							<?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-offset-3 col-sm-6">
                            <button type="submit" class="btn btn-giris" style="margin-top: 10px;"> <?=$lng[122]?></button>
                        </div>
                    </div>
                </form>
				<?php else:?>
                <form id="emailChangeForm" action="<?=URI::get_path('profile/emailchange')?>" method="POST" class="form-horizontal" autocomplete="off">
                    <div class="form-group">
                        <label for="password" class="col-sm-3 control-label"><?=$lng[23]?></label>
                        <div class="col-sm-6">
                            <input type="password" class="form-control" name="password" id="password" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="newMail" class="col-sm-3 control-label"><?=$lng[133]?></label>
                        <div class="col-sm-6">
                            <input type="email" class="form-control" name="new_mail" id="newMail" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="reMail" class="col-sm-3 control-label"><?=$lng[134]?></label>
                        <div class="col-sm-6">
                            <input type="email" class="form-control" name="re_mail" id="reMail" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="reCaptcha" class="col-sm-3 control-label"><?=$lng[24]?></label>
                        <div class="col-sm-6">
							<?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-offset-3 col-sm-6">
                            <button type="submit" class="btn btn-giris" style="margin-top: 10px;"> <?=$lng[122]?></button>
                        </div>
                    </div>
                </form>
				<?php endif;?>
            </div>
        </div>
    </div>
</div>
<script>
    $("#emailChangeForm").on("submit", function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                grecaptcha.reset();
                if (response.result)
                    successNotify(response.message);
                else
                    errorNotify(response.message);
            }
        });
    });
</script>