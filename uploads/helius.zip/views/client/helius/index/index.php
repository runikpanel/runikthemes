<div class="homepage-content">
    <div class="section-area news-list">
        <div class="row">
            <div class="col-xs-7">
                <div class="tab-area no-padding">
                    <ul class="nav">
                        <li class="active">
                            <a href="#news" data-toggle="tab" aria-expanded="true"><i class="fa fa-newspaper-o"></i> Haberler&Duyurular </a>
                        </li>
                    </ul>

                    <div class="tab-content">
                        <div role="tabpanel" class="tab-pane active" id="news">

							<?php Cache::open('patch');?>
							    <?php if (Cache::check('patch')):?>
							        <?php $newsList = $this->all['patch']; ?>
							        <?php foreach ($newsList->data as $news):?>

                            <div class="media">
                                <div class="media-left">
                                    <div class="news-date-wrapper">
                                        <div class="news-date text-center no-radius col-xs-12">
                                            <?php $explodeDate = explode(" ",Functions::prettyDateTime1($news->tarih));?>
                                            <div class="day col-xs-12 no-padding"><?=$explodeDate[1]?></div>
                                            <div class="month col-xs-12 no-padding"><?=$explodeDate[0]?></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="media-body">
                                    <a href="<?=URI::get_path('patch/view/'.$news->id)?>" class="media-heading font-size-16 margin-bottom-10"><?=$news->title;?></a>
                                    <div class="col-xs-12 no-padding news-desc"><?=$news->content2;?></div>
                                </div>
                            </div>

								<?php endforeach; ?>
							<?php endif;?>
							<?php Cache::close('patch');?>

                        </div>
                    </div>
                </div>
            </div>

			<?php if (\StaticDatabase\StaticDatabase::settings('event_type') != "3"):?>
                <div class="col-xs-5">
                    <h3 class="section-title margin-bottom-15">
                        <i class="fa fa-calendar"></i>
						<?=$lng[15]?>
                    </h3>
                    <div class="padding-10">
						<?php if(\StaticDatabase\StaticDatabase::settings('event_type') == "1"):?>
                            <center><iframe src="<?=URI::get_path('event')?>" class="event-frame" style="min-height: 260px"></iframe></center>
						<?php else:?>
                            <iframe src="<?=URI::get_path('event/dynamic')?>" style="border: none;width: 100%;min-height: 260px;height: 301px;left: -5px;" id="fancybox-frame"></iframe>
						<?php endif;?>
                    </div>
                </div>
            <?php endif;?>

        </div>
    </div>



	<?php if (\StaticDatabase\StaticDatabase::settings('facebook_status')):?>
    <div class="section-area">
        <div class="row">
            <div class="col-xs-12 no-padding-right">
                <h3 class="section-title"><i class="fa fa-facebook-square"></i> Facebook'ta Biz</h3>
                <div id="fb" class="facebook">
                    <img src="<?=URI::public_path()?>static/images/loaders/brighter.gif" alt="" id="fbLoading" style="display:block; margin-left: auto;margin-right: auto; margin-top: 224px;margin-bottom: 224px;">
                    <div id="fbContent" class="fb-page" data-href="<?=\StaticDatabase\StaticDatabase::settings('facebook')?>" data-tabs="timeline" data-width="462" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="false" style="display: none;margin-left: 65px;"></div>
                </div>
                <script>
                    $(document).ready(function () {
                        if ($(window).width() < 540) {
                            document.getElementById('fb').style.display = 'none';
                        }else{
                            setTimeout(function () {
                                document.getElementById('fbLoading').style.display = "none";
                                $('#fbContent').fadeIn();
                            },3500)
                        }

                    });
                </script>
            </div>
        </div>
    </div>
	<?php endif;?>

	<?php if (\StaticDatabase\StaticDatabase::settings('facebook_like_status')):?>
        <div class="fbBoard fbBoard2" id="facebookLike">
            <center>

                <a href="<?=\StaticDatabase\StaticDatabase::settings('facebook')?>" target="_blank">
                    <div class="facebook-like">
                        <img src="<?=URI::public_path('main/images/face.png')?>" alt="">
                        <a href="javascript:void(0)" onclick="document.getElementById('facebookLike').style.display='none';" style="display:block;width:23px;height:23px;margin:0px;padding:0px;border:none;background-color:transparent;position:absolute;top:23px;right:70px;-webkit-border-radius: 12px;border-radius: 12px;"></a>

                        <iframe src="https://www.facebook.com/plugins/like.php?href=<?=\StaticDatabase\StaticDatabase::settings('facebook')?>&amp;send=false&amp;layout=button_count&amp;width=120&amp;show_faces=false&amp;action=like&amp;colorscheme=light&amp;font=segoe+ui&amp;height=30&amp;appId=515295435153698" scrolling="no" frameborder="0" style="position:absolute;bottom:82px;right:104px;border:none; overflow:hidden; width:98px; height:21px;" allowtransparency="true"></iframe>


                    </div>
                </a>
            </center>
        </div>
        <script>
            var isMobile = {
                Android: function() {
                    return navigator.userAgent.match(/Android/i);
                },
                BlackBerry: function() {
                    return navigator.userAgent.match(/BlackBerry/i);
                },
                iOS: function() {
                    return navigator.userAgent.match(/iPhone|iPad|iPod/i);
                },
                Opera: function() {
                    return navigator.userAgent.match(/Opera Mini/i);
                },
                Windows: function() {
                    return navigator.userAgent.match(/IEMobile/i);
                },
                any: function() {
                    return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows());
                }
            };
            if(isMobile.any()) {
                document.getElementById('facebookLike').style.display = 'none';
            }
        </script>
	<?php endif;?>
</div>