<?php
$packList = $this->all;
?>
<style>
    .bg-light {
        width: 95%;
        display: block;
        overflow: auto;
        padding-right: 15px;
        padding-left: 15px;
        background: url(<?=URI::public_path('asset/images/content-bg.jpg')?>);
        filter: brightness(1.72);
    }
    .col-50 {
        float: left;
        width: 50%;
    }
    .bg-light h3{
        font-size: 16px;
        text-align: center;
        color: #A07332;
        margin-bottom: 15px;
    }
    .central{
        text-align: center;
    }
</style>

<div class="homepage-content">
    <div class="section-area">
        <h3 class="section-title" style="margin-bottom:20px"> Oyunu İndir</h3>

        <table class="table table-striped table-hover dataTable no-footer">
            <thead>
            <tr>
                <th><?=$lng[52]?></th>
                <th><?=$lng[53]?></th>
                <th><?=$lng[54]?></th>
                <th><?=$lng[55]?></th>
            </tr>
            </thead>
            <tbody>
			<?php foreach ($packList->data as $pack):?>
                <tr>
                    <td><?=$pack->name;?></td>
                    <td><?=$pack->size;?></td>
                    <td><a href="<?=$pack->url?>" target="_blank"><img src="<?=$pack->image?>" alt="<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?>" width="70px;"></a></td>
                    <td><a href="<?=$pack->url?>" target="_blank" class="btn btn-danger" style="padding: 3px;margin-right: 15px;"><?=$lng[175]?></a></td>
                </tr>
			<?php endforeach;?>
            </tbody>
        </table>
        <br>
        <div class="bg-light">
            <h3><?=$lng[56]?></h3>
            <div class="col-50 central">
                <strong class="wheat"><?=$lng[57]?></strong><br><br>
                <strong><?=$lng[58]?>:</strong> Windows Vista, 7<br>
                <strong>CPU:</strong> Pentium 3 800MHz or higher<br>
                <strong>RAM:</strong> 256MB<br>
                <strong>VGA:</strong> 3D GeForce2 or ATI 9000<br>
                <strong>HDD:</strong> 1,5 GB<br><br>
            </div>
            <div class="col-50 central">
                <strong class="wheat"><?=$lng[59]?></strong><br><br>
                <strong><?=$lng[58]?>:</strong> Windows Vista, 7<br>
                <strong>CPU:</strong> Pentium 4 2.4GHz or higher<br>
                <strong>RAM:</strong> 512MB<br>
                <strong>VGA:</strong> 3D GeForce FX 5600 or ATI9500<br>
                <strong>HDD:</strong> 2 GB<br><br>
            </div>
        </div>
    </div>
</div>

