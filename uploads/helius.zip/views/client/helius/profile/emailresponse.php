<?php $status = $this->all['result']; ?>
<div class="homepage-content">
    <div class="section-area">
        <h3 class="section-title" style="margin-bottom:20px"> <?=$lng[122]?></h3>

		<?php if(!$status): ?>
			<?= Client::alert('error',$lng[81]);?>
		<?php else:?>
			<?= Client::alert('info',$lng[135]);?>
            <form id="emailChangeForm2" action="<?=URI::get_path('profile/emailchange3')?>" method="POST" class="form-horizontal form-fv fv-form fv-form-bootstrap" autocomplete="off" >
                <div class="form-group">
                    <label class="col-xs-2 control-label"><?=$lng[23]?></label>
                    <div class="col-xs-10">
                        <input id="password" type="password" name="password" class="form-control input-grey" placeholder="<?=$lng[23]?>">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-xs-2 control-label"><?=$lng[133]?></label>
                    <div class="col-xs-10">
                        <input id="newMail" type="email" name="new_mail" value="" class="form-control input-grey" placeholder="<?=$lng[133]?>">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-xs-2 control-label"><?=$lng[134]?></label>
                    <div class="col-xs-10">
                        <input id="reMail" type="email" name="re_mail" value="" class="form-control input-grey" placeholder="<?=$lng[134]?>">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-xs-2 control-label">Kontrol</label>
                    <div class="col-xs-10">
						<?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                        <button type="submit" form="emailChangeForm2" class="btn btn-default downbutton"><?=$lng[122]?></button>
                    </div>
                </div>
            </form>
		<?php endif;?>

    </div>
</div>
<script>
    $("#emailChangeForm2").on("submit", function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                grecaptcha.reset();
                if (response.result)
                    successNotify(response.message);
                else
                    errorNotify(response.message);
            }
        });
    });
</script>