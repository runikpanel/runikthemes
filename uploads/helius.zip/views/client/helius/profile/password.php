<?php $isBanned = $this->all["is_banned"];?>
<div class="homepage-content">
    <div class="section-area">
        <h3 class="section-title" style="margin-bottom:20px"> <?=$lng[141]?></h3>

		<?php if ($isBanned):?>
			<?= Client::alert('error', $lng[112]);?>
		<?php else:?>
        <form id="passwordChangeForm" action="<?=URI::get_path('profile/passwordchange')?>" method="post" accept-charset="utf-8" class="form-horizontal form-fv fv-form fv-form-bootstrap" autocomplete="off">
            <div class="form-group">
                <label class="col-xs-2 control-label"><?=$lng[165]?></label>
                <div class="col-xs-10">
                    <input type="password" class="form-control input-grey" name="old_password" id="oldPassword" placeholder="<?=$lng[165]?>">
                </div>
            </div>
            <div class="form-group">
                <label class="col-xs-2 control-label"><?=$lng[166]?></label>
                <div class="col-xs-10">
                    <input type="password" class="form-control input-grey" name="new_password" id="newPassword" placeholder="<?=$lng[166]?>">
                </div>
            </div>
            <div class="form-group">
                <label class="col-xs-2 control-label"><?=$lng[167]?></label>
                <div class="col-xs-10">
                    <input type="password" class="form-control input-grey" name="re_password" id="rePassword" placeholder="<?=$lng[167]?>">
                </div>
            </div>

            <div class="form-group">
                <label class="col-xs-2 control-label">Kontrol</label>
                <div class="col-xs-10">
					<?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <button type="submit" form="passwordChangeForm" class="btn btn-default downbutton"><?=$lng[141]?></button>
                </div>
            </div>
            </form>
		<?php endif;?>

    </div>
</div>
<script>
    $("#passwordChangeForm").on("submit", function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                grecaptcha.reset();
                if (response.result)
                    successNotify(response.message);
                else
                    errorNotify(response.message);
            }
        });
    });
</script>