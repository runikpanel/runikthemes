<div class="homepage-content">
    <div class="section-area">
        <h3 class="section-title" style="margin-bottom:20px"> <?=$lng[153]?></h3>

		<?php if($this->response['result'] == false): ?>
			<?php echo Client::alert('error',$lng[81]);?>
		<?php elseif ($this->response['result'] == true):?>
			<?php echo Client::alert('success',$lng[157]);?>
            <h3 class="header-3" style="font: normal 25px 'Palatino Linotype', 'Times', serif; text-transform: none;"><?=$lng[158]?> : <?=$this->response['data'];?></h3>
		<?php endif;?>

    </div>
</div>