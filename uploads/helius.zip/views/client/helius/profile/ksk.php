<?php
$isBanned = $this->all["is_banned"];
$mailActive = $this->all["mail_active"];
?>
<div class="homepage-content">
    <div class="section-area">
        <h3 class="section-title" style="margin-bottom:20px"> <?=$lng[153]?></h3>

		<?php if ($isBanned):?>
			<?= Client::alert('error',$lng[112]); ?>
		<?php elseif ($mailActive === "0"):?>
			<?= Client::alert('error',$lng[113])?>
            <a href="<?=URI::get_path('profile/aktive')?>" ><button type="submit" class="center-block btn btn-grunge"><?=$lng[114]?></button></a>
		<?php else:?>
            <form id="kskChangeForm" action="<?=URI::get_path('profile/kskchange')?>" method="POST" class="form-horizontal form-fv fv-form fv-form-bootstrap" autocomplete="off" >
                <div class="form-group">
                    <label class="col-xs-2 control-label"><?=$lng[23]?></label>
                    <div class="col-xs-10">
                        <input id="password" type="password" name="password" class="form-control input-grey" placeholder="<?=$lng[23]?>">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-xs-2 control-label">Kontrol</label>
                    <div class="col-xs-10">
						<?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                        <button type="submit" form="kskChangeForm" class="btn btn-default downbutton"><?=$lng[156]?></button>
                    </div>
                </div>
            </form>
		<?php endif;?>

    </div>
</div>

<script>
    $("#kskChangeForm").on("submit", function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                grecaptcha.reset();
                if (response.result)
                    successNotify(response.message);
                else
                    errorNotify(response.message);
            }
        });
    });
</script>