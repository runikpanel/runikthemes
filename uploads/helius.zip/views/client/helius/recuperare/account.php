<div class="homepage-content">
    <div class="section-area">
        <h3 class="section-title" style="margin-bottom:20px"> <?=$lng[73]?></h3>

        <form id="forgetAccountForm" action="<?=URI::get_path('recuperare/control2')?>" method="post" accept-charset="utf-8" class="form-horizontal form-fv fv-form fv-form-bootstrap" autocomplete="off">
            <div class="form-group">
                <label class="col-xs-2 control-label"><?=$lng[78]?></label>
                <div class="col-xs-10">
                    <input type="text" class="form-control input-grey" name="email" id="email" placeholder="<?=$lng[78]?>">
                </div>
            </div>
            <div class="form-group">
                <label class="col-xs-2 control-label">Kontrol</label>
                <div class="col-xs-10">
					<?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <button type="submit" class="btn btn-default downbutton"><?=$lng[79]?></button>
                </div>
            </div>
        </form>

    </div>
</div>
<script>
    $("#forgetAccountForm").on("submit", function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                grecaptcha.reset();
                if (response.result)
                    successNotify(response.message);
                else
                    errorNotify(response.message);
            }
        });
    });
</script>