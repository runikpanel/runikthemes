<div class="homepage-content">
    <div class="section-area">
        <h3 class="section-title" style="margin-bottom:20px"> <?=$lng[21]?></h3>

        <form id="loginForm" class="form-horizontal form-fv fv-form fv-form-bootstrap" action="<?=URI::get_path('login/control')?>" method="POST" autocomplete="off" >
            <div class="form-group">
                <label class="col-xs-2 control-label"><?=$lng[22]?></label>
                <div class="col-xs-10">
                    <input type="text" class="form-control input-grey" name="login" id="login" required maxlength="16"/>
                </div>
            </div>
            <div class="form-group">
                <label class="col-xs-2 control-label"><?=$lng[23]?></label>
                <div class="col-xs-10">
                    <input type="password" class="form-control input-grey" name="password" id="password"/>
                </div>
            </div>
			<?php if (\StaticDatabase\StaticDatabase::settings('pin_status') === "1"): ?>
                <div class="form-group">
                    <label class="col-xs-2 control-label">PIN</label>
                    <div class="col-xs-10">
                        <input type="password" class="form-control input-grey" name="pin" id="pin" maxlength="<?=\StaticDatabase\StaticDatabase::settings('pin_count')?>"/>
                    </div>
                </div>
            <?php endif;?>
            <div class="form-group">
                <label class="col-xs-2 control-label">Kontrol</label>
                <div class="col-xs-10">
					<?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <button type="submit" form="loginForm" class="btn btn-default downbutton"><?=$lng[21]?></button>
                </div>
            </div>
        </form>

    </div>
</div>
<script>
    $("#loginForm").on('submit', function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                if (response.result)
                    window.location.href = response.redirect;
                else
                {
                    errorNotify(response.message);
                    grecaptcha.reset();
                }
            }
        });
    });
</script>