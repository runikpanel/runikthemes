<?php $patchInfo = $this->all["patch"]; ?>
<style>
    .main-text-bg{
        width: 95%;
        overflow: auto;
        padding: 20px;
        background: url(<?=URI::public_path('asset/images/content-bg.jpg')?>);
        filter: brightness(1.72);
    }
</style>
<div class="homepage-content">
    <div class="section-area">
		<?php Cache::open($patchInfo->id."_patch");?>
		<?php if (Cache::check($patchInfo->id."_patch")):?>
        <h3 class="section-title" style="margin-bottom:20px"> <?=$patchInfo->title?></h3>

            <div class="body">
                <div class="main-inner main-inner-news">
                    <div class="main-text-bg">
                        <div style="float: right"><?=Functions::prettyDateTime1($patchInfo->tarih);?></div>
                        <br><br>
                        <div class="main-text">
							<?=$patchInfo->content?>
                        </div>
                    </div>
                </div>
            </div>

		<?php endif;?>
		<?php Cache::close($patchInfo->id."_patch");?>
    </div>
</div>