</div>
<style>
    #rc-imageselect, .g-recaptcha {
        display: inline; //the most important
    }

    #rc-imageselect{
        max-width: 100%;
    }

    .g-recaptcha>div>div{
        width: 50% !important;
        height: 78px;
        transform:scale(0.77); //the code to rescale the captcha obtained in this page
    webkit-transform:scale(0.77);
        text-align: center;
        position: relative;
    }
</style>
<div class="col-xs-3">
    <div class="sidebar">
        <a class="download-button" href="<?=URI::get_path('download')?>"><i class="fa fa-download" aria-hidden="true"></i> KURULUM</a>
		<?php if (isset($_SESSION['aid'])):?>
            <div class="form">

                <div class="bottom">
                    <div class="row">
                        <div class="col-xs-12 margin-bottom-10"><div class="col-xs-12 sidebar-title"><i class="fa fa-user" aria-hidden="true"></i> Hesap Bilgileri</div></div>
                        <div class="col-xs-12"><div class="col-xs-12 account-label">Kullanıcı Adı : <?=Session::get('cLogin')?></div></div>
                        <div class="col-xs-12"><div class="col-xs-12 account-label">Ejderha Parası : <?=$getAin[CASH]?> EP</div></div>
                        <div class="col-xs-12"><div class="col-xs-12 account-label">Ejderha Markası : <?=$getAin[MILEAGE]?> EM</div></div>

                        <div class="col-xs-12 menu-label-cikis">
                            <a href="<?=URI::get_path('profile')?>" class="label label-default col-xs-12">Hesabım</a>
                        </div>
                        <div class="col-xs-12 menu-label-cikis">
                            <a href="<?=URI::get_path('login/logout')?>" class="label label-default col-xs-12">Çıkış Yap</a>
                        </div>
                    </div>
                </div>
            </div>
        <?php else:?>
		    <?php if ($urlLang[0] != 'register' && $urlLang[0] != 'login' && $urlLang[0] != 'recuperare'):?>
                <div class="form">
                    <form id="loginForm" action="<?=URI::get_path('login/control')?>" method="post" accept-charset="utf-8" autocomplete="off">
                        <div class="row">
                            <div class="col-xs-8 margin-top-5">
                                <input type="text" name="login" placeholder="<?=$lng[22]?>">
                                <input type="password" name="password" placeholder="<?=$lng[23]?>">
				                <?php if (\StaticDatabase\StaticDatabase::settings('pin_status') === "1"): ?>
                                    <input type="password" name="pin" placeholder="PIN" maxlength="<?=\StaticDatabase\StaticDatabase::settings('pin_count')?>">
								<?php endif;?>
                            </div>
                            <div class="col-xs-4 margin-top-5" style="padding-left:0">
                                <input type="submit" value="Giriş">
                            </div>
                            <div class="form-group  col-xs-12 text-center no-padding-left no-margin-bottom">
                                <div class="g-recaptcha rc-anchor-blue" data-theme="dark" style="transform:scale(0.81);-webkit-transform:scale(0.81);transform-origin:0 0;-webkit-transform-origin:0 0;" data-sitekey="<?=\StaticDatabase\StaticDatabase::settings('sitekey')?>"></div>
                            </div>


                            <div class="col-xs-12 margin-top-5">
                                <div class="pasreg-title">
                                    <a href="<?=URI::get_path('recuperare')?>"><i class="fa fa-question-circle-o" aria-hidden="true"></i> <?=$lng[25]?></a>
                                </div>
                            </div>
                            <div class="col-xs-12 margin-top-5">
                                <div class="pasreg-title">
                                    <a href="<?=URI::get_path('recuperare/account')?>"><i class="fa fa-question-circle-o" aria-hidden="true"></i> <?=$lng[26]?></a>
                                </div>
                            </div>
				            <?php if(\StaticDatabase\StaticDatabase::settings('pin_status') === "1"):?>
                                <div class="col-xs-12 margin-top-5">
                                    <div class="pasreg-title">
                                        <a href="<?=URI::get_path('recuperare/pin')?>"><i class="fa fa-question-circle-o" aria-hidden="true"></i> PIN Unuttum</a>
                                    </div>
                                </div>
				            <?php endif;?>


                        </div>
                    </form>
                    <script>
                        $("#loginForm").on('submit', function (event) {
                            event.preventDefault();

                            var url = $(this).attr("action");
                            var data = $(this).serialize();

                            $.ajax({
                                url : url,
                                type : 'POST',
                                data : data,
                                dataType : 'json',
                                success : function (response) {
                                    if (response.result)
                                        window.location.href = response.redirect;
                                    else
                                    {
                                        errorNotify(response.message);
                                        grecaptcha.reset();
                                    }
                                }
                            });
                        });
                    </script>
                </div>
			<?php endif;?>
        <?php endif;?>
        <div class="action-box">
            <a href="<?=URL.SHOP?>" class="itemshop itemshop-btn iframe">
                <i class="fa fa-shopping-cart"></i> <?=$lng[12]?>
            </a>
            <a href="<?=URL.MUTUAL?>" class="color itemshop itemshop-btn iframe">
                <i class="fa fa-support"></i><?=$lng[13]?>
            </a>
            <a href="<?=\StaticDatabase\StaticDatabase::settings('tanitim')?>" target="_blank" class="color">
                <i class="fa fa-bookmark-o"></i> <?=$lng[184]?>
            </a>
            <a href="<?=\StaticDatabase\StaticDatabase::settings('youtube')?>" target="_blank">
                <i class="fa fa-youtube"></i> Youtube
            </a>
            <div class="clear"></div>
        </div>

        <div class="list-table">
            <h3 class="title"><i class="fa fa-user" aria-hidden="true"></i> <?=$lng[176]?></h3>
            <table>
				<?php Cache::open('player_ranking');?>
				<?php if (Cache::check('player_ranking')):?>
				    <?php if (count($result['topplayer']) != 0):?>
				        <?php foreach ($result['topplayer'] as $key=>$row):?>
                <tr>
                    <td style="color:#ffe09d;"><?=$key+1?></td>
                    <td><a href="<?=URI::get_path('detail/player/'.$row['name'])?>" style="color:#ffffff;"><?=$row['name']?></a></td>
                    <td>Lv. <?=$row['level']?></td>
                </tr>
						<?php endforeach;?>
					<?php endif;?>
				<?php endif;?>
				<?php Cache::close('player_ranking')?>
            </table>
        </div>

        <div class="list-table">
            <h3 class="title"><i class="fa fa-users" aria-hidden="true"></i> <?=$lng[177]?></h3>
            <table>
				<?php Cache::open('guild_ranking');?>
				<?php if (Cache::check('guild_ranking')):?>
				    <?php if (count($result['topguild']) != 0):?>
				        <?php foreach ($result['topguild'] as $key2=>$row2):?>
                <tr>
                    <td style="color:#ffe09d;"><?=$key2+1?></td>
                    <td><a href="<?=URI::get_path('detail/guild/'.$row2['name'])?>" style="color: #ffffff"><?=$row2['name']?></a></td>
                    <td><?=$row2["ladder_point"];?></td>
                </tr>
						<?php endforeach;?>
					<?php endif;?>
				<?php endif;?>
				<?php Cache::close('guild_ranking')?>
            </table>
        </div>

		<?php if (\StaticDatabase\StaticDatabase::settings('active_pazar_status') != 0 || \StaticDatabase\StaticDatabase::settings('today_login_status') != 0 || \StaticDatabase\StaticDatabase::settings('total_account_status') != 0 || \StaticDatabase\StaticDatabase::settings('total_player_status') != 0):?>
		    <?php Cache::open('server_statistics');?>
		    <?php if (Cache::check('server_statistics')):?>
        <div class="list-table">
            <h3 class="title"><i class="fa fa-server" aria-hidden="true"></i> <?=$lng[2]?></h3>
            <table>
				<?php if (\StaticDatabase\StaticDatabase::settings('total_online_status')):?>
                    <tr>
                        <td class="border-right"><?=$lng[3]?></td>
                        <td><?=$getCount['totalOnline']['count'] + \StaticDatabase\StaticDatabase::settings('online')?></td>
                    </tr>
				<?php endif;?>

				<?php if (\StaticDatabase\StaticDatabase::settings('active_pazar_status')):?>
                    <tr>
                        <td class="border-right"><?=$lng[7]?></td>
                        <td><?=$getCount['activePazar']['count'] + \StaticDatabase\StaticDatabase::settings('activepazar')?></td>
                    </tr>
				<?php endif;?>

				<?php if (\StaticDatabase\StaticDatabase::settings('today_login_status')):?>
                    <tr>
                        <td class="border-right"><?=$lng[4]?></td>
                        <td><?=$getCount['todayLogin']['count'] + \StaticDatabase\StaticDatabase::settings('todaylogin')?></td>
                    </tr>
				<?php endif;?>

				<?php if (\StaticDatabase\StaticDatabase::settings('total_account_status')):?>
                    <tr>
                        <td class="border-right"><?=$lng[5]?></td>
                        <td><?=$getCount['totalAccount']['count'] + \StaticDatabase\StaticDatabase::settings('totalaccount')?></td>
                    </tr>
				<?php endif;?>

				<?php if (\StaticDatabase\StaticDatabase::settings('total_player_status')):?>
                    <tr>
                        <td class="border-right"><?=$lng[6]?></td>
                        <td><?=$getCount['totalPlayer']['count'] + \StaticDatabase\StaticDatabase::settings('totalplayer')?></td>
                    </tr>
				<?php endif;?>
            </table>
        </div>
			<?php endif;?>
			<?php Cache::close('server_statistics');?>
		<?php endif;?>

    </div>
</div>
<div class="clearfix">

</div>
</div>
</div>
<!-- End Content -->