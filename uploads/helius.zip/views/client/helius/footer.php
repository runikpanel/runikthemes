<!-- Begin Footer -->
<div class="footer">
    <div class="container">
        <div class="footer-nav">
            <ul>
                <li><a href="<?=URI::get_path('index')?>">ANASAYFA</a></li>
                <li><a href="<?=URI::get_path('register')?>">KAYIT OL</a></li>
                <li><a href="<?=URI::get_path('download')?>">İNDİR</a></li>
                <li><a href="<?=URI::get_path('ranked/player')?>">SIRALAMA</a></li>
                <li><a href="<?=URL.SHOP?>" class="itemshop itemshop-btn iframe">NESNE MARKET</a></li>
                <li><a href="<?=URL.MUTUAL?>" class="itemshop itemshop-btn iframe">DESTEK</a></li>
                <li><a href="<?=\StaticDatabase\StaticDatabase::settings('forum')?>">FORUM</a></li>
            </ul>
        </div>

        <div class="copyright">
            <p>Copyright &copy; by <a href="<?=\StaticDatabase\StaticDatabase::settings('footer_link')?>"><?=\StaticDatabase\StaticDatabase::settings('footer_name')?></a> - <?=date("Y")?></p>
            <p>Tüm hakları saklıdır ve <a href="<?=URI::get_path('index')?>"><?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?></a> mülkiyetindedir.</p>
            <p><a href="https://payreks.com" target="_blank" title="Metin2 PVP Ödeme Sistemleri">Payreks</a> - +90 850 840 99 39 - <a href="mailto:bilgi@payreks.com">bilgi@payreks.com</a></p>
            <p><a href="https://payreks.com" target="_blank"><img src="https://development.payreks.com/assets/images/logo-white-mini.png" style="display: block;width: 100px;margin-right: auto;margin-left: auto;" alt="Metin2 PVP Ödeme Sistemleri"></a></p>
        </div>
    </div>
</div>
<!-- End Footer -->

<?php if (\StaticDatabase\StaticDatabase::settings('discord_status') == "1"):?>
    <style>

        .discord-widget {
            position: fixed;
            bottom: 0;
            z-index:10;
        }


        .discord-widget.active
        {
            right: 20px;
        }
    </style>
    <a class="discord-widget animated bounceInLeft" href="<?php echo \StaticDatabase\StaticDatabase::settings('discord_link')?>" title="Join us on Discord">
        <img src="https://discordapp.com/api/guilds/<?php echo \StaticDatabase\StaticDatabase::settings('discord_id')?>/embed.png?style=<?php echo \StaticDatabase\StaticDatabase::settings('discord_theme')?>">
    </a>
<?php endif;?>
<?php if (\StaticDatabase\StaticDatabase::settings('tawkto_status') == "1"):?>
    <!--Start of Tawk.to Script-->
    <script type="text/javascript">
        var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
        (function(){
            var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
            s1.async=true;
            s1.src='https://embed.tawk.to/'+"<?php echo \StaticDatabase\StaticDatabase::settings('tawkto_id')?>"+'/default';
            s1.charset='UTF-8';
            s1.setAttribute('crossorigin','*');
            s0.parentNode.insertBefore(s1,s0);
        })();
    </script>
    <!--End of Tawk.to Script-->
<?php endif;?>
<?php if (\StaticDatabase\StaticDatabase::settings('gtag_status') == "1"):?>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=<?= \StaticDatabase\StaticDatabase::settings('gtag_id')?>"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', '<?= \StaticDatabase\StaticDatabase::settings('gtag_id')?>');
    </script>
    <!-- Global site tag (gtag.js) - Google Analytics -->
<?php endif;?>

</body>
</html>