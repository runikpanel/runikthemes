<style>
    .select-box{
        background-color: #F7F7F7;
        box-shadow: inset 0 1px 1px rgb(0 0 0 / 48%);
        color: #7d8a9f;
        padding: 8px 10px;
        font-size: 12px;
        position: relative;
        border-radius: 3px;
        transition: all 0.5s ease;
        width: 100%;
    }
</style>
<div class="homepage-content">
    <div class="section-area">
        <h3 class="section-title" style="margin-bottom:20px"> <?=$lng[21]?></h3>
		<?php if (\StaticDatabase\StaticDatabase::settings('register_status') == "0"):?>
			<?php echo Client::alert('error','Kayıtlarımız şuanda kapalıdır!');?>
		<?php else:?>
            <form id="registerForm" class="form-horizontal form-fv fv-form fv-form-bootstrap" action="<?=URI::get_path('register/control')?>" method="POST" autocomplete="off" >
                <div class="form-group">
                    <label class="col-xs-2 control-label"><?=$lng[22]?></label>
                    <div class="col-xs-10">
                        <input type="text" class="form-control input-grey" name="login" id="login" required maxlength="16" onkeypress="return textonly(event,'#login')"/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-xs-2 control-label"><?=$lng[23]?></label>
                    <div class="col-xs-10">
                        <input type="password" class="form-control input-grey" name="password" id="password" required maxlength="30"/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-xs-2 control-label"><?=$lng[94]?></label>
                    <div class="col-xs-10">
                        <input type="password" class="form-control input-grey" name="password2" id="password2" required maxlength="30"/>
                    </div>
                </div>
				<?php if (\StaticDatabase\StaticDatabase::settings('pin_status') === "1"): ?>
                    <div class="form-group">
                        <label class="col-xs-2 control-label">PIN</label>
                        <div class="col-xs-10">
                            <input type="password" class="form-control input-grey" name="pin" id="pin" maxlength="<?=\StaticDatabase\StaticDatabase::settings('pin_count')?>" onkeypress="return numberonly(event,this)" required/>
                        </div>
                    </div>
				<?php endif;?>
                <div class="form-group">
                    <label class="col-xs-2 control-label"><?=$lng[78]?></label>
                    <div class="col-xs-10">
                        <input type="email" class="form-control input-grey" name="email" id="email" required />
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-xs-2 control-label"><?=$lng[95]?></label>
                    <div class="col-xs-10">
                        <input id="name" type="text" name="name" class="form-control input-grey" onkeypress="return textonly2(event,'#name')" maxlength="60" required />
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-xs-2 control-label"><?=$lng[96]?></label>
                    <div class="col-xs-10">
                        <input id="ksk" type="text" name="ksk" class="form-control input-grey" onkeypress="return numberonly(event,'#ksk')" maxlength="7" required />
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-xs-2 control-label"><?=$lng[97]?></label>
                    <div class="col-xs-10">
                        <input type="text" id="phone" name="phone" class="form-control input-grey" onkeypress="return numberonly(event,'#phone')" maxlength="10" placeholder="555-555-55-55" required/>
                    </div>
                </div>
				<?php if (\StaticDatabase\StaticDatabase::settings('findme_status') === "1"): ?>
					<?php
					$findMeList = \StaticDatabase\StaticDatabase::init()->prepare("SELECT * FROM findme_list");
					$findMeList->execute();
					?>
                    <div class="form-group">
                        <label class="col-xs-2 control-label">Bizi nerden buldunuz?</label>
                        <div class="col-xs-10">
                            <select name="findme" class="select-box">
                                <option value="0" selected>Lütfen seçiniz...</option>
								<?php foreach ($findMeList->fetchAll(PDO::FETCH_ASSOC) as $row):?>
                                    <option value="<?=$row["id"]?>"><?=$row["name"]?></option>
								<?php endforeach;?>
                            </select>
                        </div>
                    </div>
                <?php endif;?>
                <div class="form-group">
                    <label class="col-xs-2 control-label">Kontrol</label>
                    <div class="col-xs-10">
						<?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-xs-2 control-label"></label>
                    <div class="col-xs-10">
                        <span>Kayıt olarak <a href="<?=URI::get_path('privacy/index')?>" target="_blank">üyelik sözleşmesini</a> kabul ederim.</span>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                        <button type="submit" form="registerForm" class="btn btn-default downbutton"><?=$lng[10]?></button>
                    </div>
                </div>
            </form>
		<?php endif;?>
    </div>
</div>
<script>
    $('#pass2').change(function ()
    {
        var pass = $('#pass').val();
        var pass2 = $(this).val();
        if(pass != pass2){
            $('#pass2').notify(
                "Şifreler uyuşmuyor !",
                { position:"right" }
            );
        }
    });

    $("#registerForm").on("submit", function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                if (response.result)
                {
                    successNotify(response.message);
                    setTimeout(function () {
                        window.location.href = response.redirect;
                    },2000)
                }
                else
                {
                    errorNotify(response.message);
                    grecaptcha.reset();
                }
            }
        });
    });
</script>