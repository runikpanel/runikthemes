var dataTables = {
		/**
		 * @param string element -> jquery selector
		 * @param string url -> verilerin alınacağı link
		 * @param array sorting
		 * @param array columns
		 */
		create : function(element,link,order,columns,server,display,search,lengthChange){
		    if (search === undefined) {
		          search = true;
		    } 
		    if(lengthChange===undefined){
		    	lengthChange = true;
		    }
		    var table = jQuery(element).DataTable( {
                "serverSide": server,
                "processing": true,
                "deferRender": true,
                "ajax": {
                    url:link,
                    method: 'POST'
                },
	            "language": {
	                "url":"//cdn.datatables.net/plug-ins/1.10.6/i18n/Turkish.json"
	            },
	            "iDisplayLength" : display,
	            "bLengthChange": lengthChange,
	            "searching": search,
		        "order": order,
		        "columns": columns,
		        "initComplete": function(settings, json) {
		        	//Sadece entera basıldığında veya input temizledinğinde arama yap
		            jQuery(element+ '_filter input').unbind();
		            jQuery(element+'_filter input').bind('keyup', function(e) {
		                if(e.keyCode == 13) {
		                    table.search( this.value ).draw();
		                }
		                else if(e.keyCode == 8 && this.value == ''){
		                	table.search( this.value ).draw();
		                }
		                else if(e.keyCode == 46 && this.value == ''){
		                	table.search( this.value ).draw();
		                }
		            }); 
		        }
		    } );

		},
		/*processDialog : function (element){
			data = jQuery(element).data();
			bootbox.dialog({
				title : data.title,
				message : data.message,
				animate : true,
				onEscape : true,
				buttons : {
					cancel :{
						label : "İptal",
						className : "btn-default",
						callback : function(){
							bootbox.hideAll();
						}
					},
					confirm: {
					      label: data.confirmText,
					      className: data.confirmClass,
					      callback: function() {
					    	  jQuery.ajax({
					    		    url : jQuery(element).attr("href"),
					    		    type: "POST",
					    		    data: data.data,
					    		    dataType : 'json',
					    		    success: function(dataXHR)
					    		    {
					    		        if(dataXHR.status=="success"){
					    		        	bootbox.hideAll();
					    		        	if(data.deleteRow==true){
					    		        		var trId = jQuery(element).parents('tr').attr('id');
					    		        		var tableId = jQuery(element).parents('table').attr('id');
					    		        		dataTables.removeRow(tableId,trId)
					    		        	}
					    		        	toastr.success(dataXHR.message);
					    		        }else if(data.status == "error"){
					    		        	toastr.error(dataXHR.message);
					    		        }
					    		    },
					    		});
					      }
					}

				}
			});
		},*/
		removeRow : function (tableId,rowId){
			var dt = jQuery('#'+tableId).DataTable();
			var row = jQuery('#'+tableId).find('#'+rowId);
			dt.row(row).remove().draw();
		}
};
	
jQuery("body").on("click",".dataTable .process",function(){
		dataTables.processDialog(this);
		return false;
});
