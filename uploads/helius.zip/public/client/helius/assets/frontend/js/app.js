var app = {
	baseUri : '',
	pageReload : function (){
		location.reload(true);
	},
	goPage : function(url){
		location.href =  url;
	},
	alertHide : function(){
		jQuery("body").on("click","[data-hide='alert']",function(){
			jQuery(this).parent(".alert").addClass("hide");
		});
	},
	alertClose: function(){
		$('#alert-message .alert').prepend('<button type="button" class="close" data-dismiss="alert">&times;</button>');
	},
	init : function(baseUri){
		this.baseUri = baseUri;
		app.alertHide();
		app.alertClose();
	}
};

