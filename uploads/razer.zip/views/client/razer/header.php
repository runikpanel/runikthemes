<!DOCTYPE html>
<html>
<head>

    <!-- Meta start -->
    <meta charset="UTF-8">
    <meta name="robots" content="follow, index"/>
    <meta http-equiv="Content-Language" content="pl"/>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <base href="<?=URL?>">
    <title><?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> - <?=\StaticDatabase\StaticDatabase::settings('slogan')?></title>
    <!-- /meta start -->

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="<?=URL?>favicon.ico" sizes="16x16" />
    <!-- /favicon -->

    <!-- Meta -->
    <meta name="keywords" content="metin2, <?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?>, emek, orta emek, metin, pvp server metin2"/>
    <meta name="description" content="<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> pvp server Metin2 emek/zor."/>
    <!-- /meta -->

    <!-- OpenGraph tags (espec. Facebook) -->
    <meta property="og:type" content="article"/>
    <meta property="og:url" content="<?=URL?>"/>
    <meta property="og:title" content="<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> - Metin2 PVP Server"/>
    <meta property="og:description" content="<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?>-<?=\StaticDatabase\StaticDatabase::settings('slogan')?>. Uzun süre boyunca, hoş dengeli ve ilginç oyun sunuyoruz!"/>
    <meta property="og:image" content="<?=\StaticDatabase\StaticDatabase::settings('logo')?>"/>
    <!-- /openGraph tags -->


    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700" rel="stylesheet">
    <link rel="stylesheet" href="<?=URI::public_path()?>asset/css/style.css" type="text/css"/>
    <link rel="stylesheet" href="<?=URI::public_path()?>asset/css/other-reset.css" type="text/css"/>
    <link rel="stylesheet" href="<?=URI::public_path()?>asset/css/slick.css"type="text/css"/>
    <link rel="stylesheet" href="<?=URI::public_path()?>asset/css/slick-theme.css" type="text/css"/>

	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="<?=URI::public_path()?>global/css/main.css"/>
	<link rel="stylesheet" type="text/css" href="<?=URI::public_path()?>global/css/selectbox.css"/>
    <link rel="stylesheet" type="text/css" href="<?=URI::public_path()?>global/css/radiocheck.css"/>
    <link rel="stylesheet" type="text/css" href="<?=URI::public_path()?>global/css/shadowbox.css"/>
	<link rel="stylesheet" href="<?=URI::public_path()?>global/css/rankings.css"/>
    <link rel="stylesheet" href="<?=URI::public_path()?>global/css/popup.css"/>
    <link rel="stylesheet" href="<?=URI::public_path()?>global/css/jquery.modal.css"/>
	<link rel="stylesheet" href="<?=URI::public_path()?>global/css/fancybox.css" type="text/css" media="screen"/>
    <link rel="stylesheet" type="text/css" href="<?=URI::public_path('notify/css/notify.css')?>">
    <link rel="stylesheet" type="text/css" href="<?=URI::public_path('notify/css/prettify.css')?>">

	<!--[if IE 7]>
	<style type="text/css">
		.copy {padding-top: 0;}
		.main-inn {padding-bottom: 43px;}
		.vote-block {padding: 9px 0 0 0;}
	</style>
	<![endif]-->

	<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.0.min.js"></script>
	<script type="text/javascript" src="https://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
	<script type="text/javascript" src="<?=URI::public_path()?>asset/js/slick.min.js"></script>
	<script src="<?=URI::public_path()?>asset/js/jquery-ui.min.js"></script>

	<script type="text/javascript" src="<?=URI::public_path()?>global/js/jquery.modal.min.js"></script>
	<script type="text/javascript" src="<?=URI::public_path()?>global/js/selectbox.min.js"></script>
    <script type="text/javascript" src="<?=URI::public_path()?>global/js/footer_include.js"></script>
    <script type="text/javascript" src="<?=URI::public_path()?>global/js/ui.js"></script>
    <script type="text/javascript" src="<?=URI::public_path()?>global/js/flux.min.js"></script>
    <script type="text/javascript" src="<?=URI::public_path()?>global/js/popup.js"></script>
    <script type="text/javascript" src="<?=URI::public_path('')?>global/js/fancybox.js"></script>
    <script src="<?=URI::public_path()?>global/js/notify.js"></script>
    <script type="text/javascript" src="<?=URI::public_path('notify/js/notify.js')?>"></script>
    <script type="text/javascript" src="<?=URI::public_path('notify/js/prettify.js')?>"></script>
    <script type="text/javascript" src="<?=URI::public_path('notify/js/notify-function.js')?>"></script>
	<script src='https://www.google.com/recaptcha/api.js'></script>

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries --><!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <script type="text/javascript">
        $(document).ready(function () {
            var screenSize = $(window).height();
            var compareW = 767;
            if (screenSize > 0 && screenSize < compareW) {
                var fancy_a = 740;
                var fancy_b = 550;
                var fancy_c = "ishopbg-small";
                var fancy_d = "13px";
                var fancy_e = "3px";
                var fancy_f = "13px";
                var fancy_g = 754;
                var fancy_h = 574;
                var fancy_i = 6;
                var fancy_j = 20;
            }
            else
            {
                var fancy_a = 1016;
                var fancy_b = 655;
                var fancy_c = "ishopbg";
                var fancy_d = "16px";
                var fancy_e = "7px";
                var fancy_f = "16px";
                var fancy_g = 1032;
                var fancy_h = 690;
                var fancy_i = 8;
                var fancy_j = 28;
            }
            var fancybox_css = {
                'outer': {'background': null},
                'close': {'background_image': null, 'height': null, 'right': null, 'top': null, 'width': null}
            };
            $('a.itemshop').fancybox({
                'autoDimensions': false,
                'width': fancy_a,
                'height': fancy_b,
                'padding': 0,
                'scrolling': 'yes',
                'overlayColor': '#000',
                'overlayOpacity': 0.8,
                'onStart': function () {
                    fancybox_css.outer.background = $('#fancybox-outer').css('background');
                    fancybox_css.close.background_image = $('#fancybox-close').css('background-image');
                    fancybox_css.close.height = $('#fancybox-close').css('height');
                    fancybox_css.close.right = $('#fancybox-close').css('right');
                    fancybox_css.close.top = $('#fancybox-close').css('top');
                    fancybox_css.close.width = $('#fancybox-close').css('width');
                    $('#fancybox-outer').css({'background': 'transparent url("<?=URI::public_path('')?>static/images/'+fancy_c+'.png") center center no-repeat'});
                    $('#fancybox-close').css({
                        'background-image': 'none',
                        'cursor': 'pointer',
                        'height': fancy_d,
                        'right': '3px',
                        'top': fancy_e,
                        'width': fancy_f
                    });
                },
                'onComplete': function () {
                    $('#fancybox-inner').css({'top': fancy_j, 'left': fancy_i});
                    $('#fancybox-wrap').css({'width': fancy_g, 'height': fancy_h});
                },
                'onClosed': function () {
                    if (null != fancybox_css.outer.background) {
                        $('#fancybox-outer').css('background', fancybox_css.outer.background);
                    }
                    if (null != fancybox_css.close.background_image) {
                        $('#fancybox-close').css('background-image', fancybox_css.close.background_image);
                    }
                    if (null != fancybox_css.close.height) {
                        $('#fancybox-close').css('height', fancybox_css.close.height);
                    }
                    if (null != fancybox_css.close.right) {
                        $('#fancybox-close').css('right', fancybox_css.close.right);
                    }
                    if (null != fancybox_css.close.top) {
                        $('#fancybox-close').css('top', fancybox_css.close.top);
                    }
                    if (null != fancybox_css.close.width) {
                        $('#fancybox-close').css('width', fancybox_css.close.width);
                    }
                }
            });
        });
    </script>
	<script type="text/javascript">
		$(function () {
		$("#toTop").click(function () {
		$("html,body").stop().animate({ scrollTop: "0" }, 1000);
		});
		});
		$(window).scroll(function () {
		var uzunluk = $(document).scrollTop();
		if (uzunluk > 300) $("#toTop").fadeIn(500);
		else { $("#toTop").fadeOut(500); }
		});
	</script>
	<script>
        function search() {
            var keyword = $("input[name=keyword]").val();
            if (keyword.length < 4) {
                UI.alert("Arama yaparken en az 4 karakter girmelisiniz.");
            } else if (keyword.length > 20) {
                UI.alert("Arama yaparken en fazla 20 karakter girmelisiniz.");
            } else {
                $("#search").submit();
            }
        }
    </script>
</head>
<body>
<!-- Load Facebook SDK for JavaScript -->
<div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/tr_TR/sdk.js#xfbml=1&version=v3.2&appId=762916164068770&autoLogAppEvents=1"></script>
<script>
  window.fbAsyncInit = function() {
    FB.init({
      xfbml            : true,
      version          : 'v3.2'
    });
  };

  (function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/tr_TR/sdk/xfbml.customerchat.js';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
