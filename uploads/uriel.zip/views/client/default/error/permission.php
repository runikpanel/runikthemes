<div class="content_wrapper left">
    <div class="real_content">

        <h2 class="headline_news active"><span class="title"><?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> | 404</span></h2>
        <div class="p4px" style="display: block;">
            <div class="real_content">
                <div class="inner_content news_content">
                    <br>
                    <p>
                    </p>
                    <h1 style="text-align: center">404</h1>
                    <h2 style="text-align: center"><?=$lng[60]?> </h2>
                    <br>
                    <p></p>
                </div>
            </div>
        </div>
    </div>
</div>
