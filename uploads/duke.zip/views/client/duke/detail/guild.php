<?php
$guildInfo = $this->all["info"];
$name = $this->all["name"];
$guildMembers = $this->all["members"];
?>
<main class="content">
    <div class="panel panel-buyuk">
        <div class="panel-heading">
            <center>
				<?=$lng[43]?>
            </center>
        </div>
		<?php Cache::open($name."_guild");?>
		<?php if (Cache::check($name."_guild")):?>
            <div class="leader">
                <img src="<?=URL.'data/chrs/big/'.$guildInfo->job.'/'.Functions::playerPortrait($guildInfo->seviye).'.png'?>" alt="<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?>">
            </div>

            <div class="guilds">
                <div class="guild-detail-list">
                    <div class="detail-name"><?=$lng[46]?> </div>
                    <div class="detail-info">
                        <span class="purple"><?=$guildInfo->name?></span>
                    </div>
                </div>

                <div class="guild-detail-list">
                    <div class="detail-name">Lonca Lideri </div>
                    <div class="detail-info">
                        <span class="purple">
                            <a href="<?=URI::get_path('detail/player/'.$guildInfo->baskan)?>"><?=$guildInfo->baskan?></a>
                        </span>
                    </div>
                </div>

                <div class="guild-detail-list">
                    <div class="detail-name"><?=$lng[47]?></div>
                    <div class="detail-info">
                        <span class="purple"><?=$guildInfo->ladder_point?></span>
                    </div>
                </div>

                <div class="guild-detail-list">
                    <div class="detail-name">EXP</div>
                    <div class="detail-info">
                        <span class="purple"><?=$guildInfo->exp?></span>
                    </div>
                </div>

                <div class="guild-detail-list">
                    <div class="detail-name"><?=$lng[48]?></div>
                    <div class="detail-info">
                        <span class="purple">
                            <img src="<?=URL.'data/flags/'.$guildInfo->empire.'.png';?>" style="width:30px;" alt="<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?>">
                        </span>
                    </div>
                </div>

                <div class="guild-detail-list">
                    <div class="detail-name">Üye Sayısı</div>
                    <div class="detail-info">
                        <span class="purple">
                            <?=$guildMembers->count?>
                        </span>
                    </div>
                </div>

                <div class="guild-detail-list">
                    <div class="detail-name"><?=$lng[49]?></div>
                    <div class="detail-info">
                        <span class="purple">
                            <?=$guildInfo->win?>
                        </span>
                    </div>
                </div>

                <div class="guild-detail-list">
                    <div class="detail-name"><?=$lng[50]?></div>
                    <div class="detail-info">
                        <span class="purple">
                            <?=$guildInfo->draw?>
                        </span>
                    </div>
                </div>

                <div class="guild-detail-list">
                    <div class="detail-name"><?=$lng[51]?></div>
                    <div class="detail-info">
                        <span class="purple">
                            <?=$guildInfo->loss?>
                        </span>
                    </div>
                </div>
            </div>

		<?php endif;?>
		<?php Cache::close($name."_guild");?>
    </div>
</main>
