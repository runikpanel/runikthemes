<!-- NEWS -->
<div class="main-panel panel-download">
    <div class="main-header">
        404 NOT FOUND
    </div>
    <div class="main-content">
        <div class="main-inner main-inner-news">
            <div class="content-title"></div>
            <div class="main-text-bg">
                <div class="main-text">
                    <div class="bg-light">
                        <div class="fr-view">
                            <p style="text-align: center;"><img src="<?=URI::public_path('layout/assets/images/errorlogosupreme.png')?>" style="width: 300px;" class="fr-fic fr-dib"></p><p style="text-align: center;"><span style="font-size: 25px; font-family: Tahoma, Geneva, sans-serif;"><?=$lng[60]?></span></p></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="main-bottom"></div>
    </div>
    <!-- /main content -->
</div>
<!-- \news -->