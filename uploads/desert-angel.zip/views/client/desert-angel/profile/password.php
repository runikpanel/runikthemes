<?php $isBanned = $this->all["is_banned"];?>
<div class="main-panel panel-download">
    <div class="main-header">
        <?=$lng[141]?>
    </div>
    <div class="main-content">
        <div class="main-inner">
            <div class="content-title"></div>
            <div class="main-text-bg">
                <div class="main-text">
                    <?php if ($isBanned):?>
                        <?= Client::alert('error', $lng[112]);?>
                    <?php else:?>
                    <form id="passwordChangeForm" action="<?=URI::get_path('profile/passwordchange')?>" method="POST" autocomplete="off">
                        <div class="bg-light">
                            <table>
                                <tbody>
                                <tr>
                                    <td style="width: 150px;">
                                        <label class="register-input"><?=$lng[165]?></label>
                                    </td>
                                    <td>
                                        <input type="password" class="form-control grunge" name="old_password" required>
                                    </td>
                                </tr>
                                <tr>
                                <tr>
                                    <td style="width: 150px;">
                                        <label class="register-input"><?=$lng[166]?></label>
                                    </td>
                                    <td>
                                        <input type="password" class="form-control grunge" name="new_password" required>
                                    </td>
                                </tr>
                                <tr>
                                <tr>
                                    <td style="width: 150px;">
                                        <label class="register-input"><?=$lng[167]?></label>
                                    </td>
                                    <td>
                                        <input type="password" class="form-control grunge" name="re_password" required>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label class="register-input" style="margin-top: -23px;"><?=$lng[24]?></label>
                                    </td>
                                    <td>
                                        <?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                            <button type="submit" class="btn"><?=$lng[141]?></button>
                        </div>
                    </form>
                    <?php endif;?>
                </div>
            </div>
        </div>
    </div>
    <div class="main-bottom"></div>
</div>
<script>
    $("#passwordChangeForm").on("submit", function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                grecaptcha.reset();
                if (response.result)
                    successNotify(response.message);
                else
                    errorNotify(response.message);
            }
        });
    });
</script>