<div class="main-panel panel-download">
    <div class="main-header">
		<?=$lng[21]?>
    </div>
    <div class="main-content">
        <div class="main-inner">
            <div class="content-title"></div>
            <div class="main-text-bg">
                <div class="main-text">
                    <form id="loginForm" action="<?=URI::get_path('login/control')?>" method="POST" autocomplete="off">
                        <div class="bg-light">
                            <table>
                                <tbody>
                                <tr>
                                    <td style="width: 150px;">
                                        <label class="register-input" for="register-login"><?=$lng[22]?>:</label>
                                    </td>
                                    <td>
                                        <input type="text" id="login" name="login" placeholder="<?=$lng[22]?>">
                                    </td>
                                </tr>

                                <tr>
                                    <td>
                                        <label class="register-input" for="register-email"><?=$lng[23]?></label>
                                    </td>
                                    <td>
                                        <input type="password" id="password" name="password" maxlength="20"
                                               placeholder="<?=$lng[23]?>">
                                    </td>
                                </tr>
								<?php if (\StaticDatabase\StaticDatabase::settings('pin_status') === "1"): ?>
                                <tr>
                                    <td>
                                        <label class="register-input" for="register-email">PIN</label>
                                    </td>
                                    <td>
                                        <input type="password" id="pin" name="pin" maxlength="<?=\StaticDatabase\StaticDatabase::settings('pin_count')?>"
                                               placeholder="PIN">
                                    </td>
                                </tr>
                                <?php endif;?>
                                <tr>
                                    <td>
                                        <label class="register-input" for="register-email" style="margin-top: -23px;"><?=$lng[24]?></label>
                                    </td>
                                    <td>
                                        <?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                            <button type="submit" class="btn"><?=$lng[21]?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="main-bottom"></div>
</div>
<script>
    $("#loginForm").on('submit', function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                if (response.result)
                    window.location.href = response.redirect;
                else
                {
                    errorNotify(response.message);
                    grecaptcha.reset();
                }
            }
        });
    });
</script>