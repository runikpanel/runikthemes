<?php
$sId = Session::get('sId');
$urlLang = isset($_GET['url']) ? $_GET['url'] : null;
$urlLang = rtrim($urlLang,'/');
$urlLang = filter_var($urlLang,FILTER_SANITIZE_URL);
$urlLang = explode('/', $urlLang);

if($sId == null)
	Session::set('sId','site');

$aid = isset($_SESSION['aid']) ? $_SESSION['aid'] : null;
if (isset($aid)) {
	$getAin = Statistics::getCashAndMileage($aid);
}

if (Cache::check('server_statistics')){
	if (\StaticDatabase\StaticDatabase::settings('total_online_status')){
		$getCount['totalOnline'] = Statistics::online();
	}

	if (\StaticDatabase\StaticDatabase::settings('total_player_status')){
		$getCount['totalPlayer'] = Statistics::player();
	}

	if (\StaticDatabase\StaticDatabase::settings('total_account_status')){
		$getCount['totalAccount'] = Statistics::account();
	}

	if (\StaticDatabase\StaticDatabase::settings('today_login_status')){
		$getCount['todayLogin'] = Statistics::todayLogin();
	}

	if (\StaticDatabase\StaticDatabase::settings('active_pazar_status')){
		$getCount['activePazar'] = Statistics::offlineShop();
	}
}

if (Cache::check('player_ranking')){
	$result['topplayer'] = Statistics::topPlayer(5);
	$result['topguild'] =  Statistics::topGuild(5);
}
?>
<body>
<div class="top-panel">
    <div class="top-panel-container">
        <ul class="menu">
            <li><a href="<?=URI::get_path('index')?>"><?=$lng[8];?></a></li>
            <li><a href="<?=URI::get_path('register')?>"><?=$lng[10];?></a></li>
            <li><a href="<?=URI::get_path('download')?>"><?=$lng[0];?></a></li>
            <li><a href="<?=URI::get_path('ranked/player')?>"><?=$lng[11];?></a></li>
            <li><a href="<?=URL.MUTUAL?>" class="itemshop itemshop-btn iframe"><?=$lng[13];?></a></li>
            <li><a href="<?=URL.SHOP?>" class="itemshop itemshop-btn iframe"><?=$lng[12];?></a></li>
            <li><a href="<?=\StaticDatabase\StaticDatabase::settings('tanitim')?>" target="_blank"><?=$lng[184];?></a></li>
        </ul>
		<?php if (\StaticDatabase\StaticDatabase::settings('multi_languages')):?>
			<?php
			$getLanguage = \StaticDatabase\StaticDatabase::init()->prepare("SELECT * FROM language");
			$getLanguage->execute();
			$languagesS = $getLanguage->fetchAll(PDO::FETCH_ASSOC);
			?>
            <div class="lang-block">
				<?php foreach ($languagesS as $languages):?>
					<?php if ($languages['code'] === $_SESSION['language']):?>
                        <a href="javascript:void(0);" class="main-item"><img src="<?=URL."data/flags/country/".$_SESSION['language'].".png"?>" alt=""> <?=$languages["name"]?></a>
					<?php endif;?>
				<?php endforeach;?>
                <ul class="hidden-block">
					<?php foreach ($languagesS as $languages):?>
                        <li><a href="<?=URI::get_path('languages/select/'.$languages['code'])?>" class="main-item"><img src="<?=URL."data/flags/country/".$languages['code'].".png"?>" alt=""> <?=$languages["name"]?></a></li>
					<?php endforeach;?>
                </ul>
            </div>
		<?php endif;?>
        <div style="width: 330px">
			<?php if (isset($_SESSION['aid'])):?>
                <a href="<?=URI::get_path('profile')?>" class="button login" style="float: left;"><?=$lng[19];?></a>
                <a href="<?=URI::get_path('login/logout')?>" class="button login" style="float: left;"><?=$lng[148];?></a>
			<?php else:?>
                <a href="javascript:void(0);" onclick="openModal('loginModal')" class="button login" style="float: left;"><?=$lng[21];?></a>
                <a href="javascript:void(0);" onclick="openModal('registerModal')" class="button login" style="float: left">Hızlı Kayıt</a>
			<?php endif;?>
        </div>
    </div>
</div><!-- top-panel -->
<style>
    .logo-header .logo
    {
        display: block;
        margin-right: auto;
        margin-left: auto;
        width: <?=\StaticDatabase\StaticDatabase::settings('logo_width')?>;
        left: <?=\StaticDatabase\StaticDatabase::settings('logo_position_x')?>;
        right: 0;
        position: absolute;
        filter: <?=\StaticDatabase\StaticDatabase::settings('logo_filter')?>;
        margin-top: <?=\StaticDatabase\StaticDatabase::settings('logo_position_y')?>;
    }

    .logo:hover
    {
        filter: <?=\StaticDatabase\StaticDatabase::settings('logo_hover')?>;
    }
</style>
<div class="wrapper" data-sitekey="<?=\StaticDatabase\StaticDatabase::settings('sitekey')?>" data-public="<?=URI::public_path()?>">
    <header class="header">
        <div class="logo-header">
            <a href="<?=URI::get_path('index')?>" class="bright logo"><img src="<?=URL.\StaticDatabase\StaticDatabase::settings('logo')?>" alt="Logo"></a>
        </div>
        <!-- animation -->
        <div class="ball">
        </div>
        <div class="light">
        </div>
        <div class="sparks sparks-1">
        </div>
        <div class="sparks sparks-2">
        </div>
        <div class="sparks sparks-3">
        </div>
    </header><!-- .header-->

    <div class="container">
        <main class="content">
            <div class="slider">
                <div class="next"> </div>
                <div class="prev"> </div>
                <div class="slides">
                    <div class="slide active" style="background-image: url(<?=URI::public_path('assets/images/slider-img.jpg')?>); ">
                    </div>
                    <div class="slide" style="background-image: url(<?=URI::public_path('assets/images/slider-img.jpg')?>); ">
                    </div>
                    <div class="slide" style="background-image: url(<?=URI::public_path('assets/images/slider-img.jpg')?>); ">
                    </div>
                </div>
                <div class="navigation">
                </div>
            </div><!-- slider -->
