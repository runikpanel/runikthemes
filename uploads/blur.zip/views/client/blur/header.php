<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />

    <!--[if lt IE 9]>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.min.js"></script>
    <![endif]-->

    <base href="<?=URL?>">
    <title><?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> - <?=\StaticDatabase\StaticDatabase::settings('slogan')?></title>

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="<?=URL?>favicon.ico" sizes="16x16" />
    <!-- /favicon -->

    <!-- Meta -->
    <meta name="keywords" content="metin2, <?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?>, emek, orta emek, metin, pvp server metin2"/>
    <meta name="description" content="<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> pvp server Metin2 emek/zor."/>
    <!-- /meta -->

    <!-- OpenGraph tags (espec. Facebook) -->
    <meta property="og:type" content="article"/>
    <meta property="og:url" content="<?=URL?>"/>
    <meta property="og:title" content="<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> - Metin2 PVP Server"/>
    <meta property="og:description" content="<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?>-<?=\StaticDatabase\StaticDatabase::settings('slogan')?>. Uzun süre boyunca, hoş dengeli ve ilginç oyun sunuyoruz!"/>
    <meta property="og:image" content="<?=\StaticDatabase\StaticDatabase::settings('logo')?>"/>
    <!-- /openGraph tags -->

    <meta name="viewport" content="width=1280, maximum-scale=1">

    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700">
    <link rel="stylesheet" href="<?=URI::public_path('assets/css/css-reset.css')?>">
    <link rel="stylesheet" href="<?=URI::public_path('assets/css/style.css')?>">
    <link rel="stylesheet" href="<?=URI::public_path('assets/css/animate.css')?>">
    <link rel="stylesheet" href="<?=URI::public_path('assets/css/extra.css')?>"/>
    <link rel="stylesheet" href="<?=URI::public_path('main/css/fancybox.css')?>"/>
    <link rel="stylesheet" href="<?=URI::public_path('main/css/rankings.css')?>"/>
    <link rel="stylesheet" href="<?=URI::public_path('main/css/extra.css')?>">
    <link rel="stylesheet" href="<?=URI::public_path('notify/css/notify.css')?>">
    <link rel="stylesheet" href="<?=URI::public_path('notify/css/prettify.css')?>">
</head>