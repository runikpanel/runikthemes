<link href="https://fonts.googleapis.com/css?family=PT+Sans|Ravi+Prakash" rel="stylesheet">
<style>
    h2{
        letter-spacing: .2px;
        color: rgba(86, 0, 21, 0.91);
        font-size: 18px;
        text-align: center;
        margin-top: 15px;
        margin-left: 5px;
    }
    span{
        color: rgba(86, 0, 21, 0.91);
        text-align: center;
        margin-left: 5px;
        margin-right: 5px;
    }
    .content{
        margin-right: 15px;
    }
</style>
<h2>Mail Aktivasyonu İşlemi Nedir?</h2>
<div class="content">
<span>Mail aktivasyonu tamamen hesabınızı güvenliğe almak için tasarlanmış bir sistemdir.
    Mail aktivasyonu ile hesabınız mail adresinize bağlanır.
    Hesap üzerinde yapacağınız tüm işlemler (örn: güvenli pc,mail adresi değiştirme,depo şifresi değiştirme vb.) için sistem sizin mailinize bir link gönderir ve tüm hesap bilgi değişiklikleri için maile gönderilen bağlantıda gerçekleşir.
    Bu şekilde hesabınızı güvenliğe almış olursunuz ve sizden başkası hesapta herhangi bir değişiklik yapamaz.
    Güvenli bir oyun için mail aktivasyonu gerçekleştirmenizi öneririz. <br><br>
    Unutmayın mail aktivasyonu yapılmamış hesaplar Çalıntı Hesap bildiriminde bulunduklarında dikkate alınmaz. <br><br>
    KlkMt2 Ekibi İyi Oyunlar Diler...
</span>
</div>