<style>
    .label {color: #191616;}
</style>
<div class="col-md-9"><div class="col-md-12 no-padding">
        <div class="panel panel-buyuk">
            <div class="panel-heading"><?=$lng[66]?>
            </div>
            <div class="panel-body no-padding">
				<?php if (\StaticDatabase\StaticDatabase::settings('guild_rank_status') == "0"):?>
					<?php  echo Client::alert('error',"Lonca sıralaması şuanda kapalı!");?>
				<?php else:?>
                    <table class="table table-hermes">
                    <thead>
                    <tr>
                        <td>#</td>
                        <td style="text-align:left;"><?=$lng[67]?></td>
                        <td class="hidden-xs"><?=$lng[71]?></td>
                        <td class="hidden-xs"><?=$lng[48]?></td>
                        <td><?=$lng[44]?></td>
                        <td class="hidden-xs"><?=$lng[72]?></td>
                    </tr>
                    </thead>
                    <tbody>
					<?php Cache::open('guilds');?>
					<?php if (Cache::check('guilds')):?>
						<?php foreach ($this->all->data as $key => $guild):?>
                    <tr>
                        <td><?=($key+1)?></td>
                        <td style="text-align:left;"><a href="<?=URI::get_path('detail/guild/'.$guild->lonca)?>"><?=$guild->lonca?></a></td>
                        <td class="hidden-xs"><?=$guild->ladder_point?></td>
                        <td><img src="<?=URL.'data/flags/'.$guild->bayrak.'.png'?>" alt=""></td>
                        <td class="hidden-xs"><a href="<?=URI::get_path('detail/player/'.$guild->baskan)?>"><?=$guild->baskan;?></a></td>
                        <td class="hidden-xs">
                            <span class="label label-green"><?=$guild->win?></span> |
                            <span class="label label-draw"><?=$guild->draw?></span> |
                            <span class="label label-red"><?=$guild->loss?></span>
                        </td>
                    </tr>
					<?php endforeach;?>
					<?php endif;?>
					<?php Cache::close('guilds');?>
                    </tbody>
                </table>
                <?php endif;?>
            </div>
        </div>
    </div>
</div>