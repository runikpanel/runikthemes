<?php
$guildInfo = $this->all["info"];
$name = $this->all["name"];
$guildMembers = $this->all["members"];
?>
<div class="col-md-9"><div class="col-md-12 no-padding">
        <div class="panel panel-buyuk">
            <div class="panel-heading"><?=$lng[43]?>
            </div>
			<?php Cache::open($name."_guild");?>
			<?php if (Cache::check($name."_guild")):?>
            <div class="panel-body no-padding">
                <div class="col-md-12">
                    <div class="karakter-icerik">
                        <table class="KarakterDetayTablo">

                            <tbody>

                            <tr>
                                <td><?=$lng[46]?></td>
                                <td><?=$guildInfo->name?></td>
                            </tr>
                            <tr>
                                <td><?=$lng[44]?></td>
                                <td><a href="<?=URI::get_path('detail/player/'.$guildInfo->baskan)?>"><?=$guildInfo->baskan?></a></td>
                            </tr>
                            <tr>
                                <td><?=$lng[48]?></td>
                                <td><div><img src="<?=URL.'data/flags/'.$guildInfo->empire.'.png';?>" style="width:30px;" alt="<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?>"></div></td>
                            </tr>
                            <tr>
                                <td><?=$lng[47]?></td>
                                <td><?=$guildInfo->ladder_point?></td>
                            </tr>
                            <tr>
                                <td><?=$lng[49]?></td>
                                <td><?=$guildInfo->win?></td>
                            </tr>
                            <tr>
                                <td><?=$lng[51]?></td>
                                <td><?=$guildInfo->loss?></td>
                            </tr>
                            <tr>
                                <td><?=$lng[50]?></td>
                                <td><?=$guildInfo->draw?></td>
                            </tr>
                            <tr>
                                <td>Üye Sayısı</td>
                                <td><?=$guildMembers->count?></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
			<?php endif;?>
			<?php Cache::close($name."_guild");?>
        </div>
    </div>
</div>

