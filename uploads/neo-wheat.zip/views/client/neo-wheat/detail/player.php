<?php
$name = $this->all["name"];
?>
<div class="col-md-9"><div class="col-md-12 no-padding">
        <div class="panel panel-buyuk">
            <div class="panel-heading"><?=$lng[32]?>
            </div>
			<?php Cache::open($name."_player");?>
			<?php if (Cache::check($name."_player")):?>
				<?php
				$info = $this->all["info"];
				$playerInfo = $info->data[0];
				?>
            <div class="panel-body no-padding">
                <div class="col-md-3 no-padding">
                    <div class="karakter-bg karakter_<?=$playerInfo->job?>"></div>
                </div>
                <div class="col-md-9">
                    <div class="karakter-icerik">
                        <table class="KarakterDetayTablo">
                            <tbody>

                            <tr>
                                <td><?=$lng[35]?></td>
                                <td><?=$playerInfo->name?></td>
                            </tr>
                            <tr>
                                <td><?=$lng[68]?></td>
                                <td><?=$playerInfo->level?></td>
                            </tr>
                            <tr>
                                <td><?=$lng[37]?></td>
                                <td><div><?=Functions::flagName($playerInfo->empire)[1]?></div></td>
                            </tr>
                            <tr>
                                <td><?=$lng[40]?></td>
                                <td><?=$playerInfo->playtime?> <?=$lng[42]?></td>
                            </tr>
                            <tr>
                                <td><?=$lng[38]?></td>
                                <td>
                                    <a href="javascript:void(0)"><?= ($playerInfo->lonca == null) ? 'Yok' : $playerInfo->lonca?></a>
                                </td>
                            </tr>
                            <tr>
                                <td><?=$lng[39]?></td>
                                <td><?=Functions::prettyDateTime1($playerInfo->last_play)?></td>
                            </tr>
                            <tr>
                                <td><?=$lng[109]?></td>
                                <td><?=Functions::map($playerInfo->map_index)?></td>
                            </tr>
                            <tr>
                                <td><?=$lng[41]?></td>
                                <td><img src="<?=URL.'data/chrs/small/'.Functions::playerOnlineStatus($playerInfo->last_play).'.png'?>" style="width: 12px;" alt=""></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
			<?php endif;?>
			<?php Cache::close($name."_player");?>
        </div>
    </div>
</div>
