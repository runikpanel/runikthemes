<div class="col-md-9"><div class="col-md-12 no-padding">
        <div class="panel panel-buyuk">
            <div class="panel-heading"><?=$lng[21]?></div>
            <div class="panel-body">
                <form id="loginForm" action="<?=URI::get_path('login/control')?>" method="POST" class="form-horizontal" autocomplete="off">
                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-3 control-label"><?=$lng[22]?> </label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" name="login" id="login" maxlength="30">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-3 control-label"><?=$lng[23]?></label>
                        <div class="col-sm-6">
                            <input type="password" class="form-control" name="password" id="password" maxlength="30">
                        </div>
                    </div>
					<?php if (\StaticDatabase\StaticDatabase::settings('pin_status') === "1"): ?>
                        <div class="form-group">
                            <label for="inputEmail3" class="col-sm-3 control-label">PIN</label>
                            <div class="col-sm-6">
                                <input type="password" class="form-control" name="pin" id="pin" maxlength="<?=\StaticDatabase\StaticDatabase::settings('pin_count')?>">
                            </div>
                        </div>
					<?php endif;?>
                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-3 control-label"><?=$lng[24]?></label>
                        <div class="col-sm-6">
							<?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-offset-3 col-sm-6">
                            <button type="submit" class="btn btn-giris" style="margin-top: 10px;"> <?=$lng[21]?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script>
    $("#loginForm").on('submit', function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                if (response.result)
                    window.location.href = response.redirect;
                else
                {
                    errorNotify(response.message);
                    grecaptcha.reset();
                }
            }
        });
    });
</script>