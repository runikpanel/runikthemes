<div class="content_wrapper left">
    <div class="real_content">
        <h2 class="headline_news active"><span class="title"><?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> | <?=$lng[21]?></span></h2>
        <div class="p4px" style="display: block;">
            <div class="real_content">
                <div class="inner_content news_content">
                    <form id="loginForm" action="<?=URI::get_path('login/control')?>" method="post" autocomplete="off">
                        <table border="0" align="center" width="100%">
                            <tbody>
                            <tr>
                                <td align="center"><label><?=$lng[22]?> :<span style="color:darkred;text-shadow:none;">*</span><br>
                                        <input name="login" type="text" value=""></label>
                                </td>
                            </tr>
                            <tr>
                                <td align="center"><label><?=$lng[23]?> :<span style="color:darkred;text-shadow:none;">*</span><br>
                                        <input name="password" type="password">
                                    </label>
                                </td>
                            </tr>
							<?php if (\StaticDatabase\StaticDatabase::settings('pin_status') === "1"): ?>
                                <tr>
                                    <td align="center"><label>PIN :<span style="color:darkred;text-shadow:none;">*</span><br>
                                            <input name="pin" type="password" maxlength="<?=\StaticDatabase\StaticDatabase::settings('pin_count')?>">
                                        </label>
                                    </td>
                                </tr>
							<?php endif;?>
                            <tr>
                                <td align="center"><label><?=$lng[24]?> :<span style="color:darkred;text-shadow:none;">*</span><br>
										<?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                                    </label>
                                </td>
                            </tr>
                            <tr>
                                <td align="center">
                                    <br>
                                    <input type="submit" value="<?=$lng[21]?>">
                                    <div class="clear"></div>
                                    <br>
                                    <a href="<?=URI::get_path('recuperare')?>" class="sifreunuttum"><?=$lng[25]?></a> <br>
                                    <a href="<?=URI::get_path('recuperare/account')?>" class="sifreunuttum"><?=$lng[26]?></a><br>
                                </td>
                            </tr>
                            <tr>
                                <td>&nbsp;</td>
                            </tr>
                            </tbody>
                        </table>
                    </form>
                    <script>
                        $("#loginForm").on('submit', function (event) {
                            event.preventDefault();

                            var url = $(this).attr("action");
                            var data = $(this).serialize();

                            $.ajax({
                                url : url,
                                type : 'POST',
                                data : data,
                                dataType : 'json',
                                success : function (response) {
                                    if (response.result)
                                        window.location.href = response.redirect;
                                    else
                                    {
                                        errorNotify(response.message);
                                        grecaptcha.reset();
                                    }
                                }
                            });
                        });
                    </script>
                </div>
            </div>
        </div
    </div>
    </div>
</div>