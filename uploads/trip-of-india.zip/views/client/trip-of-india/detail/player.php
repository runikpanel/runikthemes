<?php
$name = $this->all["name"];
?>
<div class="content_wrapper left">
    <div class="real_content">
		<?php Cache::open($name."_player");?>
		<?php if (Cache::check($name."_player")):?>
			<?php
			$info = $this->all["info"];
			$playerInfo = $info->data[0];
			?>
        <h2 class="headline_news active"><span><?=$name?></span></h2>
        <div class="p4px" style="display: block;">
            <div class="real_content">
                <div class="inner_content news_content">
                    <br>
                    <div style="clear:both"></div>
                    <div class="value">
                        <br>
                        <div class="table">
                            <div class="row">
                                <div class="cell CharLeft">
                                    <div class="main-title CharChild"><?=$lng[33]?></div>
                                    <img src="<?=URL.'data/chrs/big/'.$playerInfo->job.'/'.Functions::playerPortrait($playerInfo->level).'.png'?>" style="width: 145px">
                                    <div class="childrow Level">Level<br><span><?=$playerInfo->level?></span></div>
                                    <div class="childrow"><b><?=$playerInfo->exp?></b> <span>Exp</span></div>

                                </div> <div class="cell CharRight">
                                    <div class="main-title CharChild"><?=$lng[174]?></div>
                                    <div class="childrow"><span><?=$lng[35]?>:</span> <?=$playerInfo->name?></div>
                                    <div class="childrow"><span><?=$lng[36]?>:</span> <?=Functions::jobName($playerInfo->job)?></div>
                                    <div class="childrow"><span><?=$lng[37]?>:</span> <?=Functions::flagName($playerInfo->empire)[1]?></div>
                                    <div class="childrow"><span><?=$lng[38]?>:</span> <?= ($playerInfo->lonca == null) ? 'Yok' : $playerInfo->lonca?> </div>

                                    <div class="childrow"><span><?=$lng[39]?>:</span> <b><?=Functions::prettyDateTime1($playerInfo->last_play)?></b> </div>
                                    <div class="childrow"><span><?=$lng[40]?>:</span> <b><?=$playerInfo->playtime?> <?=$lng[42]?></b> </div>


                                    <div class="childrow"><span><?=$lng[109]?>:</span> <b><?=Functions::map($playerInfo->map_index)?></b> </div>
                                    <div class="childrow"><span><?=$lng[41]?>:</span> <img src="<?=URL.'data/chrs/small/'.Functions::playerOnlineStatus($playerInfo->last_play).'.png'?>" style="width: 12px;" alt=""> </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<?php endif;?>
		<?php Cache::close($name."_player");?>
    </div>
</div>
