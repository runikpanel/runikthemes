<div class="content_wrapper left">
    <div class="real_content">

        <h2 class="headline_news active"><span class="title"><?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> | <?=$lng[66]?></span></h2>
        <div class="p4px" style="display: block;">
            <div class="real_content">
                <div class="inner_content news_content">
                    <center>
                        <a href="<?=URI::get_path('ranked/player')?>"><input type="button" value="<?=$lng[65]?>"></a>
                        <a href="javascript:void(0)"><input type="button" value="<?=$lng[66]?>"></a>
                    </center>
                    <br>
					<?php if (\StaticDatabase\StaticDatabase::settings('guild_rank_status') == "0"):?>
						<?php  echo Client::alert('error',"Lonca sıralaması şuanda kapalı!");?>
					<?php else:?>
                        <table class="topranking" cellspacing="1" cellpadding="0" style="line-height: 4">
                            <tbody><tr class="c0">
                                <td class="pname"><i>#</i></td>
                                <td class="pname"><i><?=$lng[67]?></i></td>
                                <td class="pname"><i><?=$lng[71]?></i></td>
                                <td class="pname"><i><?=$lng[48]?></i></td>
                                <td class="pname"><i><?=$lng[44]?></i></td>
                                <td class="pname"><i><?=$lng[72]?></i></td>
                            </tr>
							<?php Cache::open('guilds');?>
							<?php if (Cache::check('guilds')):?>
								<?php foreach ($this->all->data as $key => $guild):?>
                                    <tr class="c1">
                                        <td class="pname"><?=($key+1)?></td>
                                        <td class="pname"><a href="<?=URI::get_path('detail/guild/'.$guild->lonca)?>"><?=$guild->lonca?></a></td>
                                        <td class="pname"><?=$guild->ladder_point;?></td>
                                        <td class="pname"><img src="<?=URL.'data/flags/'.$guild->bayrak.'.png'?>" alt="<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?>"></td>
                                        <td class="pname"><a href="<?=URI::get_path('detail/player/'.$guild->baskan)?>"><?=$guild->baskan;?></a></td>
                                        <td class="pname">
                                            <span class="label label-green"><?=$guild->win?></span> |
                                            <span class="label label-draw"><?=$guild->draw?></span> |
                                            <span class="label label-red"><?=$guild->loss?></span>
                                        </td>
                                    </tr>
								<?php endforeach;?>
							<?php endif;?>
							<?php Cache::close('guilds');?>
                            </tbody>
                        </table>
                    <?php endif;?>
                </div>
            </div>
        </div>
    </div>
</div>