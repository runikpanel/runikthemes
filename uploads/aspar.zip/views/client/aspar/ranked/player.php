<div class="col-md-9"><div class="col-md-12 no-padding">
        <div class="panel panel-buyuk">
            <div class="panel-heading"><?=$lng[65]?>
            </div>
            <div class="panel-body no-padding">
				<?php if (\StaticDatabase\StaticDatabase::settings('player_rank_status') == "0"):?>
					<?php  echo Client::alert('error',"Oyuncu sıralaması şuanda kapalı!");?>
				<?php else:?>
                    <table class="table table-hermes">
                        <thead>
                        <tr>
                            <td>#</td>
                            <td style="text-align:left;"><?=$lng[67]?></td>
                            <td class="hidden-xs"><?=$lng[68]?></td>
                            <td><?=$lng[48]?></td>
                            <td class="hidden-xs"><?=$lng[69]?></td>
                            <td class="hidden-xs"><?=$lng[33]?></td>
                            <td class="hidden-xs"><?=$lng[41]?></td>
                        </tr>
                        </thead>
                        <tbody>
						<?php Cache::open('players');?>
						<?php if (Cache::check('players')):?>
							<?php foreach ($this->all->data as $key => $player):?>
                                <tr>
                                    <td><?=($key+1)?></td>
                                    <td style="text-align:left;"><a href="<?=URI::get_path('detail/player/'.$player->name)?>"><?=$player->name?></a></td>
                                    <td class="hidden-xs"><?=$player->level?></td>
                                    <td><img src="<?=URL.'data/flags/'.$player->empire.'.png'?>" alt="<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?>"></td>
                                    <td class="hidden-xs">
										<?php if ($player->guild_name != null):?>
                                            <a href="<?=URI::get_path('detail/guild/'.$player->guild_name)?>"><?=$player->guild_name;?></a>
										<?php else:?>
                                            <b style="color: #8b303d"><?=$lng[70]?></b>
										<?php endif;?>
                                    </td>
                                    <td>
                                        <img src="<?=URL.'data/chrs/small/'.$player->job.'.png'?>" alt="<?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?>">
                                    </td>
                                    <td>
                                        <center>
                                            <img class="class-portrait" src="<?=URL.'data/chrs/small/'.Functions::playerOnlineStatus($player->last_play).'.png'?>"/>
                                        </center>
                                    </td>
                                </tr>
							<?php endforeach;?>
						<?php endif;?>
						<?php Cache::close('players');?>
                        </tbody>
                    </table>
				<?php endif;?>
            </div>
        </div>
    </div>
</div>
