<aside id="right">
    <div id="content_ajax">
        <article class="page_article">
			<div class="panel-heading"><?=$lng[21]?></div>
            <div class="body">
                <div class="error-holder">
                    <div class="container_3 red wide fading-notification" align="left">
                    </div>
                </div>
                <form id="loginForm" class="page_form" action="<?=URI::get_path('login/control')?>" method="POST" autocomplete="off" >
                    <div class="form-group">
                        <label for="login" class="col-sm-3 control-label"><?=$lng[22]?></label>
                        <div class="col-sm-12">
                            <input type="text" class="form-control2" name="login" id="login" required maxlength="16"/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="password" class="col-sm-3 control-label"><?=$lng[23]?></label>
                        <div class="col-sm-12">
                            <input type="password" class="form-control2" name="password" id="password"/>
                        </div>
                    </div>
					<?php if (\StaticDatabase\StaticDatabase::settings('pin_status') === "1"): ?>
                        <div class="form-group">
                            <label for="pin" class="col-sm-3 control-label">PIN</label>
                            <div class="col-sm-12">
                                <input type="password" class="form-control2" name="pin" id="pin" maxlength="<?=\StaticDatabase\StaticDatabase::settings('pin_count')?>"/>
                            </div>
                        </div>
					<?php endif;?>
                    <div class="form-group">
                        <label for="recaptcha" class="col-sm-3 control-label"></label>
                        <div class="col-sm-12">
							<?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-3 col-sm-6">
                            <button type="submit" form="loginForm" name="login_submit" class="btn form-btn"><?=$lng[21]?></button>
                        </div>
                    </div>
                </form>
            </div>
        </article>
    </div>
</aside>
<script>
    $("#loginForm").on('submit', function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                if (response.result)
                    window.location.href = response.redirect;
                else
                {
                    errorNotify(response.message);
                    grecaptcha.reset();
                }
            }
        });
    });
</script>