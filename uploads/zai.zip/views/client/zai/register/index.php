<style>
    .g-recaptcha {
        transform: scale(0.66);
        transform-origin: 0 0;
        margin-left: 26%;
    }
</style>
<div class="content_wrapper left">
    <div class="real_content">
        <h2 class="headline_news active"><span class="title"><?=\StaticDatabase\StaticDatabase::settings('oyun_adi')?> | <?=$lng[10]?></span></h2>
        <div class="p4px" style="display: block;">
            <div class="real_content">
                <div class="inner_content news_content">
					<?php if (\StaticDatabase\StaticDatabase::settings('register_status') == "0"):?>
						<?php echo Client::alert('error','Kayıtlarımız şuanda kapalıdır!');?>
					<?php else:?>
                        <form id="registerForm" action="<?=URI::get_path('register/control')?>" method="POST" autocomplete="off">
                            <table border="0" align="center" width="100%">
                                <tbody>
                                <tr>
                                    <td align="center"><label><?=$lng[22]?> :<span style="color:darkred;text-shadow:none;">*</span><br>
                                            <input name="login" type="text" id="username" maxlength="16" required></label>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="center"><label><?=$lng[23]?> :<span style="color:darkred;text-shadow:none;">*</span><br>
                                            <input name="password" type="password" id="password" maxlength="30" required>
                                        </label>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="center"><label><?=$lng[94]?> :<span style="color:darkred;text-shadow:none;">*</span><br>
                                            <input type="password" name="password2" id="password2" maxlength="30" required></label>
                                    </td>
                                </tr>
								<?php if (\StaticDatabase\StaticDatabase::settings('pin_status') === "1"): ?>
                                    <tr>
                                        <td align="center"><label>PIN :<span style="color:darkred;text-shadow:none;">*</span><br>
                                                <input name="pin" type="password" id="pin" maxlength="<?=\StaticDatabase\StaticDatabase::settings('pin_count')?>" required>
                                            </label>
                                        </td>
                                    </tr>
								<?php endif;?>
                                <tr>
                                    <td align="center"><label><?=$lng[78]?> :<span style="color:darkred;text-shadow:none;">*</span><br>
                                            <input type="text" name="email" id="email" required></label>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="center"><label><?=$lng[95]?> :<span style="color:darkred;text-shadow:none;">*</span><br>
                                            <input type="text" name="name" id="name" maxlength="60" required></label>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="center"><label><?=$lng[96]?> :<span style="color:darkred;text-shadow:none;">*</span><br>
                                            <input type="text" name="ksk" id="ksk" maxlength="7" required></label>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="center"><label><?=$lng[97]?> :<span style="color:darkred;text-shadow:none;">*</span><br>
                                            <input type="text" name="phone" id="phone" maxlength="10" placeholder="555-555-55-55" required></label>
                                    </td>
                                </tr>
								<?php if (\StaticDatabase\StaticDatabase::settings('findme_status') === "1"): ?>
                                    <tr>
										<?php
										$findMeList = \StaticDatabase\StaticDatabase::init()->prepare("SELECT * FROM findme_list");
										$findMeList->execute();
										?>
                                        <td align="center"><label>Bizi nerden buldunuz? :<span style="color:darkred;text-shadow:none;">*</span><br>
                                                <select name="findme">
                                                    <option value="0" selected>Lütfen seçiniz...</option>
													<?php foreach ($findMeList->fetchAll(PDO::FETCH_ASSOC) as $row):?>
                                                        <option value="<?=$row["id"]?>"><?=$row["name"]?></option>
													<?php endforeach;?>
                                                </select>
                                        </td>
                                    </tr>
								<?php endif;?>
                                <tr>
                                    <td align="center"><label><br>
											<?=$this->captcha->google(\StaticDatabase\StaticDatabase::settings('sitekey'))->call();?>
                                        </label>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="center">
                                        <label>
                                            <span>Kayıt olarak <a href="<?=URI::get_path('privacy/index')?>" target="_blank">üyelik sözleşmesini</a> kabul ederim.</span>
                                        </label>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="center">
                                        <br>
                                        <input type="submit" value="<?=$lng[10]?>" style="width: 34%">
                                        <div class="clear"></div>
                                        <br>
                                    </td>
                                </tr>
                                <tr>
                                    <td>&nbsp;</td>
                                </tr>
                                </tbody>
                            </table>
                        </form>
					<?php endif;?>
                </div>
            </div>
        </div
    </div>
</div>
</div>
<script>
    $("#registerForm").on("submit", function (event) {
        event.preventDefault();

        var url = $(this).attr("action");
        var data = $(this).serialize();

        $.ajax({
            url : url,
            type : 'POST',
            data : data,
            dataType : 'json',
            success : function (response) {
                if (response.result)
                {
                    successNotify(response.message);
                    setTimeout(function () {
                        window.location.href = response.redirect;
                    },2000)
                }
                else
                {
                    errorNotify(response.message);
                    grecaptcha.reset();
                }
            }
        });
    });
</script>


